#pragma once
#include "ast.h"
#include <string>

std::string exprToString(const Expr* e);
std::string stmtToString(const Stmt* s);
std::string programToString(const Program& p);