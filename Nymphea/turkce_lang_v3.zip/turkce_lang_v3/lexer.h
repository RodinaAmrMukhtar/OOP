#pragma once
#include "token.h"
#include <string>
#include <vector>

class Lexer {
public:
    explicit Lexer(std::string source);
    std::vector<Token> tokenize();

private:
    std::string src;
    size_t i = 0;
    int line = 1;
    int col  = 1;

    bool isAtEnd() const;
    char peek() const;
    char peekNext() const;
    char advance();

    void skipWhitespaceAndComments();

    Token make(TokenType type, const std::string& lex, int startLine, int startCol);
    Token readNumber();
    Token readWord();
    Token readString();
};