#include "bytecode_vm.h"

#include <cmath>
#include <iostream>
#include <iomanip>
#include <unordered_set>
#include <random>
#include <sstream>
#include <stdexcept>

// -------------------------
// Chunk
// -------------------------

uint16_t Chunk::addConstant(Value v){
    constants.push_back(std::move(v));
    if(constants.size() > 0xFFFFu) throw std::runtime_error("Too many constants");
    return (uint16_t)(constants.size() - 1);
}

void Chunk::write(uint8_t byte, int line){
    code.push_back(byte);
    lines.push_back(line);
}

void Chunk::writeU16(uint16_t x, int line){
    // big endian for readability
    write((uint8_t)((x >> 8) & 0xFF), line);
    write((uint8_t)(x & 0xFF), line);
}


// -------------------------
// Disassembler
// -------------------------

std::string opcodeName(OpCode op){
    switch(op){
        case OpCode::NOP: return "NOP";
        case OpCode::CONSTANT: return "CONSTANT";
        case OpCode::NULLV: return "NULL";
        case OpCode::TRUEV: return "TRUE";
        case OpCode::FALSEV: return "FALSE";
        case OpCode::POP: return "POP";
        case OpCode::GET_LOCAL: return "GET_LOCAL";
        case OpCode::SET_LOCAL: return "SET_LOCAL";
        case OpCode::GET_GLOBAL: return "GET_GLOBAL";
        case OpCode::DEFINE_GLOBAL: return "DEFINE_GLOBAL";
        case OpCode::SET_GLOBAL: return "SET_GLOBAL";
        case OpCode::EQUAL: return "EQUAL";
        case OpCode::GREATER: return "GREATER";
        case OpCode::LESS: return "LESS";
        case OpCode::GREATER_EQUAL: return "GREATER_EQUAL";
        case OpCode::LESS_EQUAL: return "LESS_EQUAL";
        case OpCode::ADD: return "ADD";
        case OpCode::SUBTRACT: return "SUB";
        case OpCode::MULTIPLY: return "MUL";
        case OpCode::DIVIDE: return "DIV";
        case OpCode::MOD: return "MOD";
        case OpCode::NEGATE: return "NEGATE";
        case OpCode::NOT: return "NOT";
        case OpCode::IS_TRUTHY: return "IS_TRUTHY";
        case OpCode::PRINT: return "PRINT";
        case OpCode::JUMP: return "JUMP";
        case OpCode::JUMP_IF_FALSE: return "JUMP_IF_FALSE";
        case OpCode::LOOP: return "LOOP";
        case OpCode::CALL: return "CALL";
        case OpCode::CALL_BUILTIN: return "CALL_BUILTIN";
        case OpCode::MAKE_ARRAY: return "MAKE_ARRAY";
        case OpCode::INDEX_GET: return "INDEX_GET";
        case OpCode::INDEX_SET: return "INDEX_SET";
        case OpCode::STRUCT_DEF: return "STRUCT_DEF";
        case OpCode::MAKE_OBJECT: return "MAKE_OBJECT";
        case OpCode::GET_FIELD: return "GET_FIELD";
        case OpCode::SET_FIELD: return "SET_FIELD";
        case OpCode::RETURN: return "RETURN";
    }
    return "<UNKNOWN>";
}

static uint16_t readU16At(const Chunk& c, int offset){
    if(offset+1 >= (int)c.code.size()) return 0;
    return (uint16_t)((c.code[(size_t)offset] << 8) | c.code[(size_t)offset+1]);
}

int instructionSize(const Chunk& c, int offset){
    if(offset < 0 || offset >= (int)c.code.size()) return 1;
    OpCode op = (OpCode)c.code[(size_t)offset];
    switch(op){
        case OpCode::NOP: case OpCode::NULLV: case OpCode::TRUEV: case OpCode::FALSEV:
        case OpCode::POP: case OpCode::EQUAL: case OpCode::GREATER: case OpCode::LESS:
        case OpCode::GREATER_EQUAL: case OpCode::LESS_EQUAL: case OpCode::ADD: case OpCode::SUBTRACT:
        case OpCode::MULTIPLY: case OpCode::DIVIDE: case OpCode::MOD: case OpCode::NEGATE: case OpCode::NOT:
        case OpCode::IS_TRUTHY: case OpCode::PRINT: case OpCode::INDEX_GET: case OpCode::INDEX_SET: case OpCode::RETURN:
            return 1;

        case OpCode::CONSTANT: case OpCode::GET_LOCAL: case OpCode::SET_LOCAL:
        case OpCode::GET_GLOBAL: case OpCode::DEFINE_GLOBAL: case OpCode::SET_GLOBAL:
        case OpCode::JUMP: case OpCode::JUMP_IF_FALSE: case OpCode::LOOP:
        case OpCode::MAKE_ARRAY: case OpCode::GET_FIELD: case OpCode::SET_FIELD:
            return 3;

        case OpCode::CALL: 
            return 2;

        case OpCode::CALL_BUILTIN:
            return 4;

        case OpCode::STRUCT_DEF: {
            if(offset+5 >= (int)c.code.size()) return 1;
            uint16_t fieldCount = readU16At(c, offset+3);
            return 1 + 2 + 2 + (int)fieldCount * 4;
        }

        case OpCode::MAKE_OBJECT: {
            if(offset+5 >= (int)c.code.size()) return 1;
            uint16_t initCount = readU16At(c, offset+3);
            return 1 + 2 + 2 + (int)initCount * 2;
        }
    }
    return 1;
}

int disassembleInstruction(const Chunk& c, int offset, std::ostream& out){
    if(offset < 0 || offset >= (int)c.code.size()){
        out << "<eof>\n";
        return offset + 1;
    }
    OpCode op = (OpCode)c.code[(size_t)offset];
    out << std::setw(6) << std::setfill('0') << std::right << offset << "  "
        << std::setfill(' ') << std::left << std::setw(14) << opcodeName(op);

    auto printConst=[&](uint16_t idx){
        if(idx >= c.constants.size()){ out << "#" << idx << " <bad>"; return; }
        out << "#" << idx << " " ;
        const Value& v = c.constants[idx];
        if(v.type==Value::Type::String) out << '"' << v.str << '"';
        else out << v.toString();
    };

    switch(op){
        case OpCode::NOP: case OpCode::NULLV: case OpCode::TRUEV: case OpCode::FALSEV: case OpCode::POP:
        case OpCode::EQUAL: case OpCode::GREATER: case OpCode::LESS: case OpCode::GREATER_EQUAL: case OpCode::LESS_EQUAL:
        case OpCode::ADD: case OpCode::SUBTRACT: case OpCode::MULTIPLY: case OpCode::DIVIDE: case OpCode::MOD:
        case OpCode::NEGATE: case OpCode::NOT: case OpCode::IS_TRUTHY: case OpCode::PRINT:
        case OpCode::INDEX_GET: case OpCode::INDEX_SET: case OpCode::RETURN:
            break;

        case OpCode::CONSTANT: {
            uint16_t idx = readU16At(c, offset+1);
            out << " ";
            printConst(idx);
            break;
        }
        case OpCode::GET_LOCAL: case OpCode::SET_LOCAL: {
            uint16_t slot = readU16At(c, offset+1);
            out << " slot=" << slot;
            break;
        }
        case OpCode::GET_GLOBAL: case OpCode::DEFINE_GLOBAL: case OpCode::SET_GLOBAL: {
            uint16_t idx = readU16At(c, offset+1);
            out << " name=";
            printConst(idx);
            break;
        }
        case OpCode::JUMP: case OpCode::JUMP_IF_FALSE: {
            uint16_t off = readU16At(c, offset+1);
            int target = offset + 3 + (int)off;
            out << " -> " << target;
            break;
        }
        case OpCode::LOOP: {
            uint16_t off = readU16At(c, offset+1);
            int target = offset + 3 - (int)off;
            out << " -> " << target;
            break;
        }
        case OpCode::CALL: {
            if(offset+1 < (int)c.code.size()){
                uint8_t argc = c.code[(size_t)offset+1];
                out << " argc=" << (int)argc;
            }
            break;
        }
        case OpCode::CALL_BUILTIN: {
            uint16_t nameIdx = readU16At(c, offset+1);
            uint8_t argc = (offset+3 < (int)c.code.size()) ? c.code[(size_t)offset+3] : 0;
            out << " name=";
            printConst(nameIdx);
            out << " argc=" << (int)argc;
            break;
        }
        case OpCode::MAKE_ARRAY: {
            uint16_t count = readU16At(c, offset+1);
            out << " count=" << count;
            break;
        }
        case OpCode::GET_FIELD: case OpCode::SET_FIELD: {
            uint16_t nameIdx = readU16At(c, offset+1);
            out << " field=";
            printConst(nameIdx);
            break;
        }
        case OpCode::STRUCT_DEF: {
            uint16_t typeIdx = readU16At(c, offset+1);
            uint16_t fieldCount = readU16At(c, offset+3);
            out << " type=";
            printConst(typeIdx);
            out << " fields=" << fieldCount;
            break;
        }
        case OpCode::MAKE_OBJECT: {
            uint16_t typeIdx = readU16At(c, offset+1);
            uint16_t initCount = readU16At(c, offset+3);
            out << " type=";
            printConst(typeIdx);
            out << " inits=" << initCount;
            break;
        }
    }

    out << "\n";
    return offset + instructionSize(c, offset);
}

void disassembleChunk(const Chunk& c, const std::string& name, std::ostream& out){
    out << "== " << name << " ==\n";
    for(int off=0; off < (int)c.code.size(); ){
        off = disassembleInstruction(c, off, out);
    }
    out << "\n";
}

void disassembleProgram(const BytecodeProgram& p, std::ostream& out){
    // print script first
    if(p.main && p.main->chunk) disassembleChunk(*p.main->chunk, p.main->name.empty()?"<script>":p.main->name, out);
    for(const auto& fn : p.funcs){
        if(!fn || !fn->isBytecode || !fn->chunk) continue;
        if(fn.get() == p.main) continue;
        std::string nm = fn->name.empty()?"<fn>":fn->name;
        disassembleChunk(*fn->chunk, nm, out);
    }
}

// -------------------------
// Optimizer + Verifier
// -------------------------

static void writeU16At(Chunk& c, int offset, uint16_t x){
    if(offset+1 >= (int)c.code.size()) return;
    c.code[(size_t)offset] = (uint8_t)((x>>8)&0xFF);
    c.code[(size_t)offset+1] = (uint8_t)(x & 0xFF);
}

static std::unordered_set<int> collectJumpTargets(const Chunk& c){
    std::unordered_set<int> targets;
    for(int off=0; off < (int)c.code.size(); ){
        OpCode op = (OpCode)c.code[(size_t)off];
        int size = instructionSize(c, off);
        if(op==OpCode::JUMP || op==OpCode::JUMP_IF_FALSE){
            uint16_t rel = readU16At(c, off+1);
            int t = off + 3 + (int)rel;
            targets.insert(t);
        } else if(op==OpCode::LOOP){
            uint16_t rel = readU16At(c, off+1);
            int t = off + 3 - (int)rel;
            targets.insert(t);
        }
        off += size;
    }
    return targets;
}

static bool foldBinary(OpCode op, const Value& a, const Value& b, Value& out){
    if(op==OpCode::ADD){
        if(a.type==Value::Type::Number && b.type==Value::Type::Number){ out = Value::makeNumber(a.number + b.number); return true; }
        if(a.type==Value::Type::String && b.type==Value::Type::String){ out = Value::makeString(a.str + b.str); return true; }
        return false;
    }
    if(op==OpCode::SUBTRACT||op==OpCode::MULTIPLY||op==OpCode::DIVIDE||op==OpCode::MOD){
        if(a.type!=Value::Type::Number || b.type!=Value::Type::Number) return false;
        if(op==OpCode::DIVIDE && b.number==0.0) return false;
        if(op==OpCode::MOD && (long long)b.number==0) return false;
        if(op==OpCode::SUBTRACT){ out = Value::makeNumber(a.number - b.number); return true; }
        if(op==OpCode::MULTIPLY){ out = Value::makeNumber(a.number * b.number); return true; }
        if(op==OpCode::DIVIDE){ out = Value::makeNumber(a.number / b.number); return true; }
        long long aa=(long long)a.number, bb=(long long)b.number;
        out = Value::makeNumber((double)(aa % bb));
        return true;
    }
    if(op==OpCode::EQUAL){ out = Value::makeBool(a.type==b.type && a.toString()==b.toString()); return true; }
    if(op==OpCode::GREATER||op==OpCode::LESS||op==OpCode::GREATER_EQUAL||op==OpCode::LESS_EQUAL){
        if(a.type!=Value::Type::Number || b.type!=Value::Type::Number) return false;
        bool r=false;
        if(op==OpCode::GREATER) r = a.number > b.number;
        else if(op==OpCode::LESS) r = a.number < b.number;
        else if(op==OpCode::GREATER_EQUAL) r = a.number >= b.number;
        else r = a.number <= b.number;
        out = Value::makeBool(r);
        return true;
    }
    return false;
}

static bool foldUnary(OpCode op, const Value& a, Value& out){
    if(op==OpCode::NEGATE){
        if(a.type!=Value::Type::Number) return false;
        out = Value::makeNumber(-a.number);
        return true;
    }
    if(op==OpCode::NOT){
        // truthiness at compile time
        bool t=false;
        switch(a.type){
            case Value::Type::Bool: t=a.boolean; break;
            case Value::Type::Null: t=false; break;
            case Value::Type::Number: t=a.number!=0.0; break;
            case Value::Type::String: t=!a.str.empty(); break;
            default: return false;
        }
        out = Value::makeBool(!t);
        return true;
    }
    return false;
}

static BytecodeOptStats optimizeChunk(Chunk& c){
    BytecodeOptStats st;
    auto targets = collectJumpTargets(c);

    auto safeRegion=[&](int off, int len){
        for(int i=0;i<len;i++){
            if(targets.count(off+i)) return false;
        }
        return true;
    };

    // peephole folds
    for(int off=0; off < (int)c.code.size(); ){
        OpCode op = (OpCode)c.code[(size_t)off];

        // CONSTANT a; POP  => NOP x4
        if(op==OpCode::CONSTANT && off+3 < (int)c.code.size() && (OpCode)c.code[(size_t)off+3]==OpCode::POP && safeRegion(off,4)){
            c.code[(size_t)off]   = (uint8_t)OpCode::NOP;
            c.code[(size_t)off+1] = (uint8_t)OpCode::NOP;
            c.code[(size_t)off+2] = (uint8_t)OpCode::NOP;
            c.code[(size_t)off+3] = (uint8_t)OpCode::NOP;
            st.removedPushPop++;
            off += 4;
            continue;
        }

        // CONSTANT a; (NEGATE/NOT)
        if(op==OpCode::CONSTANT && off+3 < (int)c.code.size() && safeRegion(off,4)){
            OpCode uop = (OpCode)c.code[(size_t)off+3];
            if(uop==OpCode::NEGATE || uop==OpCode::NOT){
                uint16_t ia = readU16At(c, off+1);
                if(ia < c.constants.size()){
                    Value folded;
                    if(foldUnary(uop, c.constants[ia], folded)){
                        uint16_t ic = c.addConstant(folded);
                        c.code[(size_t)off] = (uint8_t)OpCode::CONSTANT;
                        writeU16At(c, off+1, ic);
                        c.code[(size_t)off+3] = (uint8_t)OpCode::NOP;
                        st.foldedConstants++;
                        off += 4;
                        continue;
                    }
                }
            }
        }

        // CONSTANT a; CONSTANT b; OP
        if(op==OpCode::CONSTANT && off+6 < (int)c.code.size() && safeRegion(off,7)){
            OpCode op2 = (OpCode)c.code[(size_t)off+3];
            OpCode bop = (OpCode)c.code[(size_t)off+6];
            if(op2==OpCode::CONSTANT){
                uint16_t ia = readU16At(c, off+1);
                uint16_t ib = readU16At(c, off+4);
                if(ia < c.constants.size() && ib < c.constants.size()){
                    Value folded;
                    if(foldBinary(bop, c.constants[ia], c.constants[ib], folded)){
                        uint16_t ic = c.addConstant(folded);
                        c.code[(size_t)off] = (uint8_t)OpCode::CONSTANT;
                        writeU16At(c, off+1, ic);
                        // NOP-out the remaining 4 bytes
                        for(int k=3;k<7;k++) c.code[(size_t)off+k] = (uint8_t)OpCode::NOP;
                        st.foldedConstants++;
                        off += 7;
                        continue;
                    }
                }
            }
        }

        // Jump threading for unconditional JUMP
        if(op==OpCode::JUMP && off+2 < (int)c.code.size()){
            int ipAfter = off + 3;
            uint16_t rel = readU16At(c, off+1);
            int target = ipAfter + (int)rel;
            int finalTarget = target;
            int guard=0;
            while(guard++ < 32 && finalTarget >=0 && finalTarget < (int)c.code.size() && (OpCode)c.code[(size_t)finalTarget]==OpCode::JUMP){
                uint16_t rel2 = readU16At(c, finalTarget+1);
                finalTarget = finalTarget + 3 + (int)rel2;
            }
            if(finalTarget != target){
                int newRel = finalTarget - ipAfter;
                if(newRel >=0 && newRel <= 0xFFFF){
                    writeU16At(c, off+1, (uint16_t)newRel);
                    st.threadedJumps++;
                }
            }
        }

        off += instructionSize(c, off);
    }
    return st;
}

// Remove NOPs and fix up jump offsets so the bytecode stream stays compact and readable.
// This is safe because our peephole optimizer only introduces NOPs in regions that are not
// jump targets; however we also handle the (rare) case where a jump points at a NOP by
// retargeting it to the next non-NOP instruction boundary.
static int compactChunk(Chunk& c){
    // 1) collect instruction boundaries from the *old* code
    std::vector<int> boundaries;
    boundaries.reserve(c.code.size()/2 + 8);
    for(int off=0; off < (int)c.code.size(); ){
        boundaries.push_back(off);
        int sz = instructionSize(c, off);
        if(sz <= 0) sz = 1;
        off += sz;
    }
    boundaries.push_back((int)c.code.size());

    // 2) precompute the next boundary that is NOT a NOP (or end)
    std::unordered_map<int,int> nextNonNop; // old boundary -> old boundary
    int nextKept = boundaries.back();
    for(int i=(int)boundaries.size()-1; i>=0; --i){
        int off = boundaries[(size_t)i];
        if(off == (int)c.code.size()){
            nextKept = off;
            nextNonNop[off] = off;
            continue;
        }
        OpCode op = (OpCode)c.code[(size_t)off];
        if(op != OpCode::NOP) nextKept = off;
        nextNonNop[off] = nextKept;
    }

    // 3) build new code, keeping non-NOP instructions, and remember old->new mapping for kept boundaries
    std::vector<uint8_t> oldCode = c.code;
    c.code.clear();
    c.code.reserve(oldCode.size());

    // A read-only view used only for instruction sizing.
    Chunk view;
    view.code = oldCode;
    view.maxLocals = c.maxLocals;

    std::unordered_map<int,int> oldToNew;
    oldToNew.reserve(boundaries.size()*2);
    int removed = 0;

    for(int off=0; off < (int)oldCode.size(); ){
        OpCode op = (OpCode)oldCode[(size_t)off];
        int sz = instructionSize(view, off);
        if(sz <= 0) sz = 1;

        if(op == OpCode::NOP){
            removed += sz;
            off += sz;
            continue;
        }

        int newOff = (int)c.code.size();
        oldToNew[off] = newOff;
        for(int i=0;i<sz;i++) c.code.push_back(oldCode[(size_t)off+i]);
        off += sz;
    }
    oldToNew[(int)oldCode.size()] = (int)c.code.size();

    auto mapTarget=[&](int oldTarget)->int{
        // If oldTarget was removed (NOP), bump it forward to the next non-NOP boundary.
        int bumped = oldTarget;
        auto it = nextNonNop.find(oldTarget);
        if(it != nextNonNop.end()) bumped = it->second;
        // If the bumped target is still not present (e.g., it was NOP and no following kept), use end.
        auto it2 = oldToNew.find(bumped);
        if(it2 != oldToNew.end()) return it2->second;
        return (int)c.code.size();
    };

    // 4) patch jump offsets in the new code using old targets.
    // We re-scan the old code in lockstep, and for any kept jump we compute its new relative.
    {
        for(int off=0; off < (int)oldCode.size(); ){
            OpCode op = (OpCode)oldCode[(size_t)off];
            int sz = instructionSize(view, off);
            if(sz <= 0) sz = 1;
            bool kept = (op != OpCode::NOP) && oldToNew.find(off) != oldToNew.end();

            if(kept && (op==OpCode::JUMP || op==OpCode::JUMP_IF_FALSE || op==OpCode::LOOP)){
                int newOff = oldToNew[off];
                int oldIpAfter = off + 3;
                uint16_t rel = (uint16_t)((oldCode[(size_t)off+1] << 8) | oldCode[(size_t)off+2]);

                int oldTarget;
                if(op==OpCode::LOOP) oldTarget = oldIpAfter - (int)rel;
                else oldTarget = oldIpAfter + (int)rel;

                int newIpAfter = newOff + 3;
                int newTarget = mapTarget(oldTarget);
                int newRel;
                if(op==OpCode::LOOP) newRel = newIpAfter - newTarget;
                else newRel = newTarget - newIpAfter;
                if(newRel < 0) newRel = 0;
                if(newRel > 0xFFFF) newRel = 0xFFFF;
                writeU16At(c, newOff+1, (uint16_t)newRel);
            }

            off += sz;
        }
    }

    return removed;
}

BytecodeOptStats optimizeProgram(BytecodeProgram& p){
    BytecodeOptStats total;
    for(auto& ch : p.chunks){
        if(!ch) continue;
        BytecodeOptStats st = optimizeChunk(*ch);
        int removedBytes = compactChunk(*ch);
        st.removedNops += removedBytes; // bytes removed
        total.foldedConstants += st.foldedConstants;
        total.removedPushPop += st.removedPushPop;
        total.threadedJumps += st.threadedJumps;
        total.removedNops += st.removedNops;
    }
    return total;
}

static void verifyChunk(const Chunk& c, const std::string& name, std::vector<std::string>& errors){
    // collect boundaries
    std::unordered_set<int> boundaries;
    int off=0;
    while(off < (int)c.code.size()){
        boundaries.insert(off);
        int sz = instructionSize(c, off);
        if(sz <= 0){ errors.push_back(name+": invalid instr size at "+std::to_string(off)); break; }
        off += sz;
    }
    if(off != (int)c.code.size()) errors.push_back(name+": chunk scan ended mid-instruction");

    auto needConstStr=[&](uint16_t idx, const std::string& what, int at){
        if(idx >= c.constants.size()) { errors.push_back(name+": bad const index for "+what+" at "+std::to_string(at)); return; }
        if(c.constants[idx].type != Value::Type::String) errors.push_back(name+": expected string const for "+what+" at "+std::to_string(at));
    };

    for(int i=0;i < (int)c.code.size(); ){
        OpCode op = (OpCode)c.code[(size_t)i];
        int sz = instructionSize(c, i);
        if(i+sz > (int)c.code.size()){ errors.push_back(name+": instruction overruns at "+std::to_string(i)); break; }

        if(op==OpCode::CONSTANT){
            uint16_t idx = readU16At(c, i+1);
            if(idx >= c.constants.size()) errors.push_back(name+": bad CONSTANT index at "+std::to_string(i));
        }
        if(op==OpCode::GET_LOCAL || op==OpCode::SET_LOCAL){
            uint16_t slot = readU16At(c, i+1);
            if(slot >= (uint16_t)c.maxLocals) errors.push_back(name+": local slot out of range at "+std::to_string(i));
        }
        if(op==OpCode::GET_GLOBAL || op==OpCode::DEFINE_GLOBAL || op==OpCode::SET_GLOBAL){
            uint16_t idx = readU16At(c, i+1);
            needConstStr(idx, "global name", i);
        }
        if(op==OpCode::GET_FIELD || op==OpCode::SET_FIELD){
            uint16_t idx = readU16At(c, i+1);
            needConstStr(idx, "field name", i);
        }
        if(op==OpCode::CALL_BUILTIN){
            uint16_t idx = readU16At(c, i+1);
            needConstStr(idx, "builtin name", i);
        }
        if(op==OpCode::STRUCT_DEF){
            uint16_t tidx = readU16At(c, i+1);
            needConstStr(tidx, "struct name", i);
            uint16_t fieldCount = readU16At(c, i+3);
            int expect = 1 + 2 + 2 + (int)fieldCount*4;
            if(expect != sz) errors.push_back(name+": STRUCT_DEF size mismatch at "+std::to_string(i));
        }
        if(op==OpCode::MAKE_OBJECT){
            uint16_t tidx = readU16At(c, i+1);
            needConstStr(tidx, "struct name", i);
        }
        if(op==OpCode::JUMP || op==OpCode::JUMP_IF_FALSE){
            uint16_t rel = readU16At(c, i+1);
            int target = i+3 + (int)rel;
            if(!boundaries.count(target)) errors.push_back(name+": jump target not on boundary at "+std::to_string(i));
        }
        if(op==OpCode::LOOP){
            uint16_t rel = readU16At(c, i+1);
            int target = i+3 - (int)rel;
            if(!boundaries.count(target)) errors.push_back(name+": loop target not on boundary at "+std::to_string(i));
        }

        i += sz;
    }
}

bool verifyProgram(const BytecodeProgram& p, std::vector<std::string>& errors){
    errors.clear();
    if(p.main && p.main->chunk) verifyChunk(*p.main->chunk, p.main->name.empty()?"<script>":p.main->name, errors);
    for(const auto& fn : p.funcs){
        if(!fn || !fn->isBytecode || !fn->chunk) continue;
        if(fn.get()==p.main) continue;
        verifyChunk(*fn->chunk, fn->name.empty()?"<fn>":fn->name, errors);
    }
    return errors.empty();
}

// -------------------------
// Compiler
// -------------------------

BytecodeCompiler::BytecodeCompiler(std::string source) : src(std::move(source)) {}

uint16_t BytecodeCompiler::makeConst(Value v){
    return current->addConstant(std::move(v));
}

uint16_t BytecodeCompiler::makeStringConst(const std::string& s){
    return makeConst(Value::makeString(s));
}

int BytecodeCompiler::currentOffset() const {
    return (int)current->code.size();
}

void BytecodeCompiler::emit(OpCode op, int line){ emitByte((uint8_t)op, line); }
void BytecodeCompiler::emitByte(uint8_t b, int line){ current->write(b, line); }
void BytecodeCompiler::emitU16(uint16_t x, int line){ current->writeU16(x, line); }

int BytecodeCompiler::emitJump(OpCode op, int line){
    emit(op, line);
    // placeholder
    emitU16(0xFFFF, line);
    return currentOffset() - 2; // position of the u16
}

void BytecodeCompiler::patchJump(int patchPos){
    // patchPos points to first byte of u16
    int jump = currentOffset() - patchPos - 2;
    if(jump < 0 || jump > 0xFFFF) throw std::runtime_error("Jump too large");
    current->code[(size_t)patchPos]     = (uint8_t)((jump >> 8) & 0xFF);
    current->code[(size_t)patchPos + 1] = (uint8_t)(jump & 0xFF);
}

void BytecodeCompiler::emitLoop(int loopStart, int line){
    emit(OpCode::LOOP, line);
    int offset = currentOffset() - loopStart + 2;
    if(offset < 0 || offset > 0xFFFF) throw std::runtime_error("Loop too large");
    emitU16((uint16_t)offset, line);
}

void BytecodeCompiler::beginScope(){ scopeDepth++; }

void BytecodeCompiler::endScope(){
    scopeDepth--;
    // pop locals whose depth is greater than current
    while(!locals.empty() && locals.back().depth > scopeDepth){
        locals.pop_back();
    }
}

int BytecodeCompiler::resolveLocal(const std::string& name) const{
    for(int i=(int)locals.size()-1;i>=0;--i){
        if(locals[(size_t)i].name == name) return locals[(size_t)i].slot;
    }
    return -1;
}

void BytecodeCompiler::declareLocal(const std::string& name){
    int slot = (int)locals.size();
    locals.push_back(Local{name, scopeDepth, slot});
    if(current) current->maxLocals = std::max(current->maxLocals, (int)locals.size());
}

bool BytecodeCompiler::isBuiltinName(const std::string& name) const{
    // must match Interpreter::isBuiltin list
    return
        name=="len" || name=="uzunluk" ||
        name=="tip" ||
        name=="sizeof" || name=="boyut" ||
        name=="push" || name=="ekle" ||
        name=="pop"  || name=="cikar" || name=="çıkar" ||
        name=="sil" ||
        name=="temizle" ||
        name=="anahtarlar" || name=="degerler" || name=="değerler" ||
        name=="varmi" || name=="varmı" ||
        name=="bol" ||
        name=="birlestir" || name=="birleştir" ||
        name=="alt" ||
        name=="mutlak" ||
        name=="taban" ||
        name=="tavan" ||
        name=="yuvarla" ||
        name=="min" ||
        name=="max" ||
        name=="rastgele" ||
        name=="pi" ||
        name=="sin" || name=="cos" || name=="tan" ||
        name=="sqrt" || name=="karekok" || name=="karekök" ||
        name=="pow" || name=="us" || name=="üs" ||
        name=="oku" ||
        name=="girdi" ||
        name=="oku_sayi" || name=="oku_sayı" ||
        name=="girdi_sayi" || name=="girdi_sayı" ||
        name=="oku_tamsayi" || name=="oku_tamsayı" ||
        name=="girdi_tamsayi" || name=="girdi_tamsayı" ||
        name=="yaz" ||
        name=="__kullaniliyor" ||
        name=="metne" ||
        name=="sayiya" || name=="sayıya" ||
        name=="mantiksala" || name=="mantıksala" ||
        name=="aralik" || name=="aralık" || name=="range";
}

Function* BytecodeCompiler::compileFunction(const StmtFunction* fn){
    // allocate function object + chunk
    auto chunk = std::make_unique<Chunk>();
    Chunk* chunkPtr = chunk.get();
    out.chunks.push_back(std::move(chunk));

    auto f = std::make_unique<Function>();
    f->name = fn->name;
    for(const auto& p : fn->params){ f->params.push_back(p.name); f->paramTypes.push_back(p.typeName); }
    f->returnType = fn->returnType;
    f->body = nullptr;
    f->chunk = chunkPtr;
    f->isBytecode = true;
    Function* fPtr = f.get();
    out.funcs.push_back(std::move(f));

    // compile body
    Chunk* prevChunk = current;
    Function* prevFn = currentFn;
    bool prevInFunc = inFunction;
    auto prevLocals = locals;
    int prevDepth = scopeDepth;
    auto prevCtx = ctxStack;

    current = chunkPtr;
    currentFn = fPtr;
    inFunction = true;
    locals.clear();
    scopeDepth = 0;
    ctxStack.clear();

    // params are locals in slot order
    for(const auto& p : fn->params) declareLocal(p.name);

    compileBlock(fn->body.get());

    // implicit return bos
    emit(OpCode::NULLV, 0);
    emit(OpCode::RETURN, 0);

    // restore
    current = prevChunk;
    currentFn = prevFn;
    inFunction = prevInFunc;
    locals = std::move(prevLocals);
    scopeDepth = prevDepth;
    ctxStack = std::move(prevCtx);

    return fPtr;
}

BytecodeProgram BytecodeCompiler::compile(const Program& program){
    out = BytecodeProgram{};

    // Script chunk
    auto mainChunk = std::make_unique<Chunk>();
    Chunk* mainChunkPtr = mainChunk.get();
    out.chunks.push_back(std::move(mainChunk));

    auto mainFnObj = std::make_unique<Function>();
    mainFnObj->name = "<script>";
    mainFnObj->params = {};
    mainFnObj->body = nullptr;
    mainFnObj->chunk = mainChunkPtr;
    mainFnObj->isBytecode = true;
    Function* mainFnPtr = mainFnObj.get();
    out.funcs.push_back(std::move(mainFnObj));
    out.main = mainFnPtr;

    current = mainChunkPtr;
    currentFn = mainFnPtr;
    inFunction = false;
    locals.clear();
    scopeDepth = 0;
    ctxStack.clear();

    // Hoist structs + functions so usage-before-decl works (matches tree-walk interpreter).
    for(const auto& st : program.stmts){
        if(dynamic_cast<const StmtStructDecl*>(st.get()) || dynamic_cast<const StmtFunction*>(st.get()))
            compileStmt(st.get());
    }
    for(const auto& st : program.stmts){
        if(dynamic_cast<const StmtStructDecl*>(st.get()) || dynamic_cast<const StmtFunction*>(st.get()))
            continue;
        compileStmt(st.get());
    }

    emit(OpCode::NULLV, 0);
    emit(OpCode::RETURN, 0);

    return std::move(out);
}

// -------------------------
// Statement compilation
// -------------------------

void BytecodeCompiler::compileBlock(const StmtBlock* b){
    beginScope();
    for(const auto& st : b->stmts) compileStmt(st.get());
    endScope();
}

void BytecodeCompiler::compileIf(const StmtIf* iff){
    compileExpr(iff->cond.get());
    int thenJump = emitJump(OpCode::JUMP_IF_FALSE, 0);
    emit(OpCode::POP, 0);
    compileStmt(iff->thenBranch.get());
    int elseJump = emitJump(OpCode::JUMP, 0);
    patchJump(thenJump);
    emit(OpCode::POP, 0);
    if(iff->elseBranch) compileStmt(iff->elseBranch.get());
    patchJump(elseJump);
}

void BytecodeCompiler::compileWhile(const StmtWhile* wh){
    int loopStart = currentOffset();

    BreakableContext ctx;
    ctx.kind = BreakableContext::Kind::Loop;
    ctx.loopStart = loopStart;
    ctx.continueTarget = loopStart;
    ctxStack.push_back(ctx);

    compileExpr(wh->cond.get());
    int exitJump = emitJump(OpCode::JUMP_IF_FALSE, 0);
    emit(OpCode::POP, 0);
    compileStmt(wh->body.get());

    // continue jumps to loopStart
    for(int p : ctxStack.back().continueJumps) patchJump(p);
    emitLoop(loopStart, 0);

    patchJump(exitJump);
    emit(OpCode::POP, 0);

    // break jumps to here
    for(int p : ctxStack.back().breakJumps) patchJump(p);
    ctxStack.pop_back();
}

void BytecodeCompiler::compileDoWhile(const StmtDoWhile* dw){
    int loopStart = currentOffset();

    BreakableContext ctx;
    ctx.kind = BreakableContext::Kind::Loop;
    ctx.loopStart = loopStart;
    ctx.continueTarget = currentOffset();
    ctxStack.push_back(ctx);

    compileStmt(dw->body.get());

    // continue target is just before condition
    ctxStack.back().continueTarget = currentOffset();
    for(int p : ctxStack.back().continueJumps) patchJump(p);

    compileExpr(dw->cond.get());
    int exitJump = emitJump(OpCode::JUMP_IF_FALSE, 0);
    emit(OpCode::POP, 0);
    emitLoop(loopStart, 0);
    patchJump(exitJump);
    emit(OpCode::POP, 0);

    for(int p : ctxStack.back().breakJumps) patchJump(p);
    ctxStack.pop_back();
}

void BytecodeCompiler::compileFor(const StmtFor* fr){
    beginScope();
    if(fr->init) compileStmt(fr->init.get());

    int loopStart = currentOffset();

    BreakableContext ctx;
    ctx.kind = BreakableContext::Kind::Loop;
    ctx.loopStart = loopStart;
    ctx.continueTarget = -1; // will become step start
    ctxStack.push_back(ctx);

    // condition
    if(fr->cond) compileExpr(fr->cond.get());
    else emit(OpCode::TRUEV, 0);
    int exitJump = emitJump(OpCode::JUMP_IF_FALSE, 0);
    emit(OpCode::POP, 0);

    // body
    compileStmt(fr->body.get());

    // step
    int stepStart = currentOffset();
    ctxStack.back().continueTarget = stepStart;
    for(int p : ctxStack.back().continueJumps) patchJump(p);
    if(fr->step) compileStmt(fr->step.get());

    emitLoop(loopStart, 0);
    patchJump(exitJump);
    emit(OpCode::POP, 0);

    for(int p : ctxStack.back().breakJumps) patchJump(p);
    ctxStack.pop_back();
    endScope();
}

void BytecodeCompiler::compileForeach(const StmtForeach* fe){
    // We compile foreach as an indexed for-loop over arrays or strings.
    beginScope();

    // temp locals: __it, __i
    declareLocal("__it");
    int itSlot = resolveLocal("__it");
    declareLocal("__i");
    int iSlot = resolveLocal("__i");

    // user locals
    if(fe->isPair){
        declareLocal(fe->firstName);
        declareLocal(fe->secondName);
    } else {
        declareLocal(fe->secondName);
    }
    int userFirst = fe->isPair ? resolveLocal(fe->firstName) : -1;
    int userSecond = resolveLocal(fe->secondName);

    // __it = iterable
    compileExpr(fe->iterable.get());
    emit(OpCode::SET_LOCAL, 0); emitU16((uint16_t)itSlot, 0);

    // __i = 0
    emit(OpCode::CONSTANT, 0); emitU16(makeConst(Value::makeNumber(0)), 0);
    emit(OpCode::SET_LOCAL, 0); emitU16((uint16_t)iSlot, 0);

    int loopStart = currentOffset();

    BreakableContext ctx;
    ctx.kind = BreakableContext::Kind::Loop;
    ctx.loopStart = loopStart;
    ctx.continueTarget = -1; // will become increment start
    ctxStack.push_back(ctx);

    // condition: __i < uzunluk(__it)
    emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)iSlot, 0);
    emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)itSlot, 0);
    // CALL_BUILTIN uzunluk 1
    emit(OpCode::CALL_BUILTIN, 0);
    emitU16(makeStringConst("uzunluk"), 0);
    emitByte(1, 0);
    emit(OpCode::LESS, 0);
    int exitJump = emitJump(OpCode::JUMP_IF_FALSE, 0);
    emit(OpCode::POP, 0);

    // element = __it[__i]
    emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)itSlot, 0);
    emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)iSlot, 0);
    emit(OpCode::INDEX_GET, 0);
    emit(OpCode::SET_LOCAL, 0); emitU16((uint16_t)userSecond, 0);

    if(fe->isPair){
        emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)iSlot, 0);
        emit(OpCode::SET_LOCAL, 0); emitU16((uint16_t)userFirst, 0);
    }

    compileStmt(fe->body.get());

    // increment start (continue target)
    int incStart = currentOffset();
    ctxStack.back().continueTarget = incStart;
    for(int p : ctxStack.back().continueJumps) patchJump(p);

    // __i = __i + 1
    emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)iSlot, 0);
    emit(OpCode::CONSTANT, 0); emitU16(makeConst(Value::makeNumber(1)), 0);
    emit(OpCode::ADD, 0);
    emit(OpCode::SET_LOCAL, 0); emitU16((uint16_t)iSlot, 0);

    emitLoop(loopStart, 0);

    patchJump(exitJump);
    emit(OpCode::POP, 0);

    for(int p : ctxStack.back().breakJumps) patchJump(p);
    ctxStack.pop_back();

    endScope();
}

void BytecodeCompiler::compileSwitch(const StmtSwitch* sw){
    // switch (expr) { case v: ... break; default: ... }
    beginScope();
    declareLocal("__switch_key");
    int keySlot = resolveLocal("__switch_key");

    compileExpr(sw->expr.get());
    emit(OpCode::SET_LOCAL, 0); emitU16((uint16_t)keySlot, 0);

    BreakableContext ctx;
    ctx.kind = BreakableContext::Kind::Switch;
    ctxStack.push_back(ctx);

    std::vector<int> caseJumpsToEnd;

    for(const auto& c : sw->cases){
        // if (key == caseValue) { ... ; jump end }
        emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)keySlot, 0);
        compileExpr(c.value.get());
        emit(OpCode::EQUAL, 0);
        int notMatch = emitJump(OpCode::JUMP_IF_FALSE, 0);
        emit(OpCode::POP, 0);

        // case body
        beginScope();
        for(const auto& st : c.stmts) compileStmt(st.get());
        endScope();

        // fall-through not supported here; jump to end after first match (same as interpreter)
        caseJumpsToEnd.push_back(emitJump(OpCode::JUMP, 0));

        patchJump(notMatch);
        emit(OpCode::POP, 0);
    }

    // default
    if(!sw->defaultStmts.empty()){
        beginScope();
        for(const auto& st : sw->defaultStmts) compileStmt(st.get());
        endScope();
    }

    // end label
    for(int p : caseJumpsToEnd) patchJump(p);
    for(int p : ctxStack.back().breakJumps) patchJump(p);
    ctxStack.pop_back();
    endScope();
}

void BytecodeCompiler::compileStmt(const Stmt* s){
    if(!s) return;

    if(auto sd = dynamic_cast<const StmtStructDecl*>(s)){
        // STRUCT_DEF typeName, fieldCount, then (fieldName, fieldType)*
        emit(OpCode::STRUCT_DEF, 0);
        emitU16(makeStringConst(sd->name), 0);
        emitU16((uint16_t)sd->fields.size(), 0);
        for(const auto& f : sd->fields){
            emitU16(makeStringConst(f.name), 0);
            emitU16(makeStringConst(f.typeName), 0);
        }
        return;
    }

    if(auto fn = dynamic_cast<const StmtFunction*>(s)){
        Function* f = compileFunction(fn);
        // push function constant then define global name
        emit(OpCode::CONSTANT, 0);
        emitU16(makeConst(Value::makeFunction(f)), 0);
        emit(OpCode::DEFINE_GLOBAL, 0);
        emitU16(makeStringConst(fn->name), 0);
        return;
    }

    if(auto ul = dynamic_cast<const StmtUseLib*>(s)){
        // compile as: __kullaniliyor("<lib>"); pop
        emit(OpCode::CONSTANT, 0);
        emitU16(makeConst(Value::makeString(ul->libName)), 0);
        emit(OpCode::CALL_BUILTIN, 0);
        emitU16(makeStringConst("__kullaniliyor"), 0);
        emitByte(1, 0);
        emit(OpCode::POP, 0);
        return;
    }

    if(auto vd = dynamic_cast<const StmtVarDecl*>(s)){
        // script-level declarations at depth 0 become globals; inside function always local
        if(!inFunction && scopeDepth==0){
            compileExpr(vd->init.get());
            emit(OpCode::DEFINE_GLOBAL, 0);
            emitU16(makeStringConst(vd->name), 0);
        } else {
            declareLocal(vd->name);
            int slot = resolveLocal(vd->name);
            compileExpr(vd->init.get());
            emit(OpCode::SET_LOCAL, 0);
            emitU16((uint16_t)slot, 0);
        }
        return;
    }

    if(auto as = dynamic_cast<const StmtAssign*>(s)){
        int slot = resolveLocal(as->name);
        compileExpr(as->value.get());
        if(slot >= 0){
            emit(OpCode::SET_LOCAL, 0);
            emitU16((uint16_t)slot, 0);
        } else {
            emit(OpCode::SET_GLOBAL, 0);
            emitU16(makeStringConst(as->name), 0);
        }
        return;
    }

    if(auto aa = dynamic_cast<const StmtAugAssign*>(s)){
        // compile as: x = x <op> rhs
        int slot = resolveLocal(aa->name);
        if(slot >= 0){
            emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)slot, 0);
        } else {
            emit(OpCode::GET_GLOBAL, 0); emitU16(makeStringConst(aa->name), 0);
        }
        compileExpr(aa->value.get());

        if(aa->op=="+=") emit(OpCode::ADD, 0);
        else if(aa->op=="-=") emit(OpCode::SUBTRACT, 0);
        else if(aa->op=="*=") emit(OpCode::MULTIPLY, 0);
        else if(aa->op=="/=") emit(OpCode::DIVIDE, 0);
        else throw std::runtime_error("Unknown aug op");

        if(slot >= 0){ emit(OpCode::SET_LOCAL, 0); emitU16((uint16_t)slot, 0); }
        else { emit(OpCode::SET_GLOBAL, 0); emitU16(makeStringConst(aa->name), 0); }
        return;
    }

    if(auto si = dynamic_cast<const StmtSetIndex*>(s)){
        int slot = resolveLocal(si->arrName);
        if(slot >= 0){ emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)slot, 0); }
        else { emit(OpCode::GET_GLOBAL, 0); emitU16(makeStringConst(si->arrName), 0); }
        compileExpr(si->index.get());
        compileExpr(si->value.get());
        emit(OpCode::INDEX_SET, 0);
        emit(OpCode::POP, 0);
        return;
    }

    if(auto sf = dynamic_cast<const StmtSetField*>(s)){
        int slot = resolveLocal(sf->objName);
        if(slot >= 0){ emit(OpCode::GET_LOCAL, 0); emitU16((uint16_t)slot, 0); }
        else { emit(OpCode::GET_GLOBAL, 0); emitU16(makeStringConst(sf->objName), 0); }
        compileExpr(sf->value.get());
        emit(OpCode::SET_FIELD, 0);
        emitU16(makeStringConst(sf->field), 0);
        emit(OpCode::POP, 0);
        return;
    }

    if(auto fe = dynamic_cast<const StmtForeach*>(s)){
        compileForeach(fe);
        return;
    }

    if(auto pr = dynamic_cast<const StmtPrint*>(s)){
        compileExpr(pr->expr.get());
        emit(OpCode::PRINT, 0);
        return;
    }

    if(auto es = dynamic_cast<const StmtExpr*>(s)){
        compileExpr(es->expr.get());
        emit(OpCode::POP, 0);
        return;
    }

    if(auto bl = dynamic_cast<const StmtBlock*>(s)){
        compileBlock(bl);
        return;
    }

    if(auto iff = dynamic_cast<const StmtIf*>(s)){
        compileIf(iff);
        return;
    }

    if(auto wh = dynamic_cast<const StmtWhile*>(s)){
        compileWhile(wh);
        return;
    }

    if(auto dw = dynamic_cast<const StmtDoWhile*>(s)){
        compileDoWhile(dw);
        return;
    }

    if(auto fr = dynamic_cast<const StmtFor*>(s)){
        compileFor(fr);
        return;
    }

    if(auto sw = dynamic_cast<const StmtSwitch*>(s)){
        compileSwitch(sw);
        return;
    }

    if(dynamic_cast<const StmtBreak*>(s)){
        if(ctxStack.empty()) throw std::runtime_error("'kir' outside loop/switch");
        int p = emitJump(OpCode::JUMP, 0);
        ctxStack.back().breakJumps.push_back(p);
        return;
    }

    if(dynamic_cast<const StmtContinue*>(s)){
        // find nearest loop context
        for(int i=(int)ctxStack.size()-1;i>=0;--i){
            if(ctxStack[(size_t)i].kind == BreakableContext::Kind::Loop){
                int p = emitJump(OpCode::JUMP, 0);
                ctxStack[(size_t)i].continueJumps.push_back(p);
                return;
            }
        }
        throw std::runtime_error("'devam' outside loop");
    }

    if(auto rt = dynamic_cast<const StmtReturn*>(s)){
        if(rt->value) compileExpr(rt->value.get());
        else emit(OpCode::NULLV, 0);
        emit(OpCode::RETURN, 0);
        return;
    }

    throw std::runtime_error("Unknown statement type in compiler");
}

// -------------------------
// Expression compilation
// -------------------------

void BytecodeCompiler::compileLogicalAnd(const ExprBinary* bin){
    compileExpr(bin->left.get());
    emit(OpCode::IS_TRUTHY, 0);
    int endJump = emitJump(OpCode::JUMP_IF_FALSE, 0);
    emit(OpCode::POP, 0);
    compileExpr(bin->right.get());
    emit(OpCode::IS_TRUTHY, 0);
    patchJump(endJump);
}

void BytecodeCompiler::compileLogicalOr(const ExprBinary* bin){
    compileExpr(bin->left.get());
    emit(OpCode::IS_TRUTHY, 0);
    int elseJump = emitJump(OpCode::JUMP_IF_FALSE, 0);
    // left is true => jump end with it still on stack
    int endJump = emitJump(OpCode::JUMP, 0);
    patchJump(elseJump);
    emit(OpCode::POP, 0);
    compileExpr(bin->right.get());
    emit(OpCode::IS_TRUTHY, 0);
    patchJump(endJump);
}

void BytecodeCompiler::compileExpr(const Expr* e){
    if(!e){ emit(OpCode::NULLV, 0); return; }

    if(auto n = dynamic_cast<const ExprNumber*>(e)){
        emit(OpCode::CONSTANT, 0);
        emitU16(makeConst(Value::makeNumber(n->value)), 0);
        return;
    }
    if(auto s = dynamic_cast<const ExprString*>(e)){
        emit(OpCode::CONSTANT, 0);
        emitU16(makeConst(Value::makeString(s->value)), 0);
        return;
    }
    if(auto b = dynamic_cast<const ExprBool*>(e)){
        emit(b->value ? OpCode::TRUEV : OpCode::FALSEV, 0);
        return;
    }
    if(dynamic_cast<const ExprNull*>(e)){
        emit(OpCode::NULLV, 0);
        return;
    }
    if(auto a = dynamic_cast<const ExprArray*>(e)){
        for(const auto& el : a->elems) compileExpr(el.get());
        emit(OpCode::MAKE_ARRAY, 0);
        emitU16((uint16_t)a->elems.size(), 0);
        return;
    }
    if(auto st = dynamic_cast<const ExprStruct*>(e)){
        // push initializer values in order, then MAKE_OBJECT typeName, initCount, fieldName...
        for(const auto& f : st->fields) compileExpr(f.value.get());
        emit(OpCode::MAKE_OBJECT, 0);
        emitU16(makeStringConst(st->typeName), 0);
        emitU16((uint16_t)st->fields.size(), 0);
        for(const auto& f : st->fields){
            emitU16(makeStringConst(f.name), 0);
        }
        return;
    }
    if(auto v = dynamic_cast<const ExprVar*>(e)){
        int slot = resolveLocal(v->name);
        if(slot >= 0){
            emit(OpCode::GET_LOCAL, 0);
            emitU16((uint16_t)slot, 0);
        } else {
            emit(OpCode::GET_GLOBAL, 0);
            emitU16(makeStringConst(v->name), 0);
        }
        return;
    }
    if(auto u = dynamic_cast<const ExprUnary*>(e)){
        compileExpr(u->right.get());
        if(u->op == "-") emit(OpCode::NEGATE, 0);
        else if(u->op == "degil" || u->op == "değil") emit(OpCode::NOT, 0);
        else throw std::runtime_error("Unknown unary op");
        return;
    }
    if(auto bin = dynamic_cast<const ExprBinary*>(e)){
        const std::string& op = bin->op;
        if(op=="ve"){ compileLogicalAnd(bin); return; }
        if(op=="veya"){ compileLogicalOr(bin); return; }
        compileExpr(bin->left.get());
        compileExpr(bin->right.get());

        if(op=="+") emit(OpCode::ADD, 0);
        else if(op=="-") emit(OpCode::SUBTRACT, 0);
        else if(op=="*") emit(OpCode::MULTIPLY, 0);
        else if(op=="/") emit(OpCode::DIVIDE, 0);
        else if(op=="%") emit(OpCode::MOD, 0);
        else if(op=="<") emit(OpCode::LESS, 0);
        else if(op=="<=") emit(OpCode::LESS_EQUAL, 0);
        else if(op==">") emit(OpCode::GREATER, 0);
        else if(op==">=") emit(OpCode::GREATER_EQUAL, 0);
        else if(op=="==") emit(OpCode::EQUAL, 0);
        else if(op=="!="){ emit(OpCode::EQUAL, 0); emit(OpCode::NOT, 0); }
        else throw std::runtime_error("Unknown binary op");
        return;
    }
    if(auto get = dynamic_cast<const ExprGet*>(e)){
        compileExpr(get->obj.get());
        emit(OpCode::GET_FIELD, 0);
        emitU16(makeStringConst(get->field), 0);
        return;
    }
    if(auto ix = dynamic_cast<const ExprIndex*>(e)){
        compileExpr(ix->base.get());
        compileExpr(ix->index.get());
        emit(OpCode::INDEX_GET, 0);
        return;
    }
    if(auto call = dynamic_cast<const ExprCall*>(e)){
        // builtin shortcut
        if(auto cv = dynamic_cast<const ExprVar*>(call->callee.get())){
            if(isBuiltinName(cv->name)){
                for(const auto& a : call->args) compileExpr(a.get());
                emit(OpCode::CALL_BUILTIN, 0);
                emitU16(makeStringConst(cv->name), 0);
                emitByte((uint8_t)call->args.size(), 0);
                return;
            }
        }
        // normal call
        compileExpr(call->callee.get());
        for(const auto& a : call->args) compileExpr(a.get());
        emit(OpCode::CALL, 0);
        emitByte((uint8_t)call->args.size(), 0);
        return;
    }

    throw std::runtime_error("Unknown expression type in compiler");
}

// -------------------------
// VM
// -------------------------

VM::VM(VMOptions opt) : options(std::move(opt)) {}

// -------------------------
// VM helpers
// -------------------------

void VM::runtimeError(const std::string& msg){
    hadError = true;
    std::cerr << "Runtime error: " << msg << "\n";

    if(options.dumpDisasmOnError && lastChunk){
        std::cerr << "At: " << (lastFn && !lastFn->name.empty()?lastFn->name:"<fn>")
                  << " ip=" << lastInstOffset << "\n";
        // show a small window around the failing instruction
        int start = (int)lastInstOffset - 30;
        if(start < 0) start = 0;
        int end = (int)lastInstOffset + 60;
        if(end > (int)lastChunk->code.size()) end = (int)lastChunk->code.size();
        for(int off=start; off<end; ){
            if(off == (int)lastInstOffset) std::cerr << "> "; else std::cerr << "  ";
            std::ostringstream oss;
            int next = disassembleInstruction(*lastChunk, off, oss);
            std::string s = oss.str();
            // indent
            std::cerr << s;
            if(next <= off) break;
            off = next;
        }
    }

    if(!frames.empty()){
        std::cerr << "Stack trace:\n";
        for(int i=(int)frames.size()-1;i>=0;--i){
            const auto& f = frames[(size_t)i];
            std::cerr << "  at " << (f.fn && !f.fn->name.empty()?f.fn->name:"<fn>")
                      << " ip=" << f.ip << "\n";
        }
    }
}


void VM::push(Value v){ stack.push_back(std::move(v)); }
Value VM::pop(){ Value v = stack.back(); stack.pop_back(); return v; }
Value VM::peek(int distance) const { return stack[stack.size() - 1 - (size_t)distance]; }

bool VM::isTruthy(const Value& v) const{
    switch(v.type){
        case Value::Type::Bool: return v.boolean;
        case Value::Type::Null: return false;
        case Value::Type::Number: return v.number != 0.0;
        case Value::Type::String: return !v.str.empty();
        case Value::Type::Function: return true;
        case Value::Type::Array: return v.arr && !v.arr->empty();
        case Value::Type::Object: return (bool)v.obj;
    }
    return false;
}

bool VM::valueEquals(const Value& a, const Value& b) const{
    if(a.type != b.type) return false;
    switch(a.type){
        case Value::Type::Null: return true;
        case Value::Type::Number: return a.number == b.number;
        case Value::Type::String: return a.str == b.str;
        case Value::Type::Bool: return a.boolean == b.boolean;
        case Value::Type::Function: return a.func == b.func;
        case Value::Type::Array: return a.arr == b.arr;
        case Value::Type::Object: return a.obj == b.obj;
    }
    return false;
}

// -------- UTF-8 helpers (copied from Interpreter) --------
static bool utf8_next(const std::string& s, size_t& pos, size_t& len){
    if(pos >= s.size()) return false;
    unsigned char c = (unsigned char)s[pos];
    if((c & 0x80) == 0x00) len = 1;
    else if((c & 0xE0) == 0xC0) len = 2;
    else if((c & 0xF0) == 0xE0) len = 3;
    else if((c & 0xF8) == 0xF0) len = 4;
    else return false;
    if(pos + len > s.size()) return false;
    return true;
}

int VM::utf8_codepoint_count(const std::string& s){
    size_t pos=0, len=0;
    int count=0;
    while(pos < s.size()){
        if(!utf8_next(s,pos,len)) return -1;
        pos += len;
        count++;
    }
    return count;
}

bool VM::utf8_nth_codepoint(const std::string& s, int index, std::string& out){
    int n = utf8_codepoint_count(s);
    if(n < 0) return false;
    if(index < 0) index = n + index;
    if(index < 0 || index >= n) return false;

    size_t pos=0, len=0;
    int cur=0;
    while(pos < s.size()){
        if(!utf8_next(s,pos,len)) return false;
        if(cur == index){ out = s.substr(pos, len); return true; }
        pos += len;
        cur++;
    }
    return false;
}

bool VM::utf8_substr(const std::string& s, int start, int count, std::string& out){
    int n = utf8_codepoint_count(s);
    if(n < 0) return false;
    if(start < 0) start = n + start;
    if(start < 0) start = 0;
    if(start > n) start = n;
    if(count < 0) count = 0;
    int end = start + count;
    if(end > n) end = n;

    size_t pos=0, len=0;
    int cur=0;
    size_t byteStart=0, byteEnd=0;
    bool gotStart=false, gotEnd=false;

    while(pos < s.size()){
        if(!utf8_next(s,pos,len)) return false;
        if(cur == start && !gotStart){ byteStart = pos; gotStart=true; }
        if(cur == end && !gotEnd){ byteEnd = pos; gotEnd=true; break; }
        pos += len;
        cur++;
    }
    if(!gotStart) byteStart = s.size();
    if(!gotEnd) byteEnd = s.size();
    if(byteEnd < byteStart) byteEnd = byteStart;
    out = s.substr(byteStart, byteEnd - byteStart);
    return true;
}

// -------------------------
// Library helpers
// -------------------------
static std::string toLowerAscii(std::string s){
    for(char& c : s){
        if(c>='A' && c<='Z') c = (char)(c - 'A' + 'a');
    }
    return s;
}

static std::string canonicalLibName(const std::string& s){
    std::string t = toLowerAscii(s);
    if(t=="mat_kutphanesi" || t=="mat_kütüphanesi" || t=="mat" || t=="math" ||
       t=="matematik_kutphanesi" || t=="matematik_kütüphanesi")
        return "math";
    return t;
}

static bool libEnabled(const std::unordered_set<std::string>& libs, const std::string& name){
    return libs.find(canonicalLibName(name)) != libs.end();
}

// -------------------------
// Builtins (copied from Interpreter with minimal edits)
// -------------------------

bool VM::isBuiltin(const std::string& name) const{
    return
        name=="len" || name=="uzunluk" ||
        name=="tip" ||
        name=="sizeof" || name=="boyut" ||
        name=="push" || name=="ekle" ||
        name=="pop"  || name=="cikar" || name=="çıkar" ||
        name=="sil" ||
        name=="temizle" ||
        name=="anahtarlar" || name=="degerler" || name=="değerler" ||
        name=="varmi" || name=="varmı" ||
        name=="bol" ||
        name=="birlestir" || name=="birleştir" ||
        name=="alt" ||
        name=="mutlak" ||
        name=="taban" ||
        name=="tavan" ||
        name=="yuvarla" ||
        name=="min" ||
        name=="max" ||
        name=="rastgele" ||
        name=="pi" ||
        name=="sin" || name=="cos" || name=="tan" ||
        name=="sqrt" || name=="karekok" || name=="karekök" ||
        name=="pow" || name=="us" || name=="üs" ||
        name=="oku" ||
        name=="girdi" ||
        name=="oku_sayi" || name=="oku_sayı" ||
        name=="girdi_sayi" || name=="girdi_sayı" ||
        name=="oku_tamsayi" || name=="oku_tamsayı" ||
        name=="girdi_tamsayi" || name=="girdi_tamsayı" ||
        name=="yaz" ||
        name=="__kullaniliyor" ||
        name=="metne" ||
        name=="sayiya" || name=="sayıya" ||
        name=="mantiksala" || name=="mantıksala" ||
        name=="aralik" || name=="aralık" || name=="range";
}

Value VM::callBuiltin(const std::string& name, const std::vector<Value>& args){
    // internal: enable libraries
    if(name=="__kullaniliyor"){
        if(args.size()!=1 || args[0].type!=Value::Type::String){
            runtimeError("__kullaniliyor(lib) expects 1 string");
            return Value::makeNull();
        }
        enabledLibs.insert(canonicalLibName(args[0].str));
        return Value::makeNull();
    }


    if(name=="len" || name=="uzunluk"){
        if(args.size()!=1){ runtimeError("uzunluk(x) expects 1 arg"); return Value::makeNull(); }
        const Value& x=args[0];
        if(x.type==Value::Type::String){
            int n = utf8_codepoint_count(x.str);
            if(n < 0){ runtimeError("uzunluk: invalid utf-8"); return Value::makeNull(); }
            return Value::makeNumber((double)n);
        }
        if(x.type==Value::Type::Array)  return Value::makeNumber(x.arr ? (double)x.arr->size() : 0.0);
        if(x.type==Value::Type::Object) return Value::makeNumber(x.obj ? (double)x.obj->fields.size() : 0.0);
        runtimeError("uzunluk: unsupported type");
        return Value::makeNull();
    }

    if(name=="tip"){
        if(args.size()!=1){ runtimeError("tip(x) expects 1 arg"); return Value::makeNull(); }
        return Value::makeString(args[0].typeName());
    }

    if(name=="sizeof" || name=="boyut"){
        if(args.size()!=1){ runtimeError("boyut(x) expects 1 arg"); return Value::makeNull(); }
        const Value& x=args[0];
        switch(x.type){
            case Value::Type::Null: return Value::makeNumber(0);
            case Value::Type::Bool: return Value::makeNumber(1);
            case Value::Type::Number: return Value::makeNumber(8);
            case Value::Type::String: return Value::makeNumber((double)x.str.size());
            case Value::Type::Function: return Value::makeNumber(8);
            case Value::Type::Array: return Value::makeNumber(x.arr ? (double)x.arr->size() : 0.0);
            case Value::Type::Object: return Value::makeNumber(x.obj ? (double)x.obj->fields.size() : 0.0);
        }
    }

    if(name=="aralik" || name=="aralık" || name=="range"){
        if(args.size()!=2){ runtimeError("aralik(a,b) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Number || args[1].type!=Value::Type::Number){
            runtimeError("aralik: args must be numbers");
            return Value::makeNull();
        }
        int a=(int)args[0].number;
        int b=(int)args[1].number;
        auto vec = std::make_shared<std::vector<Value>>();
        for(int i=a;i<b;i++) vec->push_back(Value::makeNumber(i));
        return Value::makeArray(vec);
    }

    if(name=="yaz"){
        if(args.size()!=1){ runtimeError("yaz(x) expects 1 arg"); return Value::makeNull(); }
        std::cout << args[0].toString();
        return Value::makeNull();
    }

    if(name=="oku" || name=="girdi"){
        if(args.size()>1){ runtimeError("oku([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(args.size()==1) std::cout << args[0].toString();
        std::string line;
        std::getline(std::cin, line);
        return Value::makeString(line);
    }

    if(name=="oku_sayi" || name=="oku_sayı" || name=="girdi_sayi" || name=="girdi_sayı"){
        if(args.size()>1){ runtimeError("oku_sayi([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(args.size()==1) std::cout << args[0].toString();
        std::string line;
        std::getline(std::cin, line);
        try{
            double v = std::stod(line);
            return Value::makeNumber(v);
        } catch(...){
            runtimeError("oku_sayi: not a number");
            return Value::makeNull();
        }
    }

    if(name=="oku_tamsayi" || name=="oku_tamsayı" || name=="girdi_tamsayi" || name=="girdi_tamsayı"){
        if(args.size()>1){ runtimeError("oku_tamsayi([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(args.size()==1) std::cout << args[0].toString();
        std::string line;
        std::getline(std::cin, line);
        try{
            long long v = std::stoll(line);
            return Value::makeNumber((double)v);
        } catch(...){
            runtimeError("oku_tamsayi: not an integer");
            return Value::makeNull();
        }
    }

    if(name=="metne"){
        if(args.size()!=1){ runtimeError("metne(x) expects 1 arg"); return Value::makeNull(); }
        return Value::makeString(args[0].toString());
    }

    if(name=="sayiya" || name=="sayıya"){
        if(args.size()!=1){ runtimeError("sayiya(x) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type==Value::Type::Number) return args[0];
        if(args[0].type==Value::Type::Bool) return Value::makeNumber(args[0].boolean?1:0);
        if(args[0].type==Value::Type::String){
            try{
                return Value::makeNumber(std::stod(args[0].str));
            } catch(...) {
                runtimeError("sayiya: invalid number string");
                return Value::makeNull();
            }
        }
        if(args[0].type==Value::Type::Null) return Value::makeNumber(0);
        runtimeError("sayiya: unsupported type");
        return Value::makeNull();
    }

    if(name=="mantiksala" || name=="mantıksala"){
        if(args.size()!=1){ runtimeError("mantiksala(x) expects 1 arg"); return Value::makeNull(); }
        return Value::makeBool(isTruthy(args[0]));
    }

    // push/ekle(array, x)
    if(name=="push" || name=="ekle"){
        if(args.size()!=2){ runtimeError("ekle(dizi,x) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){ runtimeError("ekle: first arg must be array"); return Value::makeNull(); }
        args[0].arr->push_back(args[1]);
        return Value::makeNull();
    }

    // pop/cikar(array)
    if(name=="pop" || name=="cikar" || name=="çıkar"){
        if(args.size()!=1){ runtimeError("cikar(dizi) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){ runtimeError("cikar: arg must be array"); return Value::makeNull(); }
        if(args[0].arr->empty()) return Value::makeNull();
        Value v = args[0].arr->back();
        args[0].arr->pop_back();
        return v;
    }

    // sil(array, i)
    if(name=="sil"){
        if(args.size()!=2){ runtimeError("sil(dizi,i) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){ runtimeError("sil: first arg must be array"); return Value::makeNull(); }
        if(args[1].type!=Value::Type::Number){ runtimeError("sil: index must be number"); return Value::makeNull(); }
        int i=(int)args[1].number;
        int n=(int)args[0].arr->size();
        if(i<0) i=n+i;
        if(i<0 || i>=n){ runtimeError("sil: index out of range"); return Value::makeNull(); }
        args[0].arr->erase(args[0].arr->begin()+i);
        return Value::makeNull();
    }

    if(name=="temizle"){
        if(args.size()!=1){ runtimeError("temizle(x) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type==Value::Type::Array && args[0].arr){ args[0].arr->clear(); return Value::makeNull(); }
        if(args[0].type==Value::Type::Object && args[0].obj){ args[0].obj->fields.clear(); return Value::makeNull(); }
        runtimeError("temizle: expects array/object");
        return Value::makeNull();
    }

    if(name=="anahtarlar"){
        if(args.size()!=1){ runtimeError("anahtarlar(obj) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Object || !args[0].obj){ runtimeError("anahtarlar: expects object"); return Value::makeNull(); }
        auto vec = std::make_shared<std::vector<Value>>();
        for(const auto& kv : args[0].obj->fields) vec->push_back(Value::makeString(kv.first));
        return Value::makeArray(vec);
    }

    if(name=="degerler" || name=="değerler"){
        if(args.size()!=1){ runtimeError("degerler(obj) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Object || !args[0].obj){ runtimeError("degerler: expects object"); return Value::makeNull(); }
        auto vec = std::make_shared<std::vector<Value>>();
        for(const auto& kv : args[0].obj->fields) vec->push_back(kv.second);
        return Value::makeArray(vec);
    }

    if(name=="varmi" || name=="varmı"){
        if(args.size()!=2){ runtimeError("varmi(x,y) expects 2 args"); return Value::makeNull(); }
        if(args[0].type==Value::Type::Array && args[0].arr){
            for(const auto& v : *args[0].arr){ if(valueEquals(v, args[1])) return Value::makeBool(true); }
            return Value::makeBool(false);
        }
        if(args[0].type==Value::Type::Object && args[0].obj){
            if(args[1].type!=Value::Type::String){ runtimeError("varmi(obj, key): key must be string"); return Value::makeNull(); }
            return Value::makeBool(args[0].obj->fields.find(args[1].str) != args[0].obj->fields.end());
        }
        runtimeError("varmi: unsupported type");
        return Value::makeNull();
    }

    // bol(metin, ayirici)
    if(name=="bol"){
        if(args.size()!=2 || args[0].type!=Value::Type::String || args[1].type!=Value::Type::String){
            runtimeError("bol(s, sep) expects 2 strings");
            return Value::makeNull();
        }
        auto vec = std::make_shared<std::vector<Value>>();
        const std::string& s=args[0].str;
        const std::string& sep=args[1].str;
        if(sep.empty()){
            // split into codepoints
            int n=utf8_codepoint_count(s);
            if(n<0){ runtimeError("bol: invalid utf-8"); return Value::makeNull(); }
            for(int i=0;i<n;i++){
                std::string ch;
                utf8_nth_codepoint(s, i, ch);
                vec->push_back(Value::makeString(ch));
            }
            return Value::makeArray(vec);
        }
        size_t pos=0;
        while(true){
            size_t p = s.find(sep, pos);
            if(p==std::string::npos){
                vec->push_back(Value::makeString(s.substr(pos)));
                break;
            }
            vec->push_back(Value::makeString(s.substr(pos, p-pos)));
            pos = p + sep.size();
        }
        return Value::makeArray(vec);
    }

    // birlestir(array, sep)
    if(name=="birlestir" || name=="birleştir"){
        if(args.size()!=2 || args[0].type!=Value::Type::Array || args[1].type!=Value::Type::String){
            runtimeError("birlestir(dizi, sep) expects (array,string)");
            return Value::makeNull();
        }
        std::string out;
        const std::string& sep=args[1].str;
        if(args[0].arr){
            for(size_t i=0;i<args[0].arr->size();++i){
                if(i) out += sep;
                out += (*args[0].arr)[i].toString();
            }
        }
        return Value::makeString(out);
    }

    // alt(string, start, count)
    if(name=="alt"){
        if(args.size()!=3 || args[0].type!=Value::Type::String || args[1].type!=Value::Type::Number || args[2].type!=Value::Type::Number){
            runtimeError("alt(s, start, count) expects (string,number,number)");
            return Value::makeNull();
        }
        std::string out;
        if(!utf8_substr(args[0].str, (int)args[1].number, (int)args[2].number, out)){
            runtimeError("alt: invalid utf-8");
            return Value::makeNull();
        }
        return Value::makeString(out);
    }

    // math
    if(name=="mutlak"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("mutlak(x) expects number"); return Value::makeNull(); }
        return Value::makeNumber(std::fabs(args[0].number));
    }
    if(name=="taban"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("taban(x) expects number"); return Value::makeNull(); }
        return Value::makeNumber(std::floor(args[0].number));
    }
    if(name=="tavan"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("tavan(x) expects number"); return Value::makeNull(); }
        return Value::makeNumber(std::ceil(args[0].number));
    }
    if(name=="yuvarla"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("yuvarla(x) expects number"); return Value::makeNull(); }
        return Value::makeNumber(std::round(args[0].number));
    }
    if(name=="min" || name=="max"){
        if(args.empty()){ runtimeError("min/max expects at least 1 arg"); return Value::makeNull(); }
        for(const auto& a: args){ if(a.type!=Value::Type::Number){ runtimeError("min/max needs numbers"); return Value::makeNull(); } }
        double best=args[0].number;
        for(size_t i=1;i<args.size();++i){
            if(name=="min") best = std::min(best, args[i].number);
            else best = std::max(best, args[i].number);
        }
        return Value::makeNumber(best);
    }
    if(name=="rastgele"){
        if(args.size()!=2 || args[0].type!=Value::Type::Number || args[1].type!=Value::Type::Number){
            runtimeError("rastgele(a,b) expects 2 numbers");
            return Value::makeNull();
        }
        int a=(int)args[0].number;
        int b=(int)args[1].number;
        if(a>b) std::swap(a,b);
        static std::random_device rd;
        static std::mt19937 gen(rd());
        std::uniform_int_distribution<int> dist(a,b);
        return Value::makeNumber((double)dist(gen));
    }


    // --- math library builtins (require: mat_kütüphanesi kullanılıyor;) ---
    auto requireMath=[&]()->bool{
        if(!libEnabled(enabledLibs, "math")){
            runtimeError("Bu fonksiyon için önce 'mat_kütüphanesi kullanılıyor;' yazmalısın");
            return false;
        }
        return true;
    };

    if(name=="pi"){
        if(!args.empty()){ runtimeError("pi() expects 0 args"); return Value::makeNull(); }
        if(!requireMath()) return Value::makeNull();
        return Value::makeNumber(3.14159265358979323846);
    }
    if(name=="sin" || name=="cos" || name=="tan"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){
            runtimeError(std::string(name)+"(x) expects 1 number");
            return Value::makeNull();
        }
        if(!requireMath()) return Value::makeNull();
        double x=args[0].number;
        if(name=="sin") return Value::makeNumber(std::sin(x));
        if(name=="cos") return Value::makeNumber(std::cos(x));
        return Value::makeNumber(std::tan(x));
    }
    if(name=="sqrt" || name=="karekok" || name=="karekök"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){
            runtimeError("karekok(x) expects 1 number");
            return Value::makeNull();
        }
        if(!requireMath()) return Value::makeNull();
        if(args[0].number < 0){ runtimeError("karekok: x must be >= 0"); return Value::makeNull(); }
        return Value::makeNumber(std::sqrt(args[0].number));
    }
    if(name=="pow" || name=="us" || name=="üs"){
        if(args.size()!=2 || args[0].type!=Value::Type::Number || args[1].type!=Value::Type::Number){
            runtimeError("us(x,y) expects 2 numbers");
            return Value::makeNull();
        }
        if(!requireMath()) return Value::makeNull();
        return Value::makeNumber(std::pow(args[0].number, args[1].number));
    }

    runtimeError("Unknown builtin: " + name);
    return Value::makeNull();
}

Value VM::opAdd(const Value& a, const Value& b){
    if(a.type==Value::Type::String || b.type==Value::Type::String)
        return Value::makeString(a.toString() + b.toString());
    if(a.type==Value::Type::Array && b.type==Value::Type::Array && a.arr && b.arr){
        auto out = std::make_shared<std::vector<Value>>(*a.arr);
        out->insert(out->end(), b.arr->begin(), b.arr->end());
        return Value::makeArray(out);
    }
    if(a.type==Value::Type::Number && b.type==Value::Type::Number)
        return Value::makeNumber(a.number + b.number);
    runtimeError("'+': needs numbers, strings, or arrays");
    return Value::makeNull();
}

// -------------------------
// VM execution
// -------------------------

static uint16_t readU16(const Chunk* c, size_t& ip){
    uint16_t hi = c->code[ip++];
    uint16_t lo = c->code[ip++];
    return (uint16_t)((hi << 8) | lo);
}

bool VM::run(Function* entry){
    hadError = false;
    stack.clear();
    frames.clear();
    structDefs.clear();

    if(!entry || !entry->isBytecode || !entry->chunk){
        runtimeError("VM entry is not bytecode function");
        return false;
    }

    CallFrame f;
    f.fn = entry;
    f.chunk = entry->chunk;
    f.ip = 0;
    f.locals.assign((size_t)f.chunk->maxLocals, Value::makeNull());
    frames.push_back(std::move(f));

    return runLoop();
}

bool VM::runLoop(){
    while(!frames.empty()){
        CallFrame& frame = frames.back();
        const Chunk* chunk = frame.chunk;
        if(frame.ip >= chunk->code.size()){
            runtimeError("Instruction pointer out of range");
            return false;
        }
        size_t instOffset = frame.ip;
        OpCode op = (OpCode)chunk->code[frame.ip++];

        lastChunk = chunk;
        lastInstOffset = instOffset;
        lastFn = frame.fn;

        if(options.trace){
            if(options.maxTraceSteps && traceSteps++ >= options.maxTraceSteps){
                runtimeError("Trace step limit reached");
                return false;
            }
            std::ostringstream oss;
            disassembleInstruction(*chunk, (int)instOffset, oss);
            std::string instLine = oss.str();
            if(!instLine.empty() && instLine.back()=='\n') instLine.pop_back();

            std::cerr << "[" << (frame.fn && !frame.fn->name.empty()?frame.fn->name:"<fn>")
                      << "] stack=";
            if(options.traceStack){
                std::cerr << "[";
                for(size_t si=0; si<stack.size(); ++si){
                    if(si) std::cerr << ", ";
                    std::cerr << stack[si].toString();
                }
                std::cerr << "] ";
            }
            std::cerr << instLine << '\n';
        }

        switch(op){
            case OpCode::NOP: break;
            case OpCode::CONSTANT: {
                uint16_t idx = readU16(chunk, frame.ip);
                if(idx >= chunk->constants.size()){ runtimeError("Bad constant index"); push(Value::makeNull()); break; }
                push(chunk->constants[idx]);
                break;
            }
            case OpCode::NULLV: push(Value::makeNull()); break;
            case OpCode::TRUEV: push(Value::makeBool(true)); break;
            case OpCode::FALSEV: push(Value::makeBool(false)); break;
            case OpCode::POP: {
                if(stack.empty()) { runtimeError("POP on empty stack"); break; }
                (void)pop();
                break;
            }

            case OpCode::GET_LOCAL: {
                uint16_t slot = readU16(chunk, frame.ip);
                if(slot >= frame.locals.size()){ runtimeError("Bad local slot"); push(Value::makeNull()); break; }
                push(frame.locals[slot]);
                break;
            }
            case OpCode::SET_LOCAL: {
                uint16_t slot = readU16(chunk, frame.ip);
                if(slot >= frame.locals.size()){ runtimeError("Bad local slot"); (void)pop(); break; }
                Value v = pop();
                frame.locals[slot] = v;
                break;
            }
            case OpCode::GET_GLOBAL: {
                uint16_t nameIdx = readU16(chunk, frame.ip);
                if(nameIdx >= chunk->constants.size() || chunk->constants[nameIdx].type!=Value::Type::String){
                    runtimeError("Bad global name constant"); push(Value::makeNull()); break;
                }
                const std::string& name = chunk->constants[nameIdx].str;
                auto it = globals.find(name);
                if(it == globals.end()){
                    runtimeError("Undefined variable: " + name);
                    push(Value::makeNull());
                } else {
                    push(it->second);
                }
                break;
            }
            case OpCode::DEFINE_GLOBAL: {
                uint16_t nameIdx = readU16(chunk, frame.ip);
                if(nameIdx >= chunk->constants.size() || chunk->constants[nameIdx].type!=Value::Type::String){
                    runtimeError("Bad global name constant"); (void)pop(); break;
                }
                const std::string& name = chunk->constants[nameIdx].str;
                Value v = pop();
                globals[name] = v;
                break;
            }
            case OpCode::SET_GLOBAL: {
                uint16_t nameIdx = readU16(chunk, frame.ip);
                if(nameIdx >= chunk->constants.size() || chunk->constants[nameIdx].type!=Value::Type::String){
                    runtimeError("Bad global name constant"); (void)pop(); break;
                }
                const std::string& name = chunk->constants[nameIdx].str;
                auto it = globals.find(name);
                if(it == globals.end()){
                    runtimeError("Assign to undefined: " + name);
                    (void)pop();
                } else {
                    it->second = pop();
                }
                break;
            }

            case OpCode::EQUAL: {
                Value b = pop();
                Value a = pop();
                push(Value::makeBool(valueEquals(a,b)));
                break;
            }
            case OpCode::GREATER:
            case OpCode::LESS:
            case OpCode::GREATER_EQUAL:
            case OpCode::LESS_EQUAL: {
                Value b = pop();
                Value a = pop();
                if(a.type!=Value::Type::Number || b.type!=Value::Type::Number){
                    runtimeError("Comparison needs numbers");
                    push(Value::makeNull());
                    break;
                }
                bool res=false;
                if(op==OpCode::GREATER) res = a.number > b.number;
                else if(op==OpCode::LESS) res = a.number < b.number;
                else if(op==OpCode::GREATER_EQUAL) res = a.number >= b.number;
                else if(op==OpCode::LESS_EQUAL) res = a.number <= b.number;
                push(Value::makeBool(res));
                break;
            }

            case OpCode::ADD: {
                Value b = pop();
                Value a = pop();
                push(opAdd(a,b));
                break;
            }
            case OpCode::SUBTRACT:
            case OpCode::MULTIPLY:
            case OpCode::DIVIDE:
            case OpCode::MOD: {
                Value b = pop();
                Value a = pop();
                if(a.type!=Value::Type::Number || b.type!=Value::Type::Number){
                    runtimeError("Operator needs numbers");
                    push(Value::makeNull());
                    break;
                }
                if(op==OpCode::SUBTRACT) push(Value::makeNumber(a.number - b.number));
                else if(op==OpCode::MULTIPLY) push(Value::makeNumber(a.number * b.number));
                else if(op==OpCode::DIVIDE){
                    if(b.number==0.0){ runtimeError("Division by zero"); push(Value::makeNull()); }
                    else push(Value::makeNumber(a.number / b.number));
                } else if(op==OpCode::MOD){
                    long long aa=(long long)a.number, bb=(long long)b.number;
                    if(bb==0){ runtimeError("Modulo by zero"); push(Value::makeNull()); }
                    else push(Value::makeNumber((double)(aa % bb)));
                }
                break;
            }

            case OpCode::NEGATE: {
                Value a = pop();
                if(a.type!=Value::Type::Number){ runtimeError("Unary '-' requires number"); push(Value::makeNull()); break; }
                push(Value::makeNumber(-a.number));
                break;
            }
            case OpCode::NOT: {
                Value a = pop();
                push(Value::makeBool(!isTruthy(a)));
                break;
            }
            case OpCode::IS_TRUTHY: {
                Value a = pop();
                push(Value::makeBool(isTruthy(a)));
                break;
            }

            case OpCode::PRINT: {
                Value a = pop();
                std::cout << a.toString() << "\n";
                break;
            }

            case OpCode::JUMP: {
                uint16_t offset = readU16(chunk, frame.ip);
                frame.ip += offset;
                break;
            }
            case OpCode::JUMP_IF_FALSE: {
                uint16_t offset = readU16(chunk, frame.ip);
                Value cond = peek(0);
                if(!isTruthy(cond)) frame.ip += offset;
                break;
            }
            case OpCode::LOOP: {
                uint16_t offset = readU16(chunk, frame.ip);
                frame.ip -= offset;
                break;
            }

            case OpCode::CALL_BUILTIN: {
                uint16_t nameIdx = readU16(chunk, frame.ip);
                uint8_t argc = chunk->code[frame.ip++];
                if(nameIdx >= chunk->constants.size() || chunk->constants[nameIdx].type!=Value::Type::String){
                    runtimeError("Bad builtin name constant");
                    // pop args
                    for(int i=0;i<argc;i++) (void)pop();
                    push(Value::makeNull());
                    break;
                }
                const std::string& name = chunk->constants[nameIdx].str;
                if(!isBuiltin(name)){
                    runtimeError("Unknown builtin: " + name);
                    for(int i=0;i<argc;i++) (void)pop();
                    push(Value::makeNull());
                    break;
                }
                std::vector<Value> args;
                args.resize(argc);
                for(int i=(int)argc-1;i>=0;--i) args[(size_t)i] = pop();
                Value r = callBuiltin(name, args);
                push(r);
                break;
            }

            case OpCode::CALL: {
                uint8_t argc = chunk->code[frame.ip++];
                // stack: ... callee arg1 ... argN
                if(stack.size() < (size_t)argc + 1){ runtimeError("CALL stack underflow"); push(Value::makeNull()); break; }
                std::vector<Value> args;
                args.resize(argc);
                for(int i=(int)argc-1;i>=0;--i) args[(size_t)i] = pop();
                Value callee = pop();
                if(callee.type!=Value::Type::Function || !callee.func){
                    runtimeError("Called value is not a function");
                    push(Value::makeNull());
                    break;
                }
                Function* fn = callee.func;
                if(!fn->isBytecode || !fn->chunk){
                    runtimeError("Function is not bytecode");
                    push(Value::makeNull());
                    break;
                }

                CallFrame nf;
                nf.fn = fn;
                nf.chunk = fn->chunk;
                nf.ip = 0;
                nf.locals.assign((size_t)nf.chunk->maxLocals, Value::makeNull());
                // bind params
                for(size_t i=0;i<fn->params.size();++i){
                    Value v = (i < args.size()) ? args[i] : Value::makeNull();
                    if(i < nf.locals.size()) nf.locals[i] = v;
                }
                frames.push_back(std::move(nf));
                break;
            }

            case OpCode::MAKE_ARRAY: {
                uint16_t count = readU16(chunk, frame.ip);
                auto vec = std::make_shared<std::vector<Value>>();
                vec->resize(count);
                for(int i=(int)count-1;i>=0;--i) (*vec)[(size_t)i] = pop();
                push(Value::makeArray(vec));
                break;
            }

            case OpCode::INDEX_GET: {
                Value idx = pop();
                Value base = pop();
                if(idx.type!=Value::Type::Number){ runtimeError("Index must be number"); push(Value::makeNull()); break; }
                int i=(int)idx.number;
                if(base.type==Value::Type::Array && base.arr){
                    int n=(int)base.arr->size();
                    if(i<0) i=n+i;
                    if(i<0 || i>=n){ runtimeError("Array index out of range"); push(Value::makeNull()); break; }
                    push((*base.arr)[(size_t)i]);
                    break;
                }
                if(base.type==Value::Type::String){
                    std::string ch;
                    if(!utf8_nth_codepoint(base.str, i, ch)){
                        runtimeError("String index out of range");
                        push(Value::makeNull());
                    } else {
                        push(Value::makeString(ch));
                    }
                    break;
                }
                runtimeError("Indexing supported only on array/string");
                push(Value::makeNull());
                break;
            }

            case OpCode::INDEX_SET: {
                Value val = pop();
                Value idx = pop();
                Value base = pop();
                if(base.type!=Value::Type::Array || !base.arr){ runtimeError("SetIndex requires array"); push(Value::makeNull()); break; }
                if(idx.type!=Value::Type::Number){ runtimeError("SetIndex index must be number"); push(Value::makeNull()); break; }
                int i=(int)idx.number;
                int n=(int)base.arr->size();
                if(i<0) i=n+i;
                if(i<0){ runtimeError("SetIndex out of range"); push(Value::makeNull()); break; }
                if(i >=0 && i < (int)base.arr->size()){
                    (*base.arr)[(size_t)i] = val;
                    push(val);
                    break;
                }
                if(i == (int)base.arr->size()){
                    base.arr->push_back(val);
                    push(val);
                    break;
                }
                runtimeError("SetIndex out of range (only existing index or append at size)");
                push(Value::makeNull());
                break;
            }

            case OpCode::STRUCT_DEF: {
                uint16_t typeIdx = readU16(chunk, frame.ip);
                uint16_t fieldCount = readU16(chunk, frame.ip);
                if(typeIdx >= chunk->constants.size() || chunk->constants[typeIdx].type!=Value::Type::String){
                    runtimeError("Bad struct name");
                    // skip pairs
                    for(int i=0;i<fieldCount;i++){ (void)readU16(chunk, frame.ip); (void)readU16(chunk, frame.ip); }
                    break;
                }
                std::string typeName = chunk->constants[typeIdx].str;
                StructDef def;
                for(int i=0;i<fieldCount;i++){
                    uint16_t fNameIdx = readU16(chunk, frame.ip);
                    uint16_t fTypeIdx = readU16(chunk, frame.ip);
                    if(fNameIdx >= chunk->constants.size() || fTypeIdx >= chunk->constants.size()){
                        runtimeError("Bad struct field constant");
                        continue;
                    }
                    if(chunk->constants[fNameIdx].type!=Value::Type::String || chunk->constants[fTypeIdx].type!=Value::Type::String){
                        runtimeError("Bad struct field constant type");
                        continue;
                    }
                    def.fieldTypes[chunk->constants[fNameIdx].str] = chunk->constants[fTypeIdx].str;
                }
                structDefs[typeName] = std::move(def);
                break;
            }

            case OpCode::MAKE_OBJECT: {
                uint16_t typeIdx = readU16(chunk, frame.ip);
                uint16_t initCount = readU16(chunk, frame.ip);
                if(typeIdx >= chunk->constants.size() || chunk->constants[typeIdx].type!=Value::Type::String){
                    runtimeError("Bad struct name");
                    // pop init values
                    for(int i=0;i<initCount;i++) (void)pop();
                    // skip names
                    for(int i=0;i<initCount;i++) (void)readU16(chunk, frame.ip);
                    push(Value::makeNull());
                    break;
                }
                std::string typeName = chunk->constants[typeIdx].str;
                auto it = structDefs.find(typeName);
                if(it == structDefs.end()){
                    runtimeError("Unknown struct type: " + typeName);
                    for(int i=0;i<initCount;i++) (void)pop();
                    for(int i=0;i<initCount;i++) (void)readU16(chunk, frame.ip);
                    push(Value::makeNull());
                    break;
                }
                std::vector<std::string> names;
                names.reserve(initCount);
                for(int i=0;i<initCount;i++){
                    uint16_t nameConst = readU16(chunk, frame.ip);
                    if(nameConst >= chunk->constants.size() || chunk->constants[nameConst].type!=Value::Type::String){
                        runtimeError("Bad field name const");
                        names.push_back("?");
                    } else names.push_back(chunk->constants[nameConst].str);
                }
                std::vector<Value> vals;
                vals.resize(initCount);
                for(int i=(int)initCount-1;i>=0;--i) vals[(size_t)i] = pop();

                auto obj = std::make_shared<Object>();
                obj->typeName = typeName;
                // defaults
                for(const auto& kv : it->second.fieldTypes){ obj->fields[kv.first] = Value::makeNull(); }

                // apply init
                for(size_t i=0;i<names.size();++i){
                    const std::string& fname = names[i];
                    auto ft = it->second.fieldTypes.find(fname);
                    if(ft==it->second.fieldTypes.end()){
                        runtimeError("Unknown field '" + fname + "' for struct " + typeName);
                        continue;
                    }
                    const Value& val = vals[i];
                    const std::string& tname = ft->second;
                    bool ok=true;
                    if(tname=="tamsayi" || tname=="tamsayı") ok = (val.type==Value::Type::Number || val.type==Value::Type::Null);
                    else if(tname=="metin") ok = (val.type==Value::Type::String || val.type==Value::Type::Null);
                    else if(tname=="mantiksal" || tname=="mantıksal") ok = (val.type==Value::Type::Bool || val.type==Value::Type::Null);
                    if(!ok){ runtimeError("Field '" + fname + "' type mismatch in " + typeName); continue; }
                    obj->fields[fname] = val;
                }
                push(Value::makeObject(obj));
                break;
            }

            case OpCode::GET_FIELD: {
                uint16_t nameIdx = readU16(chunk, frame.ip);
                if(nameIdx >= chunk->constants.size() || chunk->constants[nameIdx].type!=Value::Type::String){
                    runtimeError("Bad field name");
                    (void)pop();
                    push(Value::makeNull());
                    break;
                }
                std::string field = chunk->constants[nameIdx].str;
                Value base = pop();
                if(base.type!=Value::Type::Object || !base.obj){ runtimeError("'.' needs object"); push(Value::makeNull()); break; }
                auto itf = base.obj->fields.find(field);
                if(itf==base.obj->fields.end()){
                    runtimeError("Unknown field: " + field);
                    push(Value::makeNull());
                } else push(itf->second);
                break;
            }

            case OpCode::SET_FIELD: {
                uint16_t nameIdx = readU16(chunk, frame.ip);
                if(nameIdx >= chunk->constants.size() || chunk->constants[nameIdx].type!=Value::Type::String){
                    runtimeError("Bad field name");
                    (void)pop(); (void)pop();
                    push(Value::makeNull());
                    break;
                }
                std::string field = chunk->constants[nameIdx].str;
                Value val = pop();
                Value base = pop();
                if(base.type!=Value::Type::Object || !base.obj){ runtimeError("SetField requires object"); push(Value::makeNull()); break; }

                auto defIt = structDefs.find(base.obj->typeName);
                if(defIt != structDefs.end()){
                    auto ft = defIt->second.fieldTypes.find(field);
                    if(ft==defIt->second.fieldTypes.end()){
                        runtimeError("Unknown field '" + field + "' for struct " + base.obj->typeName);
                        push(Value::makeNull());
                        break;
                    }
                    const std::string& tname=ft->second;
                    bool ok=true;
                    if(tname=="tamsayi" || tname=="tamsayı") ok = (val.type==Value::Type::Number || val.type==Value::Type::Null);
                    else if(tname=="metin") ok = (val.type==Value::Type::String || val.type==Value::Type::Null);
                    else if(tname=="mantiksal" || tname=="mantıksal") ok = (val.type==Value::Type::Bool || val.type==Value::Type::Null);
                    if(!ok){ runtimeError("Field '" + field + "' type mismatch in " + base.obj->typeName); push(Value::makeNull()); break; }
                }

                base.obj->fields[field] = val;
                push(val);
                break;
            }

            case OpCode::RETURN: {
                Value ret = pop();
                frames.pop_back();
                if(frames.empty()){
                    // end of program
                    return !hadError;
                }
                // push return value to caller
                push(ret);
                break;
            }
        }
    }
    return !hadError;
}
