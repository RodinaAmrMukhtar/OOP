# Dil (Turkish-like language)

Bu sürümde dil; yorumlar, `sabit`, tipli fonksiyonlar, standart kütüphane bildirimi, sözlük benzeri nesne literal'i, dosya işlemleri ve basit REPL desteği içerir.

## Build

```bash
g++ -std=c++17 -O2 -Wall -Wextra *.cpp -o dil
```

## Çalıştırma

```bash
./dil examples/stdlib_demo.dil
```

Varsayılan çalıştırma artık **interpreter** üstünden yapılır. Bunun nedeni yeni dil özelliklerinin tamamının interpreter tarafında desteklenmesi. VM/disasm/trace tarafı hâlâ mevcut ama en yeni özelliklerin hepsini kapsamaz.

## REPL

```bash
./dil --repl
```

Çıkmak için:

```text
:cik
:quit
exit
quit
```

## Örnekler

```bash
./dil examples/girdi_demo.dil
./dil examples/stdlib_demo.dil
./dil examples/file_demo.dil
```

## Yorumlar

Hem eski hem yeni yorum stilleri desteklenir:

```dil
-- tek satır
// tek satır

{-
  çok satır
-}

/* çok satır */
```

## Sabitler

```dil
sabit tamsayi x = 5;
```

Sabit değişkenlere yeniden atama yapılamaz.

## Tipli fonksiyonlar

```dil
fonksiyon topla(tamsayi a, tamsayi b) -> tamsayi {
    döndür a + b;
}
```

## Sözlük literal'i

```dil
değişken kisi = sözlük{
    "ad": "Ayşe",
    yas: 20
};

yazdır kisi["ad"];
```

## Kütüphaneler

Bir built-in fonksiyonu kullanmadan önce ilgili kütüphaneyi açman gerekir:

```dil
mat_kütüphanesi kullanılıyor;
metin_kütüphanesi kullanılıyor;
dosya_kütüphanesi kullanılıyor;
rastgele_kütüphanesi kullanılıyor;
girdi_kütüphanesi kullanılıyor;
```

### Matematik

`mat_kütüphanesi`
- `sin`, `cos`, `tan`, `sqrt`, `pow`, `pi`

### Metin

`metin_kütüphanesi`
- `buyuk`
- `kucuk`
- `kirp`
- `degistir`
- `icerir`

### Dosya

`dosya_kütüphanesi`
- `dosya_oku`
- `dosya_yaz`
- `dosya_ekle`

### Rastgele

`rastgele_kütüphanesi`
- `rastgele`
- `rastgele_sec`

### Girdi

`girdi_kütüphanesi`
- `girdi`
- `girdi_sayi`
- `girdi_tamsayi`
- `guvenli_sayi_girdi`
- `guvenli_tamsayi_girdi`

Not: `girdi`, `girdi_sayi`, `girdi_tamsayi` eski örneklerle uyumluluk için çalışır; yeni yapıda bunları da girdi kütüphanesi altında düşünmek en temiz yaklaşımdır.

## Hata örneği

```dil
yazdır buyuk("merhaba");
```

Çıktı:

```text
Library error: 'buyuk' için önce 'metin_kütüphanesi kullanılıyor;' yazmalısın
```

## VM / Gelişmiş bayraklar

```bash
./dil examples/fib.dil --interp
./dil examples/fib.dil --both
./dil examples/fib.dil --disasm
./dil examples/fib.dil --trace
./dil examples/fib.dil --verify
./dil examples/fib.dil --bench 500 --compare
```

## Şu an neler var?

- Parser + AST
- Statik type checker
- Tree-walk interpreter
- Bytecode compiler + VM
- Disassembler
- VM trace
- Peephole optimizer
- Bytecode verifier
- `sabit`
- Tipli fonksiyonlar
- Kütüphane bildirimi (`kullanılıyor`)
- Metin / dosya / rastgele built-in'leri
- Sözlük literal'i
- Basit REPL

## Henüz tam yapılmayan büyük konu

`dene/yakala` tarzı tam hata yakalama sistemi bu pakete eklenmedi. O özellik parser + interpreter + VM kontrol akışını daha derinden değiştireceği için ayrı bir adım olarak yapmak daha doğru olur.
