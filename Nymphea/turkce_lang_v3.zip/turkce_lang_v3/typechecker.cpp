#include "typechecker.h"
#include "stdlib_registry.h"
#include <algorithm>

void TypeChecker::beginScope(){ scopes.push_back({}); }
void TypeChecker::endScope(){ if(!scopes.empty()) scopes.pop_back(); }
void TypeChecker::error(const std::string& msg){ errs.push_back(msg); }

bool TypeChecker::findVar(const std::string& name, VarInfo& out) const{
    for(int i=(int)scopes.size()-1;i>=0;--i){
        auto it = scopes[(size_t)i].find(name);
        if(it!=scopes[(size_t)i].end()){ out = it->second; return true; }
    }
    return false;
}

void TypeChecker::declareVar(const std::string& name, Ty t, bool isConst){
    if(scopes.empty()) beginScope();
    scopes.back()[name] = VarInfo{t,isConst};
}

TypeChecker::Ty TypeChecker::tyFromDeclared(const std::string& declared){
    if(declared=="tamsayi" || declared=="tamsayı") return Ty::Num();
    if(declared=="metin") return Ty::Str();
    if(declared=="mantiksal" || declared=="mantıksal") return Ty::Bool();
    if(declared.empty()) return Ty::Any();
    return Ty::Obj(declared);
}

bool TypeChecker::canAssign(const Ty& varT, const Ty& valT){
    if(varT.kind==Ty::Kind::Any || valT.kind==Ty::Kind::Any) return true;
    if(varT.kind==valT.kind){
        if(varT.kind==Ty::Kind::Object){
            if(varT.objName.empty() || valT.objName.empty()) return true;
            return varT.objName==valT.objName || varT.objName=="sozluk" || valT.objName=="sozluk";
        }
        return true;
    }
    if(varT.kind==Ty::Kind::Number && valT.kind==Ty::Kind::Null) return false;
    if(varT.kind==Ty::Kind::Object && valT.kind==Ty::Kind::Null) return true;
    return false;
}

void TypeChecker::requireMutable(const std::string& name, const std::string& what){
    VarInfo vi;
    if(findVar(name, vi) && vi.isConst) error("Type error: sabit değişken '"+name+"' için " + what + " yapılamaz");
}

TypeChecker::Ty TypeChecker::checkExpr(const Expr* e){
    if(!e) return Ty::Null();
    if(dynamic_cast<const ExprNull*>(e)) return Ty::Null();
    if(dynamic_cast<const ExprNumber*>(e)) return Ty::Num();
    if(dynamic_cast<const ExprString*>(e)) return Ty::Str();
    if(dynamic_cast<const ExprBool*>(e)) return Ty::Bool();
    if(dynamic_cast<const ExprArray*>(e)) return Ty::Arr();

    if(auto d=dynamic_cast<const ExprDict*>(e)){
        for(const auto& ent : d->entries) (void)checkExpr(ent.value.get());
        return Ty::Obj("sozluk");
    }

    if(auto st=dynamic_cast<const ExprStruct*>(e)){
        auto it = structDefs.find(st->typeName);
        if(it==structDefs.end()){
            error("Type error: unknown struct type: "+st->typeName);
            return Ty::Obj(st->typeName);
        }
        for(auto& f : st->fields){
            auto ft = it->second.fields.find(f.name);
            if(ft==it->second.fields.end()){
                error("Type error: unknown field '"+f.name+"' for struct "+st->typeName);
                continue;
            }
            Ty valT = checkExpr(f.value.get());
            if(!canAssign(ft->second, valT)) error("Type error: field '"+f.name+"' type mismatch in "+st->typeName);
        }
        return Ty::Obj(st->typeName);
    }

    if(auto v=dynamic_cast<const ExprVar*>(e)){
        VarInfo info;
        if(findVar(v->name, info)) return info.type;
        if(functions.find(v->name)!=functions.end()) return Ty::Func();
        if(std::find(allBuiltinNames().begin(), allBuiltinNames().end(), v->name)!=allBuiltinNames().end()){
            std::string req = builtinRequiredLibrary(v->name);
            if(!req.empty() && !libEnabled(enabledLibs, req))
                error("Library error: '"+v->name+"' için önce '" + preferredLibraryDisplayName(req) + " kullanılıyor;' yazmalısın");
            if(v->name=="pi") return Ty::Num();
            return Ty::Any();
        }
        return Ty::Any();
    }

    if(auto u=dynamic_cast<const ExprUnary*>(e)){
        Ty r = checkExpr(u->right.get());
        if(u->op=="-"){
            if(r.kind!=Ty::Kind::Any && r.kind!=Ty::Kind::Number) error("Type error: unary '-' needs number");
            return Ty::Num();
        }
        if(u->op=="degil" || u->op=="değil") return Ty::Bool();
        return Ty::Any();
    }

    if(auto b=dynamic_cast<const ExprBinary*>(e)){
        const std::string& op=b->op;
        Ty L=checkExpr(b->left.get());
        Ty R=checkExpr(b->right.get());
        if(op=="ve" || op=="veya") return Ty::Bool();
        if(op=="=="||op=="!="||op=="<"||op=="<="||op==">"||op==">=") return Ty::Bool();
        if(op=="+"){
            if(L.kind==Ty::Kind::String || R.kind==Ty::Kind::String) return Ty::Str();
            if(L.kind==Ty::Kind::Array && R.kind==Ty::Kind::Array) return Ty::Arr();
            return Ty::Num();
        }
        if(op=="-"||op=="*"||op=="/"||op=="%") return Ty::Num();
        return Ty::Any();
    }

    if(auto g=dynamic_cast<const ExprGet*>(e)){
        Ty base = checkExpr(g->obj.get());
        if(base.kind==Ty::Kind::Object && !base.objName.empty() && base.objName!="sozluk"){
            auto it = structDefs.find(base.objName);
            if(it!=structDefs.end()){
                auto ft = it->second.fields.find(g->field);
                if(ft==it->second.fields.end()){
                    error("Type error: '"+base.objName+"' has no field '"+g->field+"'");
                    return Ty::Any();
                }
                return ft->second;
            }
        }
        return Ty::Any();
    }

    if(auto ix=dynamic_cast<const ExprIndex*>(e)){
        Ty base = checkExpr(ix->base.get());
        Ty idx  = checkExpr(ix->index.get());
        if(base.kind==Ty::Kind::Array) return Ty::Any();
        if(base.kind==Ty::Kind::String) return Ty::Str();
        if(base.kind==Ty::Kind::Object){
            if(idx.kind!=Ty::Kind::Any && idx.kind!=Ty::Kind::String) error("Type error: object index must be string");
            return Ty::Any();
        }
        return Ty::Any();
    }

    if(auto call=dynamic_cast<const ExprCall*>(e)){
        if(auto cv=dynamic_cast<const ExprVar*>(call->callee.get())){
            auto fit = functions.find(cv->name);
            if(fit!=functions.end()){
                const FuncSig& sig = fit->second;
                if(sig.params.size()!=call->args.size()) error("Type error: function '"+cv->name+"' expects "+std::to_string(sig.params.size())+" arg(s)");
                size_t n = std::min(sig.params.size(), call->args.size());
                for(size_t i=0;i<n;++i){
                    Ty at = checkExpr(call->args[i].get());
                    if(!canAssign(sig.params[i], at)) error("Type error: argument "+std::to_string(i+1)+" mismatch in call to '"+cv->name+"'");
                }
                return sig.returnType;
            }

            std::string req = builtinRequiredLibrary(cv->name);
            if(!req.empty() && !libEnabled(enabledLibs, req)) error("Library error: '"+cv->name+"' için önce '" + preferredLibraryDisplayName(req) + " kullanılıyor;' yazmalısın");

            for(const auto& a : call->args) (void)checkExpr(a.get());

            if(cv->name=="pi" || cv->name=="sin" || cv->name=="cos" || cv->name=="tan" || cv->name=="sqrt" || cv->name=="karekok" || cv->name=="karekök" || cv->name=="pow" || cv->name=="us" || cv->name=="üs") return Ty::Num();
            if(cv->name=="buyuk" || cv->name=="büyük" || cv->name=="kucuk" || cv->name=="küçük" || cv->name=="kirp" || cv->name=="degistir" || cv->name=="değiştir") return Ty::Str();
            if(cv->name=="icerir" || cv->name=="içerir") return Ty::Bool();
            if(cv->name=="dosya_oku") return Ty::Str();
            if(cv->name=="dosya_yaz" || cv->name=="dosya_ekle") return Ty::Null();
            if(cv->name=="girdi" || cv->name=="oku") return Ty::Str();
            if(cv->name=="girdi_sayi" || cv->name=="girdi_sayı" || cv->name=="oku_sayi" || cv->name=="oku_sayı" || cv->name=="girdi_tamsayi" || cv->name=="girdi_tamsayı" || cv->name=="oku_tamsayi" || cv->name=="oku_tamsayı" || cv->name=="guvenli_sayi_girdi" || cv->name=="güvenli_sayı_girdi" || cv->name=="guvenli_tamsayi_girdi" || cv->name=="güvenli_tamsayı_girdi") return Ty::Num();
            if(cv->name=="metne") return Ty::Str();
            if(cv->name=="sayiya" || cv->name=="sayıya") return Ty::Num();
            if(cv->name=="mantiksala" || cv->name=="mantıksala") return Ty::Bool();
            if(cv->name=="aralik" || cv->name=="aralık" || cv->name=="range" || cv->name=="bol" || cv->name=="anahtarlar" || cv->name=="degerler" || cv->name=="değerler") return Ty::Arr();
            if(cv->name=="rastgele_sec" || cv->name=="rastgele_seç") return Ty::Any();
            return Ty::Any();
        }
        for(const auto& a : call->args) (void)checkExpr(a.get());
        return Ty::Any();
    }

    return Ty::Any();
}

void TypeChecker::checkStmt(const Stmt* s){
    if(!s) return;

    if(auto sd=dynamic_cast<const StmtStructDecl*>(s)){
        StructDef def;
        for(auto& f : sd->fields) def.fields[f.name] = tyFromDeclared(f.typeName);
        structDefs[sd->name]=std::move(def);
        return;
    }

    if(auto ul=dynamic_cast<const StmtUseLib*>(s)){
        if(!isKnownLibraryName(ul->libName)) error("Library error: unknown library '" + ul->libName + "'");
        else enabledLibs.insert(canonicalLibName(ul->libName));
        return;
    }

    if(auto fn=dynamic_cast<const StmtFunction*>(s)){
        auto prevName = currentFunctionName;
        auto prevRet = currentReturnType;
        currentFunctionName = fn->name;
        currentReturnType = tyFromDeclared(fn->returnType);
        beginScope();
        for(const auto& p : fn->params) declareVar(p.name, tyFromDeclared(p.typeName), false);
        checkStmt(fn->body.get());
        endScope();
        currentFunctionName = prevName;
        currentReturnType = prevRet;
        return;
    }

    if(auto vd=dynamic_cast<const StmtVarDecl*>(s)){
        Ty declared = tyFromDeclared(vd->declaredType);
        Ty initT = checkExpr(vd->init.get());
        if(!vd->declaredType.empty() && !canAssign(declared, initT)) error("Type error: initializer does not match declared type for '"+vd->name+"'");
        if(vd->declaredType.empty()) declared = initT.kind==Ty::Kind::Null ? Ty::Any() : initT;
        declareVar(vd->name, declared, vd->isConst);
        return;
    }

    if(auto as=dynamic_cast<const StmtAssign*>(s)){
        requireMutable(as->name, "atama");
        VarInfo info; Ty vT = checkExpr(as->value.get());
        if(!findVar(as->name, info)) error("Type error: assignment to undefined variable: "+as->name);
        else if(!canAssign(info.type, vT)) error("Type error: cannot assign to '"+as->name+"'");
        return;
    }

    if(auto aa=dynamic_cast<const StmtAugAssign*>(s)){
        requireMutable(aa->name, "güncelleme");
        VarInfo info; if(!findVar(aa->name, info)) error("Type error: aug-assign to undefined variable: "+aa->name);
        (void)checkExpr(aa->value.get());
        return;
    }

    if(auto si=dynamic_cast<const StmtSetIndex*>(s)){
        requireMutable(si->arrName, "indeks yazımı");
        VarInfo info;
        if(!findVar(si->arrName, info)) error("Type error: set index on undefined: "+si->arrName);
        else if(!(info.type.kind==Ty::Kind::Any || info.type.kind==Ty::Kind::Array || info.type.kind==Ty::Kind::Object)) error("Type error: set index requires array/object: "+si->arrName);
        (void)checkExpr(si->index.get());
        (void)checkExpr(si->value.get());
        return;
    }

    if(auto sf=dynamic_cast<const StmtSetField*>(s)){
        requireMutable(sf->objName, "alan yazımı");
        VarInfo info;
        if(!findVar(sf->objName, info)) error("Type error: set field on undefined: "+sf->objName);
        else if(info.type.kind==Ty::Kind::Object && !info.type.objName.empty() && info.type.objName!="sozluk"){
            auto it=structDefs.find(info.type.objName);
            if(it!=structDefs.end()){
                auto ft=it->second.fields.find(sf->field);
                if(ft==it->second.fields.end()) error("Type error: '"+info.type.objName+"' has no field '"+sf->field+"'");
                else if(!canAssign(ft->second, checkExpr(sf->value.get()))) error("Type error: field '"+sf->field+"' type mismatch in "+info.type.objName);
            }
        } else (void)checkExpr(sf->value.get());
        return;
    }

    if(auto fe=dynamic_cast<const StmtForeach*>(s)){
        Ty iterTy = checkExpr(fe->iterable.get());
        beginScope();
        if(fe->isPair){
            declareVar(fe->firstName, iterTy.kind==Ty::Kind::Object ? Ty::Str() : Ty::Num());
            declareVar(fe->secondName, Ty::Any());
        } else declareVar(fe->secondName, Ty::Any());
        checkStmt(fe->body.get());
        endScope();
        return;
    }

    if(auto pr=dynamic_cast<const StmtPrint*>(s)){ (void)checkExpr(pr->expr.get()); return; }
    if(auto es=dynamic_cast<const StmtExpr*>(s)){ (void)checkExpr(es->expr.get()); return; }
    if(auto bl=dynamic_cast<const StmtBlock*>(s)){ beginScope(); for(auto& st: bl->stmts) checkStmt(st.get()); endScope(); return; }
    if(auto iff=dynamic_cast<const StmtIf*>(s)){ (void)checkExpr(iff->cond.get()); checkStmt(iff->thenBranch.get()); if(iff->elseBranch) checkStmt(iff->elseBranch.get()); return; }
    if(auto wh=dynamic_cast<const StmtWhile*>(s)){ (void)checkExpr(wh->cond.get()); checkStmt(wh->body.get()); return; }
    if(auto dw=dynamic_cast<const StmtDoWhile*>(s)){ checkStmt(dw->body.get()); (void)checkExpr(dw->cond.get()); return; }
    if(auto fr=dynamic_cast<const StmtFor*>(s)){ beginScope(); if(fr->init) checkStmt(fr->init.get()); if(fr->cond) (void)checkExpr(fr->cond.get()); if(fr->step) checkStmt(fr->step.get()); checkStmt(fr->body.get()); endScope(); return; }
    if(auto sw=dynamic_cast<const StmtSwitch*>(s)){ (void)checkExpr(sw->expr.get()); for(auto& c : sw->cases){ (void)checkExpr(c.value.get()); beginScope(); for(auto& st: c.stmts) checkStmt(st.get()); endScope(); } beginScope(); for(auto& st: sw->defaultStmts) checkStmt(st.get()); endScope(); return; }
    if(auto rt=dynamic_cast<const StmtReturn*>(s)){
        Ty val = checkExpr(rt->value.get());
        if(!currentFunctionName.empty() && currentReturnType.kind!=Ty::Kind::Any && !canAssign(currentReturnType, val)) error("Type error: return type mismatch in function '"+currentFunctionName+"'");
        return;
    }
}

bool TypeChecker::check(const Program& program){
    errs.clear(); scopes.clear(); structDefs.clear(); functions.clear(); enabledLibs.clear(); currentFunctionName.clear(); currentReturnType = Ty::Any();

    for(auto& st : program.stmts){
        if(auto sd=dynamic_cast<const StmtStructDecl*>(st.get())){
            StructDef def;
            for(auto& f : sd->fields) def.fields[f.name] = tyFromDeclared(f.typeName);
            structDefs[sd->name]=std::move(def);
        }
    }

    for(auto& st : program.stmts){
        if(auto fn=dynamic_cast<const StmtFunction*>(st.get())){
            FuncSig sig;
            for(const auto& p : fn->params){ sig.params.push_back(tyFromDeclared(p.typeName)); sig.paramNames.push_back(p.name); }
            sig.returnTypeName = fn->returnType;
            sig.returnType = tyFromDeclared(fn->returnType);
            functions[fn->name] = std::move(sig);
        }
    }

    beginScope();
    for(auto& st : program.stmts) checkStmt(st.get());
    endScope();
    return errs.empty();
}
