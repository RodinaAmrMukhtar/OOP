#pragma once
#include "token.h"
#include "ast.h"
#include <string>
#include <vector>

class Parser {
public:
    Parser(const std::vector<Token>& tokens, const std::string& source);

    Program parseProgram();
    int errorCount() const { return errors; }

private:
    const std::vector<Token>& tokens;
    const std::string& source;
    std::vector<size_t> lineStarts;

    size_t pos = 0;
    int errors = 0;

    TokenType peekType() const;
    TokenType peekAhead(size_t off) const;
    const Token& peek() const;
    const Token& previous() const;
    const Token& consume();
    bool match(TokenType t);

    const Token& expect(TokenType t, const std::string& msg);
    void errorHere(const std::string& msg);
    void printCaretLine(const Token& tok);
    void synchronize();

    bool isTypeKw(TokenType t) const;
    std::string parseTypeName(const std::string& msg);

    std::unique_ptr<Stmt> parseStmt();
    std::unique_ptr<Stmt> parseBlock();
    std::unique_ptr<Stmt> parseStructDecl();
    std::unique_ptr<Stmt> parseVarDeclOrTypedDecl();
    std::unique_ptr<Stmt> parseAssignStmt();
    std::unique_ptr<Stmt> parseExprStmt();
    std::unique_ptr<Stmt> parsePrint();
    std::unique_ptr<Stmt> parseUseLib();
    std::unique_ptr<Stmt> parseIf();
    std::unique_ptr<Stmt> parseWhile();
    std::unique_ptr<Stmt> parseDoWhile();
    std::unique_ptr<Stmt> parseFor();
    std::unique_ptr<Stmt> parseForeach();
    std::unique_ptr<Stmt> parseBreak();
    std::unique_ptr<Stmt> parseContinue();
    std::unique_ptr<Stmt> parseReturn();
    std::unique_ptr<Stmt> parseSwitch();
    std::unique_ptr<Stmt> parseFunction();

    std::unique_ptr<Expr> parseExpression();
    std::unique_ptr<Expr> parseOr();
    std::unique_ptr<Expr> parseAnd();
    std::unique_ptr<Expr> parseEquality();
    std::unique_ptr<Expr> parseComparison();
    std::unique_ptr<Expr> parseTerm();
    std::unique_ptr<Expr> parseFactor();
    std::unique_ptr<Expr> parseUnary();
    std::unique_ptr<Expr> parseCall();
    std::unique_ptr<Expr> parsePrimary();
};
