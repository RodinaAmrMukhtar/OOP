#pragma once
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

struct Value;

struct Object {
    std::string typeName;
    std::unordered_map<std::string, Value> fields;
};

struct Chunk;

struct Function {
    std::string name;
    std::vector<std::string> params;
    std::vector<std::string> paramTypes;
    std::string returnType;
    const struct StmtBlock* body = nullptr;
    const Chunk* chunk = nullptr;
    bool isBytecode = false;
};

struct Value {
    enum class Type { Number, String, Bool, Null, Function, Array, Object } type = Type::Null;

    double number = 0.0;
    std::string str;
    bool boolean = false;
    Function* func = nullptr;
    std::shared_ptr<std::vector<Value>> arr;
    std::shared_ptr<Object> obj;

    static Value makeNumber(double x){ Value v; v.type=Type::Number; v.number=x; return v; }
    static Value makeString(std::string s){ Value v; v.type=Type::String; v.str=std::move(s); return v; }
    static Value makeBool(bool b){ Value v; v.type=Type::Bool; v.boolean=b; return v; }
    static Value makeNull(){ return Value{}; }
    static Value makeFunction(Function* f){ Value v; v.type=Type::Function; v.func=f; return v; }
    static Value makeArray(std::shared_ptr<std::vector<Value>> a){ Value v; v.type=Type::Array; v.arr=std::move(a); return v; }
    static Value makeObject(std::shared_ptr<Object> o){ Value v; v.type=Type::Object; v.obj=std::move(o); return v; }

    std::string typeName() const {
        switch(type){
            case Type::Number: return "sayi";
            case Type::String: return "metin";
            case Type::Bool: return "mantiksal";
            case Type::Null: return "bos";
            case Type::Function: return "fonksiyon";
            case Type::Array: return "dizi";
            case Type::Object: return obj && !obj->typeName.empty() ? obj->typeName : "yapi";
        }
        return "bos";
    }

    std::string toString() const {
        switch(type){
            case Type::Number: {
                std::string s = std::to_string(number);
                while(s.size()>1 && s.back()=='0') s.pop_back();
                if(!s.empty() && s.back()=='.') s.pop_back();
                return s;
            }
            case Type::String: return str;
            case Type::Bool: return boolean ? "dogru" : "yanlis";
            case Type::Null: return "bos";
            case Type::Function: return "<fonksiyon>";
            case Type::Array: {
                if(!arr) return "[]";
                std::string out="[";
                for(size_t i=0;i<arr->size();++i){ if(i) out += ", "; out += (*arr)[i].toString(); }
                out += "]";
                return out;
            }
            case Type::Object: {
                if(!obj) return "<yapi>";
                std::string out = obj->typeName.empty()?"sozluk":obj->typeName;
                out += "{";
                bool first=true;
                for(auto& kv : obj->fields){
                    if(!first) out += ", ";
                    first=false;
                    out += kv.first + ": " + kv.second.toString();
                }
                out += "}";
                return out;
            }
        }
        return "bos";
    }
};
