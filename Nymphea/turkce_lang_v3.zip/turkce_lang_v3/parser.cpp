#include "parser.h"
#include <cstdlib>
#include <iostream>

Parser::Parser(const std::vector<Token>& tokens, const std::string& source)
    : tokens(tokens), source(source) {
    lineStarts.clear();
    lineStarts.push_back(0);
    for(size_t i=0;i<source.size();++i) if(source[i]=='\n') lineStarts.push_back(i+1);
}

TokenType Parser::peekType() const { return pos>=tokens.size()?TokenType::EndOfFile:tokens[pos].type; }
TokenType Parser::peekAhead(size_t off) const { size_t p=pos+off; return p>=tokens.size()?TokenType::EndOfFile:tokens[p].type; }
const Token& Parser::peek() const { return tokens[pos]; }
const Token& Parser::previous() const { return tokens[pos-1]; }
const Token& Parser::consume(){ return tokens[pos++]; }
bool Parser::match(TokenType t){ if(peekType()==t){ consume(); return true; } return false; }

bool Parser::isTypeKw(TokenType t) const{
    return t==TokenType::KwTamsayi || t==TokenType::KwMetin || t==TokenType::KwMantiksal;
}

std::string Parser::parseTypeName(const std::string& msg){
    if(isTypeKw(peekType()) || peekType()==TokenType::Identifier) return consume().lexeme;
    errorHere(msg);
    return "";
}

void Parser::printCaretLine(const Token& tok){
    if(tok.line <= 0) return;
    int lineIdx = tok.line - 1;
    if(lineIdx < 0 || (size_t)lineIdx >= lineStarts.size()) return;
    size_t start = lineStarts[(size_t)lineIdx];
    size_t end = source.find('\n', start);
    if(end == std::string::npos) end = source.size();
    std::string lineText = source.substr(start, end-start);
    std::cerr << "    " << lineText << "\n";
    std::cerr << "    ";
    int caretPos = tok.col;
    if(caretPos < 1) caretPos = 1;
    for(int i=1;i<caretPos;i++) std::cerr << ' ';
    std::cerr << "^\n";
}

void Parser::errorHere(const std::string& msg){
    errors++;
    const Token& here = peek();
    std::cerr<<"Parse error "<<here.line<<":"<<here.col<<" -> "<<msg<<" | got ["<<here.lexeme<<"]\n";
    printCaretLine(here);
}

const Token& Parser::expect(TokenType t, const std::string& msg){
    if(peekType()!=t){ errorHere(msg); return peek(); }
    return consume();
}

void Parser::synchronize(){
    while(peekType()!=TokenType::EndOfFile){
        if(pos>0 && previous().type==TokenType::Semicolon) return;
        switch(peekType()){
            case TokenType::KwYapi:
            case TokenType::KwDegisken:
            case TokenType::KwSabit:
            case TokenType::KwYazdir:
            case TokenType::KwEger:
            case TokenType::KwIken:
            case TokenType::KwYap:
            case TokenType::KwIcin:
            case TokenType::KwHer:
            case TokenType::KwKir:
            case TokenType::KwDevam:
            case TokenType::KwDondur:
            case TokenType::KwSec:
            case TokenType::KwFonksiyon:
            case TokenType::LBrace:
            case TokenType::RBrace:
                return;
            default: break;
        }
        consume();
    }
}

Program Parser::parseProgram(){
    Program p;
    while(peekType()!=TokenType::EndOfFile){
        if(peekType()==TokenType::RBrace){ errorHere("Unexpected '}'"); consume(); continue; }
        if(peekType()==TokenType::Error){ errorHere("Lexer error token"); consume(); synchronize(); continue; }
        auto s=parseStmt();
        if(s) p.stmts.push_back(std::move(s)); else synchronize();
    }
    return p;
}

std::unique_ptr<Stmt> Parser::parseStmt(){
    switch(peekType()){
        case TokenType::LBrace: return parseBlock();
        case TokenType::KwYapi: return parseStructDecl();
        case TokenType::KwDegisken:
        case TokenType::KwSabit:
        case TokenType::KwTamsayi:
        case TokenType::KwMetin:
        case TokenType::KwMantiksal:
            return parseVarDeclOrTypedDecl();
        case TokenType::Identifier:
            if(peekAhead(1)==TokenType::KwKullaniliyor) return parseUseLib();
            if(peekAhead(1)==TokenType::Identifier && peekAhead(2)==TokenType::Equal) return parseVarDeclOrTypedDecl();
            if(peekAhead(1)==TokenType::LParen) return parseExprStmt();
            return parseAssignStmt();
        case TokenType::String:
            if(peekAhead(1)==TokenType::KwKullaniliyor) return parseUseLib();
            errorHere("String cannot start a statement");
            return nullptr;
        case TokenType::KwYazdir: return parsePrint();
        case TokenType::KwEger: return parseIf();
        case TokenType::KwIken: return parseWhile();
        case TokenType::KwYap: return parseDoWhile();
        case TokenType::KwIcin: return parseFor();
        case TokenType::KwHer: return parseForeach();
        case TokenType::KwKir: return parseBreak();
        case TokenType::KwDevam: return parseContinue();
        case TokenType::KwDondur: return parseReturn();
        case TokenType::KwSec: return parseSwitch();
        case TokenType::KwFonksiyon: return parseFunction();
        default:
            errorHere("Expected a statement");
            return nullptr;
    }
}

std::unique_ptr<Stmt> Parser::parseBlock(){
    expect(TokenType::LBrace,"Expected '{'");
    auto b=std::make_unique<StmtBlock>();
    while(peekType()!=TokenType::RBrace && peekType()!=TokenType::EndOfFile){
        auto s=parseStmt();
        if(s) b->stmts.push_back(std::move(s)); else synchronize();
    }
    expect(TokenType::RBrace,"Expected '}'");
    return b;
}

std::unique_ptr<Stmt> Parser::parseStructDecl(){
    consume();
    const Token& nameTok = expect(TokenType::Identifier, "Expected struct name after yapı");
    expect(TokenType::LBrace, "Expected '{' after struct name");
    std::vector<StructFieldDef> fields;
    while(peekType()!=TokenType::RBrace && peekType()!=TokenType::EndOfFile){
        std::string typeName = parseTypeName("Expected field type (tamsayı/metin/mantıksal or type name)");
        const Token& fieldName = expect(TokenType::Identifier, "Expected field name");
        expect(TokenType::Semicolon, "Expected ';' after field");
        fields.push_back({typeName, fieldName.lexeme});
    }
    expect(TokenType::RBrace, "Expected '}' to close struct");
    return std::make_unique<StmtStructDecl>(nameTok.lexeme, std::move(fields));
}

std::unique_ptr<Stmt> Parser::parseVarDeclOrTypedDecl(){
    bool isConst = false;
    std::string declaredType;

    if(match(TokenType::KwSabit)) isConst = true;

    if(isTypeKw(peekType())) declaredType = consume().lexeme;
    else if(peekType()==TokenType::Identifier && peekAhead(1)==TokenType::Identifier && peekAhead(2)==TokenType::Equal) declaredType = consume().lexeme;
    else if(match(TokenType::KwDegisken)) {}

    const Token& name=expect(TokenType::Identifier,"Expected variable name");
    expect(TokenType::Equal,"Expected '='");
    auto init=parseExpression();
    expect(TokenType::Semicolon,"Expected ';'");
    return std::make_unique<StmtVarDecl>(name.lexeme,std::move(init),declaredType,isConst);
}

std::unique_ptr<Stmt> Parser::parseAssignStmt(){
    const Token& name=expect(TokenType::Identifier,"Expected identifier");

    if(match(TokenType::LBracket)){
        auto idx=parseExpression();
        expect(TokenType::RBracket,"Expected ']'");
        expect(TokenType::Equal,"Expected '=' after index");
        auto v=parseExpression();
        expect(TokenType::Semicolon,"Expected ';'");
        return std::make_unique<StmtSetIndex>(name.lexeme,std::move(idx),std::move(v));
    }

    if(match(TokenType::Dot)){
        const Token& field=expect(TokenType::Identifier,"Expected field name");
        expect(TokenType::Equal,"Expected '=' after field");
        auto v=parseExpression();
        expect(TokenType::Semicolon,"Expected ';'");
        return std::make_unique<StmtSetField>(name.lexeme, field.lexeme, std::move(v));
    }

    if(peekType()==TokenType::PlusEqual || peekType()==TokenType::MinusEqual ||
       peekType()==TokenType::StarEqual || peekType()==TokenType::SlashEqual){
        Token op=consume();
        auto v=parseExpression();
        expect(TokenType::Semicolon,"Expected ';'");
        return std::make_unique<StmtAugAssign>(name.lexeme, op.lexeme, std::move(v));
    }

    expect(TokenType::Equal,"Expected '=' in assignment");
    auto v=parseExpression();
    expect(TokenType::Semicolon,"Expected ';'");
    return std::make_unique<StmtAssign>(name.lexeme,std::move(v));
}

std::unique_ptr<Stmt> Parser::parseExprStmt(){
    auto e = parseExpression();
    expect(TokenType::Semicolon, "Expected ';' after expression");
    return std::make_unique<StmtExpr>(std::move(e));
}

std::unique_ptr<Stmt> Parser::parsePrint(){
    consume();
    auto e=parseExpression();
    expect(TokenType::Semicolon,"Expected ';' after yazdır");
    return std::make_unique<StmtPrint>(std::move(e));
}

std::unique_ptr<Stmt> Parser::parseUseLib(){
    std::string lib;
    if(peekType()==TokenType::Identifier || peekType()==TokenType::String) lib = consume().lexeme;
    else { errorHere("Expected library name"); return nullptr; }
    expect(TokenType::KwKullaniliyor, "Expected 'kullanılıyor' after library name");
    expect(TokenType::Semicolon, "Expected ';' after kullanılıyor");
    return std::make_unique<StmtUseLib>(lib);
}

std::unique_ptr<Stmt> Parser::parseIf(){
    consume();
    expect(TokenType::LParen,"Expected '(' after eğer");
    auto cond=parseExpression();
    expect(TokenType::RParen,"Expected ')'");
    auto thenS=parseStmt();

    auto root = std::make_unique<StmtIf>(std::move(cond), std::move(thenS), nullptr);
    StmtIf* current = root.get();
    while(match(TokenType::KwYoksa)){
        if(match(TokenType::KwEger)){
            expect(TokenType::LParen,"Expected '(' after yoksa eğer");
            auto c=parseExpression();
            expect(TokenType::RParen,"Expected ')'");
            auto t=parseStmt();
            auto elifNode = std::make_unique<StmtIf>(std::move(c), std::move(t), nullptr);
            StmtIf* next = elifNode.get();
            current->elseBranch = std::move(elifNode);
            current = next;
            continue;
        } else {
            current->elseBranch = parseStmt();
            return root;
        }
    }
    if(match(TokenType::KwDegilse)) current->elseBranch = parseStmt();
    return root;
}

std::unique_ptr<Stmt> Parser::parseWhile(){
    consume();
    expect(TokenType::LParen,"Expected '(' after iken");
    auto cond=parseExpression();
    expect(TokenType::RParen,"Expected ')'");
    auto body=parseStmt();
    return std::make_unique<StmtWhile>(std::move(cond),std::move(body));
}

std::unique_ptr<Stmt> Parser::parseDoWhile(){
    consume();
    auto body=parseStmt();
    expect(TokenType::KwIken,"Expected 'iken' after yap body");
    expect(TokenType::LParen,"Expected '(' after iken");
    auto cond=parseExpression();
    expect(TokenType::RParen,"Expected ')'");
    expect(TokenType::Semicolon,"Expected ';' after do-while");
    return std::make_unique<StmtDoWhile>(std::move(body),std::move(cond));
}

std::unique_ptr<Stmt> Parser::parseFor(){
    consume();
    expect(TokenType::LParen,"Expected '(' after için");
    std::unique_ptr<Stmt> init;
    if(peekType()==TokenType::KwDegisken || peekType()==TokenType::KwSabit || isTypeKw(peekType()) ||
       (peekType()==TokenType::Identifier && peekAhead(1)==TokenType::Identifier && peekAhead(2)==TokenType::Equal)){
        init = parseVarDeclOrTypedDecl();
    } else if(peekType()==TokenType::Identifier){
        const Token& n=expect(TokenType::Identifier,"Expected identifier");
        if(peekType()==TokenType::PlusEqual || peekType()==TokenType::MinusEqual ||
           peekType()==TokenType::StarEqual || peekType()==TokenType::SlashEqual){
            Token op=consume();
            auto v=parseExpression();
            expect(TokenType::Semicolon,"Expected ';' in for init");
            init = std::make_unique<StmtAugAssign>(n.lexeme, op.lexeme, std::move(v));
        } else {
            expect(TokenType::Equal,"Expected '='");
            auto v=parseExpression();
            expect(TokenType::Semicolon,"Expected ';' in for init");
            init = std::make_unique<StmtAssign>(n.lexeme,std::move(v));
        }
    } else {
        expect(TokenType::Semicolon,"Expected ';' in for init");
    }
    std::unique_ptr<Expr> cond;
    if(peekType()!=TokenType::Semicolon) cond=parseExpression();
    expect(TokenType::Semicolon,"Expected ';' after for condition");
    std::unique_ptr<Stmt> step;
    if(peekType()!=TokenType::RParen){
        const Token& n=expect(TokenType::Identifier,"Expected identifier in for step");
        if(peekType()==TokenType::PlusEqual || peekType()==TokenType::MinusEqual ||
           peekType()==TokenType::StarEqual || peekType()==TokenType::SlashEqual){
            Token op=consume();
            auto v=parseExpression();
            step = std::make_unique<StmtAugAssign>(n.lexeme, op.lexeme, std::move(v));
        } else {
            expect(TokenType::Equal,"Expected '=' in for step");
            auto v=parseExpression();
            step = std::make_unique<StmtAssign>(n.lexeme,std::move(v));
        }
    }
    expect(TokenType::RParen,"Expected ')' after for header");
    auto body=parseStmt();
    return std::make_unique<StmtFor>(std::move(init),std::move(cond),std::move(step),std::move(body));
}

std::unique_ptr<Stmt> Parser::parseForeach(){
    consume();
    bool isPair=false;
    std::string first, second;
    if(match(TokenType::LParen)){
        isPair=true;
        const Token& a = expect(TokenType::Identifier, "Expected first name in her (a,b)");
        expect(TokenType::Comma, "Expected ',' in her (a,b)");
        const Token& b = expect(TokenType::Identifier, "Expected second name in her (a,b)");
        expect(TokenType::RParen, "Expected ')' after her (a,b)");
        first = a.lexeme; second = b.lexeme;
    } else {
        const Token& v = expect(TokenType::Identifier, "Expected foreach variable name");
        second = v.lexeme;
    }
    expect(TokenType::KwIcinde, "Expected 'içinde'");
    auto iterable = parseExpression();
    auto body = parseStmt();
    if(isPair) return std::make_unique<StmtForeach>(first, second, std::move(iterable), std::move(body));
    return std::make_unique<StmtForeach>(second, std::move(iterable), std::move(body));
}

std::unique_ptr<Stmt> Parser::parseBreak(){ consume(); expect(TokenType::Semicolon,"Expected ';' after kır"); return std::make_unique<StmtBreak>(); }
std::unique_ptr<Stmt> Parser::parseContinue(){ consume(); expect(TokenType::Semicolon,"Expected ';' after devam"); return std::make_unique<StmtContinue>(); }

std::unique_ptr<Stmt> Parser::parseReturn(){
    consume();
    std::unique_ptr<Expr> v;
    if(peekType()!=TokenType::Semicolon) v=parseExpression(); else v=std::make_unique<ExprNull>();
    expect(TokenType::Semicolon,"Expected ';' after döndür");
    return std::make_unique<StmtReturn>(std::move(v));
}

std::unique_ptr<Stmt> Parser::parseSwitch(){
    consume();
    expect(TokenType::LParen,"Expected '(' after seç");
    auto e=parseExpression();
    expect(TokenType::RParen,"Expected ')'");
    expect(TokenType::LBrace,"Expected '{' after seç(...)");

    auto sw=std::make_unique<StmtSwitch>();
    sw->expr=std::move(e);
    while(peekType()!=TokenType::RBrace && peekType()!=TokenType::EndOfFile){
        if(match(TokenType::KwDurum)){
            SwitchCase c;
            c.value=parseExpression();
            expect(TokenType::Colon,"Expected ':' after durum value");
            while(peekType()!=TokenType::KwDurum && peekType()!=TokenType::KwVarsayilan &&
                  peekType()!=TokenType::RBrace && peekType()!=TokenType::EndOfFile){
                auto st=parseStmt();
                if(st) c.stmts.push_back(std::move(st)); else synchronize();
            }
            sw->cases.push_back(std::move(c));
        } else if(match(TokenType::KwVarsayilan)){
            expect(TokenType::Colon,"Expected ':' after varsayılan");
            while(peekType()!=TokenType::KwDurum && peekType()!=TokenType::RBrace && peekType()!=TokenType::EndOfFile){
                auto st=parseStmt();
                if(st) sw->defaultStmts.push_back(std::move(st)); else synchronize();
            }
        } else {
            errorHere("Expected durum/varsayılan or '}' in switch");
            consume();
        }
    }
    expect(TokenType::RBrace,"Expected '}' to close switch");
    return sw;
}

std::unique_ptr<Stmt> Parser::parseFunction(){
    consume();
    const Token& name=expect(TokenType::Identifier,"Expected function name");
    expect(TokenType::LParen,"Expected '(' after function name");

    std::vector<FunctionParam> params;
    if(peekType()!=TokenType::RParen){
        while(true){
            FunctionParam fp;
            if((isTypeKw(peekType()) || peekType()==TokenType::Identifier) && peekAhead(1)==TokenType::Identifier){
                fp.typeName = consume().lexeme;
                fp.name = expect(TokenType::Identifier, "Expected parameter name").lexeme;
            } else {
                fp.name = expect(TokenType::Identifier, "Expected parameter name").lexeme;
            }
            params.push_back(fp);
            if(match(TokenType::Comma)) continue;
            break;
        }
    }
    expect(TokenType::RParen,"Expected ')' after params");

    std::string returnType;
    if(match(TokenType::Arrow)) returnType = parseTypeName("Expected return type after '->'");

    auto bodyStmt=parseBlock();
    auto bodyBlock = std::unique_ptr<StmtBlock>(dynamic_cast<StmtBlock*>(bodyStmt.release()));
    if(!bodyBlock){ errorHere("Function body must be a block"); bodyBlock = std::make_unique<StmtBlock>(); }
    return std::make_unique<StmtFunction>(name.lexeme,std::move(params),returnType,std::move(bodyBlock));
}

std::unique_ptr<Expr> Parser::parseExpression(){ return parseOr(); }
std::unique_ptr<Expr> Parser::parseOr(){ auto left=parseAnd(); while(match(TokenType::KwVeya)){ Token op=previous(); auto right=parseAnd(); left=std::make_unique<ExprBinary>(op.lexeme,std::move(left),std::move(right)); } return left; }
std::unique_ptr<Expr> Parser::parseAnd(){ auto left=parseEquality(); while(match(TokenType::KwVe)){ Token op=previous(); auto right=parseEquality(); left=std::make_unique<ExprBinary>(op.lexeme,std::move(left),std::move(right)); } return left; }
std::unique_ptr<Expr> Parser::parseEquality(){ auto left=parseComparison(); while(peekType()==TokenType::EqualEqual || peekType()==TokenType::BangEqual){ Token op=consume(); auto right=parseComparison(); left=std::make_unique<ExprBinary>(op.lexeme,std::move(left),std::move(right)); } return left; }
std::unique_ptr<Expr> Parser::parseComparison(){ auto left=parseTerm(); while(peekType()==TokenType::Less || peekType()==TokenType::LessEqual || peekType()==TokenType::Greater || peekType()==TokenType::GreaterEqual){ Token op=consume(); auto right=parseTerm(); left=std::make_unique<ExprBinary>(op.lexeme,std::move(left),std::move(right)); } return left; }
std::unique_ptr<Expr> Parser::parseTerm(){ auto left=parseFactor(); while(peekType()==TokenType::Plus || peekType()==TokenType::Minus){ Token op=consume(); auto right=parseFactor(); left=std::make_unique<ExprBinary>(op.lexeme,std::move(left),std::move(right)); } return left; }
std::unique_ptr<Expr> Parser::parseFactor(){ auto left=parseUnary(); while(peekType()==TokenType::Star || peekType()==TokenType::Slash || peekType()==TokenType::Percent){ Token op=consume(); auto right=parseUnary(); left=std::make_unique<ExprBinary>(op.lexeme,std::move(left),std::move(right)); } return left; }

std::unique_ptr<Expr> Parser::parseUnary(){
    if(peekType()==TokenType::Minus){ Token op=consume(); auto r=parseUnary(); return std::make_unique<ExprUnary>(op.lexeme,std::move(r)); }
    if(peekType()==TokenType::KwDegil){ Token op=consume(); auto r=parseUnary(); return std::make_unique<ExprUnary>(op.lexeme,std::move(r)); }
    return parseCall();
}

std::unique_ptr<Expr> Parser::parseCall(){
    auto expr=parsePrimary();
    while(true){
        if(match(TokenType::LParen)){
            std::vector<std::unique_ptr<Expr>> args;
            if(peekType()!=TokenType::RParen){ while(true){ args.push_back(parseExpression()); if(match(TokenType::Comma)) continue; break; } }
            expect(TokenType::RParen,"Expected ')'");
            expr = std::make_unique<ExprCall>(std::move(expr), std::move(args));
            continue;
        }
        if(match(TokenType::LBracket)){
            auto idx=parseExpression();
            expect(TokenType::RBracket,"Expected ']'");
            expr = std::make_unique<ExprIndex>(std::move(expr), std::move(idx));
            continue;
        }
        if(match(TokenType::Dot)){
            const Token& field=expect(TokenType::Identifier,"Expected field after '.'");
            expr = std::make_unique<ExprGet>(std::move(expr), field.lexeme);
            continue;
        }
        if(peekType()==TokenType::LBrace){
            auto* v = dynamic_cast<ExprVar*>(expr.get());
            if(!v) break;
            if(!( (peekAhead(1)==TokenType::Identifier || peekAhead(1)==TokenType::String) && peekAhead(2)==TokenType::Colon)) break;
            consume();
            if(v->name=="sozluk" || v->name=="sözlük"){
                auto d = std::make_unique<ExprDict>();
                while(true){
                    std::string key;
                    if(peekType()==TokenType::Identifier || peekType()==TokenType::String) key = consume().lexeme;
                    else { errorHere("Expected dictionary key"); break; }
                    expect(TokenType::Colon, "Expected ':' after dictionary key");
                    auto val = parseExpression();
                    d->entries.push_back({key, std::move(val)});
                    if(match(TokenType::Comma)) continue;
                    break;
                }
                expect(TokenType::RBrace, "Expected '}' to close dictionary");
                expr = std::move(d);
                continue;
            } else {
                std::vector<StructFieldInit> inits;
                while(true){
                    const Token& field = expect(TokenType::Identifier, "Expected field name in struct init");
                    expect(TokenType::Colon, "Expected ':' after field name");
                    auto val = parseExpression();
                    inits.push_back({field.lexeme, std::move(val)});
                    if(match(TokenType::Comma)) continue;
                    break;
                }
                expect(TokenType::RBrace, "Expected '}' to close struct init");
                auto st = std::make_unique<ExprStruct>();
                st->typeName = v->name;
                st->fields = std::move(inits);
                expr = std::move(st);
                continue;
            }
        }
        break;
    }
    return expr;
}

std::unique_ptr<Expr> Parser::parsePrimary(){
    if(match(TokenType::Number)){ const Token& t=previous(); return std::make_unique<ExprNumber>(std::strtod(t.lexeme.c_str(),nullptr)); }
    if(match(TokenType::String)){ const Token& t=previous(); return std::make_unique<ExprString>(t.lexeme); }
    if(match(TokenType::KwDogru)) return std::make_unique<ExprBool>(true);
    if(match(TokenType::KwYanlis)) return std::make_unique<ExprBool>(false);
    if(match(TokenType::KwBos)) return std::make_unique<ExprNull>();
    if(match(TokenType::Identifier)){ const Token& t=previous(); return std::make_unique<ExprVar>(t.lexeme); }
    if(match(TokenType::LBracket)){
        std::vector<std::unique_ptr<Expr>> elems;
        if(peekType()!=TokenType::RBracket){ while(true){ elems.push_back(parseExpression()); if(match(TokenType::Comma)) continue; break; } }
        expect(TokenType::RBracket,"Expected ']'");
        return std::make_unique<ExprArray>(std::move(elems));
    }
    if(match(TokenType::LParen)){
        auto inside=parseExpression();
        expect(TokenType::RParen,"Expected ')'");
        return inside;
    }
    errorHere("Expected expression");
    if(peekType()!=TokenType::EndOfFile) consume();
    return std::make_unique<ExprNull>();
}
