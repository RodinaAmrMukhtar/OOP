#pragma once
#include <string>

enum class TokenType {
    Identifier,
    Number,
    String,

    // keywords
    KwDegisken,
    KwSabit,
    KwYazdir,

    KwKullaniliyor,

    KwEger,
    KwDegilse,
    KwYoksa,
    KwIken,

    KwDogru,
    KwYanlis,
    KwBos,

    KwKir,
    KwDevam,

    KwFonksiyon,
    KwDondur,

    KwYap,
    KwIcin,
    KwHer,
    KwIcinde,

    KwSec,
    KwDurum,
    KwVarsayilan,

    KwYapi,

    KwVe,
    KwVeya,
    KwDegil,

    KwTamsayi,
    KwMetin,
    KwMantiksal,

    // operators / punctuation
    Equal,
    PlusEqual,
    MinusEqual,
    StarEqual,
    SlashEqual,
    Arrow,

    EqualEqual,
    BangEqual,
    Less,
    LessEqual,
    Greater,
    GreaterEqual,

    Semicolon,
    Comma,
    Colon,
    Dot,
    Plus, Minus, Star, Slash, Percent,
    LParen, RParen,
    LBrace, RBrace,
    LBracket, RBracket,

    EndOfFile,
    Error
};

struct Token {
    TokenType type{};
    std::string lexeme;
    int line = 1;
    int col  = 1;
};
