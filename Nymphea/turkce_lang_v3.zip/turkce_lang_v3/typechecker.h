#pragma once
#include "ast.h"
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

class TypeChecker {
public:
    bool check(const Program& program);
    int errorCount() const { return (int)errs.size(); }
    const std::vector<std::string>& errors() const { return errs; }

private:
    struct Ty {
        enum class Kind { Any, Number, String, Bool, Null, Array, Object, Function } kind = Kind::Any;
        std::string objName;
        static Ty Any(){ return Ty{Kind::Any, ""}; }
        static Ty Num(){ return Ty{Kind::Number, ""}; }
        static Ty Str(){ return Ty{Kind::String, ""}; }
        static Ty Bool(){ return Ty{Kind::Bool, ""}; }
        static Ty Null(){ return Ty{Kind::Null, ""}; }
        static Ty Arr(){ return Ty{Kind::Array, ""}; }
        static Ty Func(){ return Ty{Kind::Function, ""}; }
        static Ty Obj(std::string n){ Ty t; t.kind=Kind::Object; t.objName=std::move(n); return t; }
    };

    struct VarInfo { Ty type; bool isConst = false; };
    struct StructDef { std::unordered_map<std::string, Ty> fields; };
    struct FuncSig {
        std::vector<Ty> params;
        std::vector<std::string> paramNames;
        std::string returnTypeName;
        Ty returnType = Ty::Any();
    };

    std::vector<std::unordered_map<std::string, VarInfo>> scopes;
    std::unordered_map<std::string, StructDef> structDefs;
    std::unordered_map<std::string, FuncSig> functions;
    std::unordered_set<std::string> enabledLibs;
    std::vector<std::string> errs;
    std::string currentFunctionName;
    Ty currentReturnType = Ty::Any();

    void beginScope();
    void endScope();
    void error(const std::string& msg);

    bool findVar(const std::string& name, VarInfo& out) const;
    void declareVar(const std::string& name, Ty t, bool isConst=false);

    static Ty tyFromDeclared(const std::string& declared);
    static bool canAssign(const Ty& varT, const Ty& valT);

    Ty checkExpr(const Expr* e);
    void checkStmt(const Stmt* s);
    void requireMutable(const std::string& name, const std::string& what);
};
