#pragma once

#include "ast.h"
#include "value.h"

#include <cstdint>
#include <memory>
#include <ostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

// -------------------------
// Phase 5: Bytecode VM
// -------------------------

enum class OpCode : uint8_t {
    NOP,
    CONSTANT,
    NULLV,
    TRUEV,
    FALSEV,
    POP,

    GET_LOCAL,
    SET_LOCAL,

    GET_GLOBAL,
    DEFINE_GLOBAL,
    SET_GLOBAL,

    EQUAL,
    GREATER,
    LESS,
    GREATER_EQUAL,
    LESS_EQUAL,

    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE,
    MOD,

    NEGATE,
    NOT,
    IS_TRUTHY,

    PRINT,

    JUMP,
    JUMP_IF_FALSE,
    LOOP,

    CALL,
    CALL_BUILTIN,

    MAKE_ARRAY,
    INDEX_GET,
    INDEX_SET,

    STRUCT_DEF,
    MAKE_OBJECT,
    GET_FIELD,
    SET_FIELD,

    RETURN,
};

struct Chunk {
    std::vector<uint8_t> code;
    std::vector<int> lines;
    std::vector<Value> constants;

    int maxLocals = 0; // for function frames

    uint16_t addConstant(Value v);
    void write(uint8_t byte, int line);
    void writeU16(uint16_t x, int line);
};

struct BytecodeProgram {
    Function* main = nullptr;
    std::vector<std::unique_ptr<Chunk>> chunks;     // owns all chunks
    std::vector<std::unique_ptr<Function>> funcs;   // owns all function objects
};

class BytecodeCompiler {
public:
    explicit BytecodeCompiler(std::string source);
    BytecodeProgram compile(const Program& program);

private:
    struct Local {
        std::string name;
        int depth = 0;
        int slot = -1;
    };

    struct BreakableContext {
        enum class Kind { Loop, Switch } kind;
        int loopStart = -1;         // for loops
        int continueTarget = -1;    // for loops
        std::vector<int> breakJumps;
        std::vector<int> continueJumps; // loops only
    };

    std::string src;
    Chunk* current = nullptr;
    Function* currentFn = nullptr;
    bool inFunction = false; // false => script

    std::vector<Local> locals;
    int scopeDepth = 0;
    std::vector<BreakableContext> ctxStack;

    // allocation/lifetime
    BytecodeProgram out;

    // helpers
    uint16_t makeConst(Value v);
    uint16_t makeStringConst(const std::string& s);
    int currentOffset() const;

    void emit(OpCode op, int line);
    void emitByte(uint8_t b, int line);
    void emitU16(uint16_t x, int line);
    int emitJump(OpCode op, int line);   // returns patch position (offset to u16)
    void patchJump(int patchPos);
    void emitLoop(int loopStart, int line);

    void beginScope();
    void endScope();

    int resolveLocal(const std::string& name) const;
    void declareLocal(const std::string& name);

    void compileStmt(const Stmt* s);
    void compileExpr(const Expr* e);

    void compileBlock(const StmtBlock* b);
    void compileIf(const StmtIf* iff);
    void compileWhile(const StmtWhile* wh);
    void compileDoWhile(const StmtDoWhile* dw);
    void compileFor(const StmtFor* fr);
    void compileForeach(const StmtForeach* fe);
    void compileSwitch(const StmtSwitch* sw);

    Function* compileFunction(const StmtFunction* fn);

    // expression helpers
    void compileLogicalAnd(const ExprBinary* bin);
    void compileLogicalOr(const ExprBinary* bin);
    bool isBuiltinName(const std::string& name) const;
};



// Disassembler / Debug helpers
std::string opcodeName(OpCode op);
int instructionSize(const Chunk& c, int offset);
int disassembleInstruction(const Chunk& c, int offset, std::ostream& out);
void disassembleChunk(const Chunk& c, const std::string& name, std::ostream& out);
void disassembleProgram(const BytecodeProgram& p, std::ostream& out);

// Simple bytecode optimizer (peephole + jump threading)
struct BytecodeOptStats {
    int foldedConstants = 0;
    int removedPushPop = 0;
    int threadedJumps = 0;
    int removedNops = 0; // removed by compaction pass
};
BytecodeOptStats optimizeProgram(BytecodeProgram& p);

// Bytecode verifier
bool verifyProgram(const BytecodeProgram& p, std::vector<std::string>& errors);

struct VMOptions {
    bool trace = false;
    bool traceStack = true;
    bool traceCalls = true;
    bool dumpDisasmOnError = true;
    size_t maxTraceSteps = 0; // 0 = unlimited
};

class VM {
public:
    explicit VM(VMOptions opt = {});
    bool run(Function* entry);

    // VM state (globals & struct defs persist across calls)
    std::unordered_map<std::string, Value> globals;

    // enabled libraries (set by <lib> kullanılıyor;)
    std::unordered_set<std::string> enabledLibs;

private:
    struct StructDef {
        std::unordered_map<std::string, std::string> fieldTypes;
    };

    struct CallFrame {
        Function* fn = nullptr;
        const Chunk* chunk = nullptr;
        size_t ip = 0;
        std::vector<Value> locals;
    };

    std::vector<Value> stack;
    std::vector<CallFrame> frames;
    std::unordered_map<std::string, StructDef> structDefs;

    bool hadError = false;
    VMOptions options;
    size_t traceSteps = 0;
    const Chunk* lastChunk = nullptr;
    size_t lastInstOffset = 0;
    Function* lastFn = nullptr;

    // execution
    bool runLoop();
    void runtimeError(const std::string& msg);

    // stack helpers
    void push(Value v);
    Value pop();
    Value peek(int distance) const;

    // VM helpers
    bool isTruthy(const Value& v) const;
    bool valueEquals(const Value& a, const Value& b) const;

    // UTF-8 helpers
    static int utf8_codepoint_count(const std::string& s);
    static bool utf8_nth_codepoint(const std::string& s, int index, std::string& out);
    static bool utf8_substr(const std::string& s, int start, int count, std::string& out);

    // builtins
    bool isBuiltin(const std::string& name) const;
    Value callBuiltin(const std::string& name, const std::vector<Value>& args);

    // operations
    Value opAdd(const Value& a, const Value& b);
};
