#pragma once
#include "ast.h"
#include "value.h"
#include <memory>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

class Interpreter {
public:
    bool run(const Program& program);

private:
    enum class FlowKind { None, BreakLoop, ContinueLoop, Return, BreakSwitch };

    struct Flow {
        FlowKind kind = FlowKind::None;
        Value returnValue = Value::makeNull();

        static Flow none(){ return {}; }
        static Flow brLoop(){ Flow f; f.kind=FlowKind::BreakLoop; return f; }
        static Flow contLoop(){ Flow f; f.kind=FlowKind::ContinueLoop; return f; }
        static Flow brSwitch(){ Flow f; f.kind=FlowKind::BreakSwitch; return f; }

        static Flow makeReturn(Value v){
            Flow f;
            f.kind = FlowKind::Return;
            f.returnValue = v;
            return f;
        }
    };

    struct StructDef {
        std::unordered_map<std::string, std::string> fieldTypes; // field -> typeName (tamsayi/metin/mantiksal or other)
    };

    std::vector<std::unordered_map<std::string, Value>> scopes;
    std::unordered_map<std::string, std::unique_ptr<Function>> functions;
    std::unordered_map<std::string, StructDef> structDefs;
    std::unordered_set<std::string> enabledLibs;

    bool hadError = false;

    void runtimeError(const std::string& msg);

    void beginScope();
    void endScope();

    Value* findVar(const std::string& name);
    bool isTruthy(const Value& v) const;

    Value evalExpr(const Expr* e);
    Flow execStmt(const Stmt* s);

    Value callFunction(Function* fn, const std::vector<Value>& args);

    // builtins
    bool isBuiltin(const std::string& name) const;
    Value callBuiltin(const std::string& name, const std::vector<Value>& args);

    // helpers
    bool valueEquals(const Value& a, const Value& b) const;
};