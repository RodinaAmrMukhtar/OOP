#include "lexer.h"
#include "parser.h"
#include "ast_printer.h"
#include "interpreter.h"
#include "typechecker.h"
#include "bytecode_vm.h"

#include <cctype>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

Lexer::Lexer(std::string source) : src(std::move(source)) {}
bool Lexer::isAtEnd() const { return i >= src.size(); }
char Lexer::peek() const { return isAtEnd()?'\0':src[i]; }
char Lexer::peekNext() const { return (i+1>=src.size())?'\0':src[i+1]; }

char Lexer::advance(){
    if(isAtEnd()) return '\0';
    char c=src[i++];
    if(c=='\n'){ line++; col=1; } else col++;
    return c;
}

void Lexer::skipWhitespaceAndComments(){
    while(!isAtEnd()){
        char c=peek();
        if(c==' '||c=='\t'||c=='\r'||c=='\n'){ advance(); continue; }
        if(c=='-'&&peekNext()=='-'){ advance(); advance(); while(!isAtEnd()&&peek()!='\n') advance(); continue; }
        if(c=='/'&&peekNext()=='/'){ advance(); advance(); while(!isAtEnd()&&peek()!='\n') advance(); continue; }
        if(c=='{'&&peekNext()=='-'){
            advance(); advance();
            while(!isAtEnd()){
                if(peek()=='-'&&peekNext()=='}'){ advance(); advance(); break; }
                advance();
            }
            continue;
        }
        if(c=='/'&&peekNext()=='*'){
            advance(); advance();
            while(!isAtEnd()){
                if(peek()=='*'&&peekNext()=='/'){ advance(); advance(); break; }
                advance();
            }
            continue;
        }
        break;
    }
}

Token Lexer::make(TokenType type,const std::string& lex,int sl,int sc){
    Token t; t.type=type; t.lexeme=lex; t.line=sl; t.col=sc; return t;
}

Token Lexer::readNumber(){
    int sl=line, sc=col; size_t start=i;
    while(std::isdigit((unsigned char)peek())) advance();

    // optional fractional part
    if(peek()=='.' && std::isdigit((unsigned char)peekNext())){
        advance();
        while(std::isdigit((unsigned char)peek())) advance();
    }

    return make(TokenType::Number, src.substr(start,i-start), sl, sc);
}

Token Lexer::readString(){
    int sl=line, sc=col;
    advance(); // "
    std::string v;
    while(!isAtEnd() && peek()!='"'){
        char c=advance();
        if(c=='\\' && !isAtEnd()){
            char e=advance();
            if(e=='n') v.push_back('\n');
            else if(e=='t') v.push_back('\t');
            else if(e=='"') v.push_back('"');
            else if(e=='\\') v.push_back('\\');
            else v.push_back(e);
        } else v.push_back(c);
    }
    if(isAtEnd()) return make(TokenType::Error,"Unterminated string",sl,sc);
    advance(); // closing "
    return make(TokenType::String,v,sl,sc);
}

// UTF-8-friendly identifiers (simple)
Token Lexer::readWord(){
    int sl=line, sc=col; size_t start=i;
    auto isStart=[](unsigned char ch){ return std::isalpha(ch)||ch=='_'||ch>=0x80; };
    auto isCont=[](unsigned char ch){ return std::isalnum(ch)||ch=='_'||ch>=0x80; };

    if(isStart((unsigned char)peek())) advance();
    while(isCont((unsigned char)peek())) advance();

    std::string text=src.substr(start,i-start);

    static const std::unordered_map<std::string, TokenType> kw = {
        {"degisken",TokenType::KwDegisken}, {"değişken",TokenType::KwDegisken},
        {"sabit",TokenType::KwSabit},
        {"yazdir",TokenType::KwYazdir}, {"yazdır",TokenType::KwYazdir},

        {"kullaniliyor",TokenType::KwKullaniliyor}, {"kullanılıyor",TokenType::KwKullaniliyor},

        {"eger",TokenType::KwEger}, {"eğer",TokenType::KwEger},
        {"degilse",TokenType::KwDegilse}, {"değilse",TokenType::KwDegilse},
        {"yoksa",TokenType::KwYoksa},
        {"iken",TokenType::KwIken},

        {"dogru",TokenType::KwDogru}, {"doğru",TokenType::KwDogru},
        {"yanlis",TokenType::KwYanlis}, {"yanlış",TokenType::KwYanlis},
        {"bos",TokenType::KwBos}, {"boş",TokenType::KwBos},

        {"kir",TokenType::KwKir}, {"kır",TokenType::KwKir},
        {"devam",TokenType::KwDevam},

        {"fonksiyon",TokenType::KwFonksiyon},
        {"dondur",TokenType::KwDondur}, {"döndür",TokenType::KwDondur},

        {"yap",TokenType::KwYap},
        {"icin",TokenType::KwIcin}, {"için",TokenType::KwIcin},
        {"her",TokenType::KwHer},
        {"icinde",TokenType::KwIcinde}, {"içinde",TokenType::KwIcinde},

        {"sec",TokenType::KwSec}, {"seç",TokenType::KwSec},
        {"durum",TokenType::KwDurum},
        {"varsayilan",TokenType::KwVarsayilan}, {"varsayılan",TokenType::KwVarsayilan},

        {"yapi",TokenType::KwYapi}, {"yapı",TokenType::KwYapi},

        {"ve",TokenType::KwVe},
        {"veya",TokenType::KwVeya},
        {"degil",TokenType::KwDegil}, {"değil",TokenType::KwDegil},

        {"tamsayi",TokenType::KwTamsayi}, {"tamsayı",TokenType::KwTamsayi},
        {"metin",TokenType::KwMetin},
        {"mantiksal",TokenType::KwMantiksal}, {"mantıksal",TokenType::KwMantiksal},
    };

    auto it=kw.find(text);
    if(it!=kw.end()) return make(it->second,text,sl,sc);
    return make(TokenType::Identifier,text,sl,sc);
}

std::vector<Token> Lexer::tokenize(){
    std::vector<Token> out;
    while(!isAtEnd()){
        skipWhitespaceAndComments();
        if(isAtEnd()) break;
        int sl=line, sc=col;
        char c=peek();

        if(std::isdigit((unsigned char)c)){ out.push_back(readNumber()); continue; }
        if(std::isalpha((unsigned char)c) || c=='_' || (unsigned char)c>=0x80){ out.push_back(readWord()); continue; }
        if(c=='"'){ out.push_back(readString()); continue; }

        advance();

        // two-char ops
        if(c=='=' && peek()=='='){ advance(); out.push_back(make(TokenType::EqualEqual,"==",sl,sc)); continue; }
        if(c=='!' && peek()=='='){ advance(); out.push_back(make(TokenType::BangEqual,"!=",sl,sc)); continue; }
        if(c=='<' && peek()=='='){ advance(); out.push_back(make(TokenType::LessEqual,"<=",sl,sc)); continue; }
        if(c=='>' && peek()=='='){ advance(); out.push_back(make(TokenType::GreaterEqual,">=",sl,sc)); continue; }

        if(c=='+' && peek()=='='){ advance(); out.push_back(make(TokenType::PlusEqual,"+=",sl,sc)); continue; }
        if(c=='-' && peek()=='='){ advance(); out.push_back(make(TokenType::MinusEqual,"-=",sl,sc)); continue; }
        if(c=='-' && peek()=='>'){ advance(); out.push_back(make(TokenType::Arrow,"->",sl,sc)); continue; }
        if(c=='*' && peek()=='='){ advance(); out.push_back(make(TokenType::StarEqual,"*=",sl,sc)); continue; }
        if(c=='/' && peek()=='='){ advance(); out.push_back(make(TokenType::SlashEqual,"/=",sl,sc)); continue; }

        // single-char
        if(c=='=') out.push_back(make(TokenType::Equal,"=",sl,sc));
        else if(c=='<') out.push_back(make(TokenType::Less,"<",sl,sc));
        else if(c=='>') out.push_back(make(TokenType::Greater,">",sl,sc));
        else if(c==';') out.push_back(make(TokenType::Semicolon,";",sl,sc));
        else if(c==',') out.push_back(make(TokenType::Comma,",",sl,sc));
        else if(c==':') out.push_back(make(TokenType::Colon,":",sl,sc));
        else if(c=='.') out.push_back(make(TokenType::Dot,".",sl,sc));
        else if(c=='+') out.push_back(make(TokenType::Plus,"+",sl,sc));
        else if(c=='-') out.push_back(make(TokenType::Minus,"-",sl,sc));
        else if(c=='*') out.push_back(make(TokenType::Star,"*",sl,sc));
        else if(c=='/') out.push_back(make(TokenType::Slash,"/",sl,sc));
        else if(c=='%') out.push_back(make(TokenType::Percent,"%",sl,sc));
        else if(c=='(') out.push_back(make(TokenType::LParen,"(",sl,sc));
        else if(c==')') out.push_back(make(TokenType::RParen,")",sl,sc));
        else if(c=='{') out.push_back(make(TokenType::LBrace,"{",sl,sc));
        else if(c=='}') out.push_back(make(TokenType::RBrace,"}",sl,sc));
        else if(c=='[') out.push_back(make(TokenType::LBracket,"[",sl,sc));
        else if(c==']') out.push_back(make(TokenType::RBracket,"]",sl,sc));
        else out.push_back(make(TokenType::Error,std::string("Unexpected: ")+c,sl,sc));
    }
    out.push_back(make(TokenType::EndOfFile,"",line,col));
    return out;
}



static std::string readFile(const std::string& path){
    std::ifstream in(path, std::ios::binary);
    if(!in) throw std::runtime_error("Cannot open file: " + path);
    std::ostringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

static std::string demoProgram(){
    return R"(-- DEMO: yapı + foreach + builtins + sizeof/boyut

yapı Kisi {
  metin ad;
  tamsayı yas;
}

değişken k = Kisi{ ad: "Ali", yas: 20 };
yazdır k.ad;
k.yas = 21;
yazdır "yas=" + k.yas;

değişken dizi = [10, 20, 30];
her eleman içinde dizi {
  yazdır eleman;
}

her (i, eleman) içinde dizi {
  yazdır "i=" + i + ", v=" + eleman;
}

değişken s = "çağdaş";
her (i, ch) içinde s { yazdır i + ":" + ch; }

yazdır uzunluk(s);
yazdır boyut(s);

ekle(dizi, 99);
sil(dizi, 1);
yazdır birlestir(dizi, ",");
yazdır alt("İstanbul", 0, 4);
yazdır rastgele(1, 6);
)";
}

struct CliOptions {
    std::string file;
    bool printAst = false;
    bool disasm = false;
    bool trace = false;
    bool verify = false;
    bool optimize = true;
    bool interp = false;   // run tree-walk interpreter instead of VM
    bool both = false;     // run both (interp + VM) and compare outputs
    bool repl = false;     // basic cumulative REPL (interpreter)
    int bench = 0;         // 0 = off
    bool compare = false;  // compare VM vs tree-walk (with --bench)
};

static void printUsage(){
    std::cout
        << "Kullanim:\n"
        << "  dil [dosya.dil] [secenekler]\n\n"
        << "Secenekler:\n"
        << "  --ast           AST yazdir\n"
        << "  --disasm        Bytecode disassembler yazdir\n"
        << "  --trace         VM adim izleme (stack + instruction)\n"
        << "  --verify        Bytecode verifier calistir\n"
        << "  --interp        Interpreter (AST) modunda calistir\n"
        << "  --both          1 kez Interpreter + VM calistir, ciktiyi karsilastir\n"
        << "  --repl          Basit REPL (interpreter)\n"
        << "  --no-opt        Optimizer kapat\n"
        << "  --bench N       N kez calistir (VM benchmark)\n"
        << "  --compare       --bench ile beraber: VM vs Interpreter\n";
}

static CliOptions parseArgs(int argc, char** argv){
    CliOptions opt;
    for(int i=1;i<argc;i++){
        std::string a=argv[i];
        if(a=="-h"||a=="--help"){ printUsage(); std::exit(0); }
        else if(a=="--ast") opt.printAst=true;
        else if(a=="--disasm") opt.disasm=true;
        else if(a=="--trace") opt.trace=true;
        else if(a=="--verify") opt.verify=true;
        else if(a=="--interp") opt.interp=true;
        else if(a=="--both") opt.both=true;
        else if(a=="--repl") opt.repl=true;
        else if(a=="--no-opt") opt.optimize=false;
        else if(a=="--bench"){
            if(i+1>=argc) throw std::runtime_error("--bench needs N");
            opt.bench = std::stoi(argv[++i]);
            if(opt.bench < 1) opt.bench = 1;
        }
        else if(a=="--compare") opt.compare=true;
        else if(!a.empty() && a[0]=='-'){
            throw std::runtime_error("Unknown option: " + a);
        } else {
            opt.file = a;
        }
    }
    if(opt.both) opt.interp = false; // --both overrides --interp/VM selection
    return opt;
}

static int braceBalance(const std::string& src){
    int balance = 0;
    bool inString = false;
    bool escape = false;
    for(char c : src){
        if(inString){
            if(escape){ escape = false; continue; }
            if(c=='\\'){ escape = true; continue; }
            if(c=='"'){ inString = false; }
            continue;
        }
        if(c=='"'){ inString = true; continue; }
        if(c=='{') balance++;
        else if(c=='}') balance--;
    }
    return balance;
}

static bool looksComplete(const std::string& src){
    if(src.empty()) return false;
    if(braceBalance(src) > 0) return false;
    for(size_t i=src.size(); i>0; --i){
        unsigned char ch = (unsigned char)src[i-1];
        if(std::isspace(ch)) continue;
        return ch==';' || ch=='}';
    }
    return false;
}

static int runRepl(){
    std::cout << "Basit REPL. Cikmak icin :cik, :quit, exit veya quit yaz.\n";

    std::string history;
    for(;;){
        std::string chunk;
        std::string line;
        while(true){
            std::cout << (chunk.empty() ? "dil> " : "...> ");
            if(!std::getline(std::cin, line)) return 0;
            if(chunk.empty() && (line==":cik" || line==":quit" || line=="exit" || line=="quit")) return 0;
            chunk += line;
            chunk += '\n';
            if(looksComplete(chunk)) break;
        }

        std::string combined = history + chunk;
        Lexer lex(combined);
        auto tokens = lex.tokenize();
        Parser parser(tokens, combined);
        Program prog = parser.parseProgram();

        if(parser.errorCount()){
            std::cout << "[parser] hata sayisi: " << parser.errorCount() << "\n";
            continue;
        }

        TypeChecker tc;
        tc.check(prog);
        if(tc.errorCount()){
            std::cout << "[tip] hata sayisi: " << tc.errorCount() << "\n";
            for(const auto& e : tc.errors()) std::cout << "  " << e << "\n";
            continue;
        }

        Interpreter it;
        if(!it.run(prog)){
            std::cout << "[runtime] calistirma hatasi\n";
            continue;
        }

        history = std::move(combined);
    }
}



struct NullBuffer : std::streambuf {
    int overflow(int c) override { return c; }
};

struct CoutSilencer {
    NullBuffer nb;
    std::streambuf* old = nullptr;
    CoutSilencer() : old(std::cout.rdbuf(&nb)) {}
    ~CoutSilencer(){ if(old) std::cout.rdbuf(old); }
};

struct CoutCapture {
    std::ostringstream buffer;
    std::streambuf* old = nullptr;
    CoutCapture() : old(std::cout.rdbuf(buffer.rdbuf())) {}
    ~CoutCapture(){ if(old) std::cout.rdbuf(old); }
    std::string str() const { return buffer.str(); }
};

int main(int argc, char** argv){
    try{
        CliOptions opt = parseArgs(argc, argv);
        if(opt.repl) return runRepl();

        std::string program = opt.file.empty() ? demoProgram() : readFile(opt.file);

        Lexer lex(program);
        auto tokens = lex.tokenize();

        Parser parser(tokens, program);
        Program prog = parser.parseProgram();

        std::cout << "Parser errors: " << parser.errorCount() << "\n";

        TypeChecker tc;
        tc.check(prog);
        std::cout << "Type errors: " << tc.errorCount() << "\n";
        for(auto& e : tc.errors()) std::cout << "  " << e << "\n";

        if(opt.printAst){
            std::cout << "\n--- AST ---\n" << programToString(prog) << "\n";
        }

        if(parser.errorCount() || tc.errorCount()){
            std::cout << "\n--- RUN skipped due to errors ---\n";
            return 1;
        }

        // Interpreter-only mode (default unless VM/bytecode-specific flags are requested)
        if(opt.interp || (!opt.disasm && !opt.trace && !opt.verify && !opt.both && opt.bench==0)){
            std::cout << "\n--- RUN (INTERPRETER) ---\n";
            Interpreter it;
            bool ok = it.run(prog);
            return ok ? 0 : 1;
        }

        // Compile to bytecode
        BytecodeCompiler bc(program);
        BytecodeProgram bprog = bc.compile(prog);

        if(opt.optimize){
            BytecodeOptStats st = optimizeProgram(bprog);
            if(st.foldedConstants || st.removedPushPop || st.threadedJumps || st.removedNops){
                std::cout << "\n[opt] folded=" << st.foldedConstants
                          << " pushpop=" << st.removedPushPop
                          << " threadJumps=" << st.threadedJumps
                          << " removedNops=" << st.removedNops
                          << "\n";
            }
        }

        if(opt.verify){
            std::vector<std::string> errors;
            bool ok = verifyProgram(bprog, errors);
            if(ok) std::cout << "\n[verify] OK\n";
            else {
                std::cout << "\n[verify] FAIL\n";
                for(const auto& e : errors) std::cout << "  " << e << "\n";
                return 1;
            }
        }

        if(opt.disasm){
            std::cout << "\n--- BYTECODE ---\n";
            disassembleProgram(bprog, std::cout);
        }

        // Run both modes once and compare outputs
        if(opt.both){
            Interpreter it;
            VMOptions vopt;
            vopt.trace = false;
            VM vm(vopt);

            std::string outInterp;
            std::string outVm;

            {
                CoutCapture cap;
                it.run(prog);
                outInterp = cap.str();
            }
            {
                CoutCapture cap;
                vm.run(bprog.main);
                outVm = cap.str();
            }

            std::cout << "\n--- RUN (INTERPRETER) ---\n" << outInterp;
            std::cout << "\n--- RUN (VM) ---\n" << outVm;

            if(outInterp == outVm) std::cout << "\n[compare] OK: output identical\n";
            else std::cout << "\n[compare] DIFFERENT: outputs diverged\n";
            return 0;
        }

        // Benchmark mode
        if(opt.bench > 0){
            using clock = std::chrono::high_resolution_clock;

            auto benchVm=[&](){
                VMOptions vopt;
                vopt.trace = false;
                VM vm(vopt);
                auto t0=clock::now();
                int okCount=0;
                {
                    CoutSilencer silence;
                    for(int i=0;i<opt.bench;i++) if(vm.run(bprog.main)) okCount++;
                }
                auto t1=clock::now();
                auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count();
                std::cout << "\n[bench] VM runs=" << opt.bench << " ok=" << okCount << " time_ms=" << ms << "\n";
            };

            auto benchInterp=[&](){
                Interpreter it;
                auto t0=clock::now();
                int okCount=0;
                {
                    CoutSilencer silence;
                    for(int i=0;i<opt.bench;i++) if(it.run(prog)) okCount++;
                }
                auto t1=clock::now();
                auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(t1-t0).count();
                std::cout << "[bench] Interpreter runs=" << opt.bench << " ok=" << okCount << " time_ms=" << ms << "\n";
            };

            benchVm();
            if(opt.compare) benchInterp();
            return 0;
        }

        // Normal run
        std::cout << "\n--- RUN (VM) ---\n";
        VMOptions vopt;
        vopt.trace = opt.trace;
        VM vm(vopt);
        bool ok = vm.run(bprog.main);
        return ok ? 0 : 1;

    } catch(const std::exception& ex){
        std::cerr << "Error: " << ex.what() << "\n";
        return 1;
    }
}
