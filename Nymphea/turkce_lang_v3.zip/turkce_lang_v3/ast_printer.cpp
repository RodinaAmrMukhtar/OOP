#include "ast_printer.h"
#include <sstream>

static std::string numToStr(double x){ std::ostringstream o; o<<x; return o.str(); }

std::string exprToString(const Expr* e){
    if(!e) return "<null>";
    if(auto n=dynamic_cast<const ExprNumber*>(e)) return numToStr(n->value);
    if(auto s=dynamic_cast<const ExprString*>(e)) return "\""+s->value+"\"";
    if(auto b=dynamic_cast<const ExprBool*>(e)) return b->value?"dogru":"yanlis";
    if(dynamic_cast<const ExprNull*>(e)) return "bos";
    if(auto v=dynamic_cast<const ExprVar*>(e)) return v->name;
    if(auto a=dynamic_cast<const ExprArray*>(e)){
        std::string out="[";
        for(size_t i=0;i<a->elems.size();++i){ if(i) out += ", "; out += exprToString(a->elems[i].get()); }
        out += "]";
        return out;
    }
    if(auto d=dynamic_cast<const ExprDict*>(e)){
        std::string out = "sozluk{";
        for(size_t i=0;i<d->entries.size();++i){ if(i) out += ", "; out += d->entries[i].key + ": " + exprToString(d->entries[i].value.get()); }
        out += "}";
        return out;
    }
    if(auto st=dynamic_cast<const ExprStruct*>(e)){
        std::string out = st->typeName + "{";
        for(size_t i=0;i<st->fields.size();++i){ if(i) out += ", "; out += st->fields[i].name + ": " + exprToString(st->fields[i].value.get()); }
        out += "}";
        return out;
    }
    if(auto u=dynamic_cast<const ExprUnary*>(e)) return "("+u->op+" "+exprToString(u->right.get())+")";
    if(auto bin=dynamic_cast<const ExprBinary*>(e)) return "("+bin->op+" "+exprToString(bin->left.get())+" "+exprToString(bin->right.get())+")";
    if(auto g=dynamic_cast<const ExprGet*>(e)) return "(get "+exprToString(g->obj.get())+"."+g->field+")";
    if(auto ix=dynamic_cast<const ExprIndex*>(e)) return "(idx "+exprToString(ix->base.get())+" "+exprToString(ix->index.get())+")";
    if(auto c=dynamic_cast<const ExprCall*>(e)){
        std::string out="(call "+exprToString(c->callee.get());
        for(auto& a2:c->args) out+=" "+exprToString(a2.get());
        out+=")";
        return out;
    }
    return "<expr?>";
}

std::string stmtToString(const Stmt* s){
    if(!s) return "<null-stmt>";
    if(auto sd=dynamic_cast<const StmtStructDecl*>(s)){
        std::string out="Yapi "+sd->name+" {\n";
        for(auto& f: sd->fields) out += "  " + f.typeName + " " + f.name + ";\n";
        out += "}";
        return out;
    }
    if(auto vd=dynamic_cast<const StmtVarDecl*>(s)){
        std::string lead = vd->isConst ? "Sabit " : "VarDecl ";
        std::string t = vd->declaredType.empty() ? "" : (vd->declaredType+" ");
        return lead+t+vd->name+" = "+exprToString(vd->init.get());
    }
    if(auto as=dynamic_cast<const StmtAssign*>(s)) return "Assign "+as->name+" = "+exprToString(as->value.get());
    if(auto aa=dynamic_cast<const StmtAugAssign*>(s)) return "AugAssign "+aa->name+" "+aa->op+" "+exprToString(aa->value.get());
    if(auto si=dynamic_cast<const StmtSetIndex*>(s)) return "SetIndex "+si->arrName+"["+exprToString(si->index.get())+"] = "+exprToString(si->value.get());
    if(auto sf=dynamic_cast<const StmtSetField*>(s)) return "SetField "+sf->objName+"."+sf->field+" = "+exprToString(sf->value.get());
    if(auto ul=dynamic_cast<const StmtUseLib*>(s)) return "UseLib " + ul->libName;
    if(auto fe=dynamic_cast<const StmtForeach*>(s)){
        if(fe->isPair) return "Foreach ("+fe->firstName+", "+fe->secondName+") in "+exprToString(fe->iterable.get())+" "+stmtToString(fe->body.get());
        return "Foreach "+fe->secondName+" in "+exprToString(fe->iterable.get())+" "+stmtToString(fe->body.get());
    }
    if(auto pr=dynamic_cast<const StmtPrint*>(s)) return "Print "+exprToString(pr->expr.get());
    if(auto es=dynamic_cast<const StmtExpr*>(s)) return "ExprStmt "+exprToString(es->expr.get());
    if(dynamic_cast<const StmtBreak*>(s)) return "Break";
    if(dynamic_cast<const StmtContinue*>(s)) return "Continue";
    if(auto rt=dynamic_cast<const StmtReturn*>(s)) return "Return "+exprToString(rt->value.get());
    if(auto bl=dynamic_cast<const StmtBlock*>(s)){
        std::string out="Block{\n";
        for(auto& st: bl->stmts) out+="  "+stmtToString(st.get())+"\n";
        out+="}";
        return out;
    }
    if(auto iff=dynamic_cast<const StmtIf*>(s)){
        std::string out="If "+exprToString(iff->cond.get())+" then "+stmtToString(iff->thenBranch.get());
        if(iff->elseBranch) out+=" else "+stmtToString(iff->elseBranch.get());
        return out;
    }
    if(auto wh=dynamic_cast<const StmtWhile*>(s)) return "While "+exprToString(wh->cond.get())+" "+stmtToString(wh->body.get());
    if(auto dw=dynamic_cast<const StmtDoWhile*>(s)) return "Do "+stmtToString(dw->body.get())+" While "+exprToString(dw->cond.get());
    if(auto fr=dynamic_cast<const StmtFor*>(s)) return "For (...) "+stmtToString(fr->body.get());
    if(auto fn=dynamic_cast<const StmtFunction*>(s)){
        std::string out = "Fonksiyon "+fn->name+"(";
        for(size_t i=0;i<fn->params.size();++i){
            if(i) out += ", ";
            if(!fn->params[i].typeName.empty()) out += fn->params[i].typeName + " ";
            out += fn->params[i].name;
        }
        out += ")";
        if(!fn->returnType.empty()) out += " -> " + fn->returnType;
        out += " " + stmtToString(fn->body.get());
        return out;
    }
    if(dynamic_cast<const StmtSwitch*>(s)) return "Switch (...)";
    return "<stmt?>";
}

std::string programToString(const Program& p){
    std::string out;
    for(auto& st:p.stmts){ out+=stmtToString(st.get()); out+="\n"; }
    return out;
}
