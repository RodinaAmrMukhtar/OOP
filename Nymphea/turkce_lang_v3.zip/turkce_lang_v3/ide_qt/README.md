# Türkçe Dil IDE (Qt)

Bu klasör, **Phase 6** için modern görünümlü (VS Code tarzı) ama hâlâ basit bir IDE içerir:

- Editor (line numbers + tabs)
- Sol tarafta dosya gezgini (klasör aç / .dil dosyası çift tık)
- **Çalıştır (VM)**
- **Çalıştır (Interpreter)**
- **Çalıştır (İkisi + karşılaştır)**
- Opsiyonel: **Disasm** ve **Trace** toggle'ları (Bytecode/Trace paneline düşer)
- Output console (stdout + stderr)
- Problems list (Parse + Type) + çift tık ile satıra git
- Syntax highlighting (Türkçe keyword'ler)
- Dosya Aç / Kaydet / Farklı Kaydet

## 1) Önce dili derle (CLI)
Proje kökünde:

```bash
g++ -std=c++17 -O2 -Wall -Wextra *.cpp -o dil
```

> IDE, `dil` executable'ını otomatik bulmaya çalışır:
> - `ide_qt/build/dil`
> - `ide_qt/dil`
> - proje kökü `../../dil`
> - son çare: PATH

## 2) Qt6 kur (Ubuntu)

```bash
sudo apt update
sudo apt install -y qt6-base-dev qt6-tools-dev-tools cmake g++
```

## 3) IDE'yi derle

```bash
cd ide_qt
cmake -S . -B build
cmake --build build -j
```

Çalıştır:

```bash
./build/turkce_ide
```

## Qt5 kullanıyorsan
`CMakeLists.txt` içindeki `Qt6` satırlarını `Qt5` yapman yeterli:

- `find_package(Qt5 REQUIRED COMPONENTS Widgets)`
- `target_link_libraries(turkce_ide PRIVATE Qt5::Widgets)`

