#include "highlighter.h"

#include <QBrush>
#include <QColor>
#include <QRegularExpression>

static QTextCharFormat makeFmt(const QColor& c, bool bold=false, bool italic=false){
    QTextCharFormat f;
    f.setForeground(QBrush(c));
    if(bold) f.setFontWeight(QFont::Bold);
    f.setFontItalic(italic);
    return f;
}

TurkceHighlighter::TurkceHighlighter(QTextDocument* parent)
    : QSyntaxHighlighter(parent)
{
    // Simple readable theme (works in light/dark-ish palettes).
    const QTextCharFormat kwFmt   = makeFmt(QColor(60, 90, 160), true);
    const QTextCharFormat typeFmt = makeFmt(QColor(140, 60, 140), true);
    const QTextCharFormat litFmt  = makeFmt(QColor(30, 140, 110), true);
    const QTextCharFormat numFmt  = makeFmt(QColor(160, 90, 60));
    const QTextCharFormat strFmt  = makeFmt(QColor(180, 80, 80));
    commentFmt = makeFmt(QColor(120, 140, 120), false, true);

    auto add=[&](const QString& pattern, const QTextCharFormat& fmt){
        Rule r{QRegularExpression(pattern), fmt};
        rules.push_back(r);
    };

    // Keywords (include Turkish diacritics variants)
    const QString kw =
        "değişken|degisken|yazdır|yazdir|kullanılıyor|kullaniliyor|eğer|eger|değilse|degilse|yoksa|iken|"
        "kır|kir|devam|fonksiyon|döndür|dondur|yap|için|icin|her|içinde|icinde|"
        "seç|sec|durum|varsayılan|varsayilan|yapı|yapi|ve|veya|değil|degil";
    add(QStringLiteral("\\b(%1)\\b").arg(kw), kwFmt);

    // Types
    const QString ty = "tamsayı|tamsayi|metin|mantıksal|mantiksal";
    add(QStringLiteral("\\b(%1)\\b").arg(ty), typeFmt);

    // Literals
    const QString lit = "doğru|dogru|yanlış|yanlis|boş|bos";
    add(QStringLiteral("\\b(%1)\\b").arg(lit), litFmt);

    // Numbers
    add(QStringLiteral("\\b[0-9]+(?:\\.[0-9]+)?\\b"), numFmt);

    // Strings (simple; language supports escapes)
    add(QStringLiteral("\"([^\\\\\"]|\\\\.)*\""), strFmt);

    // Line comment: -- ...
    add(QStringLiteral("--[^\\n]*"), commentFmt);

    // Block comment: {- ... -}
    blockStart = QRegularExpression(QStringLiteral("\\{-[^\\n]*"));
    blockEnd   = QRegularExpression(QStringLiteral("-\\}"));
}

void TurkceHighlighter::highlightBlock(const QString& text){
    // Apply single-line rules first.
    for(const Rule& r : rules){
        auto it = r.re.globalMatch(text);
        while(it.hasNext()){
            auto m = it.next();
            setFormat(m.capturedStart(), m.capturedLength(), r.fmt);
        }
    }

    // Multi-line block comment handling.
    setCurrentBlockState(0);

    int start = 0;
    if(previousBlockState() != 1){
        auto m = blockStart.match(text);
        start = m.hasMatch() ? m.capturedStart() : -1;
    } else {
        start = 0;
    }

    while(start >= 0){
        auto mEnd = blockEnd.match(text, start);
        int end = mEnd.hasMatch() ? mEnd.capturedStart() : -1;
        int len;
        if(end >= 0){
            len = (end - start) + mEnd.capturedLength();
            setFormat(start, len, commentFmt);
            auto mNext = blockStart.match(text, start + len);
            start = mNext.hasMatch() ? mNext.capturedStart() : -1;
        } else {
            setCurrentBlockState(1);
            len = text.length() - start;
            setFormat(start, len, commentFmt);
            break;
        }
    }
}
