#include <QApplication>
#include <QPalette>
#include "mainwindow.h"

static void applyModernDarkTheme(QApplication& app){
    // Palette (basic dark)
    QPalette p;
    p.setColor(QPalette::Window, QColor(30, 31, 34));
    p.setColor(QPalette::WindowText, QColor(230, 230, 230));
    p.setColor(QPalette::Base, QColor(24, 25, 28));
    p.setColor(QPalette::AlternateBase, QColor(36, 38, 42));
    p.setColor(QPalette::Text, QColor(230, 230, 230));
    p.setColor(QPalette::Button, QColor(36, 38, 42));
    p.setColor(QPalette::ButtonText, QColor(230, 230, 230));
    p.setColor(QPalette::Highlight, QColor(67, 97, 238));
    p.setColor(QPalette::HighlightedText, QColor(255, 255, 255));
    app.setPalette(p);

    // QSS (VS Code-ish)
    app.setStyleSheet(R"(
        QMainWindow { background: #1e1f22; }
        QToolBar { background: #2b2d31; border: 0px; spacing: 6px; padding: 6px; }
        QToolButton { background: #3b3d44; border: 1px solid #3b3d44; border-radius: 6px; padding: 4px 8px; color: #e6e6e6; }
        QToolButton:hover { background: #4a4d57; border-color: #4a4d57; }
        QToolButton:checked { background: #4361ee; border-color: #4361ee; }

        QDockWidget { titlebar-close-icon: url(); titlebar-normal-icon: url(); }
        QDockWidget::title { background: #2b2d31; padding: 6px; }
        QDockWidget::close-button, QDockWidget::float-button { background: transparent; }

        QTabWidget::pane { border: 1px solid #2b2d31; }
        QTabBar::tab { background: #2b2d31; padding: 6px 10px; border-top-left-radius: 6px; border-top-right-radius: 6px; margin-right: 4px; }
        QTabBar::tab:selected { background: #1f2023; }

        QPlainTextEdit { background: #1e1f22; color: #e6e6e6; border: 1px solid #2b2d31; selection-background-color: #4361ee; }
        QTreeView { background: #1e1f22; border: 1px solid #2b2d31; }
        QTreeView::item:selected { background: #4361ee; }

        QTableWidget { background: #1e1f22; border: 1px solid #2b2d31; gridline-color: #2b2d31; }
        QHeaderView::section { background: #2b2d31; padding: 4px; border: 0px; }
        QStatusBar { background: #2b2d31; }
    )");
}

int main(int argc, char** argv){
    QApplication app(argc, argv);

    applyModernDarkTheme(app);

    MainWindow w;
    w.resize(1100, 750);
    w.show();

    return app.exec();
}
