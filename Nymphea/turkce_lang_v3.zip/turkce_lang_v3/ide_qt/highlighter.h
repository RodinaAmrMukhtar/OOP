#pragma once

#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QRegularExpression>
#include <QVector>

class TurkceHighlighter : public QSyntaxHighlighter {
    Q_OBJECT
public:
    explicit TurkceHighlighter(QTextDocument* parent);

protected:
    void highlightBlock(const QString& text) override;

private:
    struct Rule {
        QRegularExpression re;
        QTextCharFormat fmt;
    };

    QVector<Rule> rules;

    // block comment: {- ... -}
    QRegularExpression blockStart;
    QRegularExpression blockEnd;
    QTextCharFormat commentFmt;
};
