#include "mainwindow.h"

#include "codeeditor.h"
#include "highlighter.h"

#include <QAction>
#include <QApplication>
#include <QCoreApplication>
#include <QDockWidget>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFileSystemModel>
#include <QHeaderView>
#include <QLabel>
#include <QMessageBox>
#include <QPlainTextEdit>
#include <QRegularExpression>
#include <QStatusBar>
#include <QTabWidget>
#include <QTableWidget>
#include <QTemporaryDir>
#include <QTextBlock>
#include <QToolBar>
#include <QTreeView>

static QString readAllTextFile(const QString& path, QString* err){
    QFile f(path);
    if(!f.open(QIODevice::ReadOnly)){
        if(err) *err = f.errorString();
        return {};
    }
    return QString::fromUtf8(f.readAll());
}

static bool writeAllTextFile(const QString& path, const QString& text, QString* err){
    QFile f(path);
    if(!f.open(QIODevice::WriteOnly | QIODevice::Truncate)){
        if(err) *err = f.errorString();
        return false;
    }
    const QByteArray bytes = text.toUtf8();
    if(f.write(bytes) != bytes.size()){
        if(err) *err = QStringLiteral("Dosya yazma hatası");
        return false;
    }
    return f.flush();
}

static QString starterProgram(){
    return
        "fonksiyon fib(n) {\n"
        "  degisken a = 0;\n"
        "  degisken b = 1;\n"
        "  degisken i = 0;\n"
        "  iken (i < n) {\n"
        "    degisken t = a + b;\n"
        "    a = b;\n"
        "    b = t;\n"
        "    i += 1;\n"
        "  }\n"
        "  dondur a;\n"
        "}\n\n"
        "yazdir \"fib(10)=\" + fib(10);\n";
}

MainWindow::MainWindow(){
    setupUi();

    connect(&proc, &QProcess::readyRead, this, &MainWindow::onProcReadyRead);
    connect(&proc, QOverload<int,QProcess::ExitStatus>::of(&QProcess::finished),
            this, &MainWindow::onProcFinished);
    connect(&proc, &QProcess::errorOccurred, this, &MainWindow::onProcError);

    // initial tab
    onNewFile();
}

void MainWindow::setupUi(){
    setWindowTitle("Türkçe Dil IDE");

    // Toolbar
    auto* tb = addToolBar("Araçlar");
    tb->setMovable(false);

    QAction* actNew  = tb->addAction("Yeni");
    QAction* actOpen = tb->addAction("Aç");
    QAction* actOpenFolder = tb->addAction("Klasör Aç");
    QAction* actSave = tb->addAction("Kaydet");
    QAction* actSaveAs = tb->addAction("Farklı Kaydet");
    tb->addSeparator();

    QAction* actRunVM = tb->addAction("▶ VM");
    QAction* actRunInterp = tb->addAction("▶ Interpreter");
    QAction* actRunBoth = tb->addAction("▶ İkisi (Karşılaştır)");
    actStop = tb->addAction("■ Durdur");
    actStop->setEnabled(false);

    tb->addSeparator();
    actDisasm = tb->addAction("Disasm");
    actDisasm->setCheckable(true);
    actTrace = tb->addAction("Trace");
    actTrace->setCheckable(true);

    connect(actNew, &QAction::triggered, this, &MainWindow::onNewFile);
    connect(actOpen, &QAction::triggered, this, &MainWindow::onOpenFile);
    connect(actOpenFolder, &QAction::triggered, this, &MainWindow::onOpenFolder);
    connect(actSave, &QAction::triggered, this, &MainWindow::onSaveFile);
    connect(actSaveAs, &QAction::triggered, this, &MainWindow::onSaveFileAs);

    connect(actRunVM, &QAction::triggered, this, &MainWindow::onRunVM);
    connect(actRunInterp, &QAction::triggered, this, &MainWindow::onRunInterp);
    connect(actRunBoth, &QAction::triggered, this, &MainWindow::onRunBoth);
    connect(actStop, &QAction::triggered, this, &MainWindow::onStopRun);

    // Editors (center)
    editors = new QTabWidget();
    editors->setTabsClosable(true);
    editors->setMovable(true);
    connect(editors, &QTabWidget::tabCloseRequested, this, &MainWindow::onTabCloseRequested);
    setCentralWidget(editors);

    // Left dock: files
    filesDock = new QDockWidget("Dosyalar", this);
    filesDock->setAllowedAreas(Qt::LeftDockWidgetArea | Qt::RightDockWidgetArea);

    fsModel = new QFileSystemModel(this);
    fsModel->setRootPath(QDir::currentPath());
    fsModel->setFilter(QDir::AllDirs | QDir::Files | QDir::NoDotAndDotDot);

    fileTree = new QTreeView(filesDock);
    fileTree->setModel(fsModel);
    fileTree->setRootIndex(fsModel->index(projectRootGuess()));
    fileTree->setHeaderHidden(true);
    fileTree->setAnimated(true);
    fileTree->setIndentation(14);
    fileTree->setSortingEnabled(true);
    fileTree->sortByColumn(0, Qt::AscendingOrder);
    connect(fileTree, &QTreeView::doubleClicked, this, &MainWindow::onFileActivated);

    filesDock->setWidget(fileTree);
    addDockWidget(Qt::LeftDockWidgetArea, filesDock);

    // Bottom dock: panels
    panelDock = new QDockWidget("Panel", this);
    panelDock->setAllowedAreas(Qt::BottomDockWidgetArea);

    panelTabs = new QTabWidget(panelDock);
    outView = new QPlainTextEdit();
    outView->setReadOnly(true);
    outView->setPlaceholderText("Çıktı...");

    bytecodeView = new QPlainTextEdit();
    bytecodeView->setReadOnly(true);
    bytecodeView->setPlaceholderText("Bytecode / Disassembly...");

    traceView = new QPlainTextEdit();
    traceView->setReadOnly(true);
    traceView->setPlaceholderText("VM trace...");

    problems = new QTableWidget();
    problems->setColumnCount(4);
    problems->setHorizontalHeaderLabels({"Tür", "Satır", "Sütun", "Mesaj"});
    problems->horizontalHeader()->setStretchLastSection(true);
    problems->verticalHeader()->setVisible(false);
    problems->setSelectionBehavior(QAbstractItemView::SelectRows);
    problems->setEditTriggers(QAbstractItemView::NoEditTriggers);
    connect(problems, &QTableWidget::cellDoubleClicked, this, &MainWindow::onProblemActivated);

    panelTabs->addTab(outView, "Çıktı");
    panelTabs->addTab(bytecodeView, "Bytecode");
    panelTabs->addTab(traceView, "Trace");
    panelTabs->addTab(problems, "Problemler");

    panelDock->setWidget(panelTabs);
    addDockWidget(Qt::BottomDockWidgetArea, panelDock);

    // Status bar
    statusLabel = new QLabel("Hazır");
    statusBar()->addPermanentWidget(statusLabel);
}

void MainWindow::applyWindowTitle(){
    const QString path = currentFilePath();
    const QString name = path.isEmpty() ? QStringLiteral("(adsız)") : QFileInfo(path).fileName();
    setWindowTitle(QStringLiteral("Türkçe Dil IDE — %1").arg(name));
}

CodeEditor* MainWindow::currentEditor() const {
    return qobject_cast<CodeEditor*>(editors->currentWidget());
}

QString MainWindow::currentFilePath() const {
    if(!editors->currentWidget()) return {};
    return editors->currentWidget()->property("filePath").toString();
}

void MainWindow::setCurrentFilePath(const QString& path){
    if(!editors->currentWidget()) return;
    editors->currentWidget()->setProperty("filePath", path);
    const QString tabName = path.isEmpty() ? QStringLiteral("adsız.dil") : QFileInfo(path).fileName();
    editors->setTabText(editors->currentIndex(), tabName);
    editors->setTabToolTip(editors->currentIndex(), path);
    applyWindowTitle();
}

void MainWindow::onNewFile(){
    auto* ed = new CodeEditor();
    ed->setTabStopDistance(4 * ed->fontMetrics().horizontalAdvance(' '));
    ed->setPlainText(starterProgram());
    (void)new TurkceHighlighter(ed->document());

    const int idx = editors->addTab(ed, "adsız.dil");
    editors->setCurrentIndex(idx);
    ed->setProperty("filePath", QString());
    applyWindowTitle();
}

bool MainWindow::loadFileIntoNewTab(const QString& path, QString* err){
    const QString txt = readAllTextFile(path, err);
    if(txt.isNull()) return false;

    // if already open, focus it
    for(int i=0;i<editors->count();++i){
        const QString p = editors->widget(i)->property("filePath").toString();
        if(!p.isEmpty() && QFileInfo(p) == QFileInfo(path)){
            editors->setCurrentIndex(i);
            return true;
        }
    }

    auto* ed = new CodeEditor();
    ed->setTabStopDistance(4 * ed->fontMetrics().horizontalAdvance(' '));
    ed->setPlainText(txt);
    (void)new TurkceHighlighter(ed->document());

    const int idx = editors->addTab(ed, QFileInfo(path).fileName());
    editors->setCurrentIndex(idx);
    ed->setProperty("filePath", QFileInfo(path).canonicalFilePath());
    editors->setTabToolTip(idx, path);
    applyWindowTitle();
    return true;
}

void MainWindow::onOpenFile(){
    const QString path = QFileDialog::getOpenFileName(this, "Dosya Aç", QString(),
                                                      "Dil Dosyası (*.dil);;Tümü (*.*)");
    if(path.isEmpty()) return;
    QString err;
    if(!loadFileIntoNewTab(path, &err)){
        QMessageBox::critical(this, "Açılamadı", err);
    }
}

void MainWindow::onOpenFolder(){
    const QString dir = QFileDialog::getExistingDirectory(this, "Klasör Aç", projectRootGuess());
    if(dir.isEmpty()) return;
    fileTree->setRootIndex(fsModel->index(dir));
}

bool MainWindow::saveEditorToPath(CodeEditor* ed, const QString& path, QString* err){
    return writeAllTextFile(path, ed->toPlainText(), err);
}

void MainWindow::onSaveFile(){
    auto* ed = currentEditor();
    if(!ed) return;
    QString path = currentFilePath();
    if(path.isEmpty()){
        onSaveFileAs();
        return;
    }
    QString err;
    if(!saveEditorToPath(ed, path, &err)){
        QMessageBox::critical(this, "Kaydedilemedi", err);
    }
}

void MainWindow::onSaveFileAs(){
    auto* ed = currentEditor();
    if(!ed) return;

    QString suggested = currentFilePath();
    if(suggested.isEmpty()) suggested = QDir(projectRootGuess()).filePath("program.dil");

    QString path = QFileDialog::getSaveFileName(this, "Farklı Kaydet", suggested,
                                                "Dil Dosyası (*.dil);;Tümü (*.*)");
    if(path.isEmpty()) return;
    if(!path.endsWith(".dil", Qt::CaseInsensitive)) path += ".dil";

    QString err;
    if(!saveEditorToPath(ed, path, &err)){
        QMessageBox::critical(this, "Kaydedilemedi", err);
        return;
    }
    setCurrentFilePath(QFileInfo(path).canonicalFilePath());
}

void MainWindow::onFileActivated(const QModelIndex& idx){
    const QString path = fsModel->filePath(idx);
    if(path.isEmpty()) return;
    if(QFileInfo(path).isDir()) return;
    if(!path.endsWith(".dil", Qt::CaseInsensitive)) return;
    QString err;
    if(!loadFileIntoNewTab(path, &err)){
        QMessageBox::critical(this, "Açılamadı", err);
    }
}

void MainWindow::onTabCloseRequested(int index){
    QWidget* w = editors->widget(index);
    if(!w) return;
    editors->removeTab(index);
    w->deleteLater();
    if(editors->count() == 0) onNewFile();
    applyWindowTitle();
}

void MainWindow::onRunVM(){ startRun(RunMode::VM); }
void MainWindow::onRunInterp(){ startRun(RunMode::Interpreter); }
void MainWindow::onRunBoth(){ startRun(RunMode::Both); }

void MainWindow::onStopRun(){
    if(proc.state() == QProcess::NotRunning) return;
    proc.kill();
    statusLabel->setText("Durduruldu");
    actStop->setEnabled(false);
}

QString MainWindow::ensureTempSourceFile(){
    static QTemporaryDir* dir = nullptr;
    if(!dir){
        dir = new QTemporaryDir();
        dir->setAutoRemove(true);
    }
    return QDir(dir->path()).filePath("ide_run.dil");
}

QString MainWindow::projectRootGuess() const {
    // best effort: walk up from current dir and look for "dil" or "examples"
    QDir d(QDir::currentPath());
    for(int i=0;i<6;i++){
        if(QFileInfo(d.filePath("dil")).exists() || QFileInfo(d.filePath("dil.exe")).exists()) return d.absolutePath();
        if(QFileInfo(d.filePath("examples")).isDir()) return d.absolutePath();
        if(!d.cdUp()) break;
    }
    return QDir::currentPath();
}

QString MainWindow::findDilExecutable() const {
    const QString exeDir = QCoreApplication::applicationDirPath();

    auto existsExec = [](const QString& p){
        QFileInfo fi(p);
        return fi.exists() && fi.isFile() && fi.isExecutable();
    };

#ifdef Q_OS_WIN
    const QString name = "dil.exe";
#else
    const QString name = "dil";
#endif

    const QString p0 = QDir(exeDir).filePath(name);
    if(existsExec(p0)) return p0;

    const QString p1 = QDir(exeDir).filePath(QStringLiteral("../%1").arg(name));
    if(existsExec(p1)) return QFileInfo(p1).canonicalFilePath();

    const QString p2 = QDir(exeDir).filePath(QStringLiteral("../../%1").arg(name));
    if(existsExec(p2)) return QFileInfo(p2).canonicalFilePath();

    const QString p3 = QDir(exeDir).filePath(QStringLiteral("../../../%1").arg(name));
    if(existsExec(p3)) return QFileInfo(p3).canonicalFilePath();

    // last resort: PATH
    return name;
}

void MainWindow::clearPanelsForRun(){
    merged.clear();
    outView->clear();
    bytecodeView->clear();
    traceView->clear();
    clearProblems();
}

void MainWindow::startRun(RunMode mode){
    if(proc.state() != QProcess::NotRunning){
        QMessageBox::warning(this, "Çalışıyor", "Zaten bir işlem çalışıyor.");
        return;
    }

    auto* ed = currentEditor();
    if(!ed) return;

    clearPanelsForRun();

    // source path: saved file if exists, otherwise temp
    QString srcPath = currentFilePath();
    if(srcPath.isEmpty()) srcPath = ensureTempSourceFile();

    QString err;
    if(!writeAllTextFile(srcPath, ed->toPlainText(), &err)){
        QMessageBox::critical(this, "Dosya Hatası", "Kaydedilemedi: " + err);
        return;
    }

    const QString dilPath = findDilExecutable();
    QStringList args;
    args << srcPath;

    // advanced flags
    if(mode == RunMode::Interpreter){
        args << "--interp";
    } else if(mode == RunMode::Both){
        args << "--both";
    }
    if(actDisasm->isChecked()) args << "--disasm";
    if(actTrace->isChecked())  args << "--trace";

    // show command
    outView->appendPlainText(QString("$ %1 %2\n").arg(dilPath, args.join(' ')));

    currentRunMode = mode;
    statusLabel->setText("Çalışıyor...");
    actStop->setEnabled(true);

    proc.setProgram(dilPath);
    proc.setArguments(args);
    proc.setWorkingDirectory(projectRootGuess());
    proc.setProcessChannelMode(QProcess::MergedChannels);
    proc.start();
}

void MainWindow::onProcReadyRead(){
    const QByteArray data = proc.readAll();
    const QString text = QString::fromUtf8(data);
    merged += text;

    // stream to output live (but keep final parsing on finish)
    outView->moveCursor(QTextCursor::End);
    outView->insertPlainText(text);
}

void MainWindow::onProcFinished(int exitCode, QProcess::ExitStatus status){
    Q_UNUSED(status);
    actStop->setEnabled(false);

    // Re-parse merged output into panels (cleaner than raw stream)
    parseAndPopulatePanels(merged);

    if(exitCode == 0) statusLabel->setText("Bitti (OK)");
    else statusLabel->setText(QString("Bitti (exit=%1)").arg(exitCode));
}

void MainWindow::onProcError(QProcess::ProcessError err){
    if(err == QProcess::FailedToStart){
        actStop->setEnabled(false);
        statusLabel->setText("Başlatılamadı");
        outView->appendPlainText("\n[IDE] İşlem başlatılamadı: " + proc.errorString());
        outView->appendPlainText("[IDE] Çözüm: Proje kökünde 'g++ ... -o dil' ile derle ve IDE build klasöründen 2 seviye yukarıda olduğundan emin ol.");
    }
}

void MainWindow::clearProblems(){
    problems->setRowCount(0);
}

void MainWindow::addProblem(const QString& kind, int line, int col, const QString& msg){
    const int r = problems->rowCount();
    problems->insertRow(r);
    problems->setItem(r, 0, new QTableWidgetItem(kind));
    problems->setItem(r, 1, new QTableWidgetItem(line > 0 ? QString::number(line) : QString()));
    problems->setItem(r, 2, new QTableWidgetItem(col  > 0 ? QString::number(col)  : QString()));
    problems->setItem(r, 3, new QTableWidgetItem(msg));
}

void MainWindow::parseAndPopulatePanels(const QString& mergedText){
    // Reset views (but keep command line already printed at top)
    // We'll re-fill from parsed segments.
    const QString cmdPrefix = outView->toPlainText().split('\n').value(0);
    outView->clear();
    outView->appendPlainText(cmdPrefix + "\n");
    bytecodeView->clear();
    traceView->clear();
    clearProblems();

    QString remaining = mergedText;

    // Pull out BYTECODE section if present
    {
        const int bc = remaining.indexOf("--- BYTECODE ---");
        if(bc >= 0){
            const int run = remaining.indexOf("--- RUN", bc);
            const int end = (run >= 0) ? run : remaining.size();
            const QString bcText = remaining.mid(bc, end - bc).trimmed();
            bytecodeView->setPlainText(bcText);
            // remove from remaining
            remaining.remove(bc, end - bc);
        }
    }

    // If trace enabled, push lines starting with '[' into trace view
    {
        QStringList outLines;
        QStringList traceLines;
        const QStringList lines = remaining.split('\n');
        for(const QString& ln : lines){
            if(ln.startsWith('[')) traceLines << ln;
            else outLines << ln;
        }
        if(!traceLines.isEmpty()) traceView->setPlainText(traceLines.join('\n'));
        remaining = outLines.join('\n');
    }

    // Problems: parse typical messages
    // Parse errors: "Parse error line:col -> message"
    {
        const QRegularExpression re(R"(^Parse error\s+(\d+):(\d+)\s+->\s+(.*)$)");
        const QStringList lines = mergedText.split('\n');
        for(const QString& ln : lines){
            auto m = re.match(ln.trimmed());
            if(!m.hasMatch()) continue;
            addProblem("Parse", m.captured(1).toInt(), m.captured(2).toInt(), m.captured(3).trimmed());
        }
    }

    // Type errors: "Type error:" lines
    {
        const QStringList lines = mergedText.split('\n');
        for(const QString& ln : lines){
            const QString t = ln.trimmed();
            if(!t.startsWith("Type error:")) continue;
            addProblem("Type", 0, 0, t);
        }
    }

    // Output
    outView->appendPlainText(remaining.trimmed());

    // If we have problems, focus the Problems tab
    if(problems->rowCount() > 0){
        panelTabs->setCurrentWidget(problems);
    } else {
        panelTabs->setCurrentWidget(outView);
    }
}

void MainWindow::onProblemActivated(int row, int col){
    Q_UNUSED(col);
    auto* ed = currentEditor();
    if(!ed) return;

    bool okLine=false, okCol=false;
    const int line = problems->item(row, 1)->text().toInt(&okLine);
    const int c    = problems->item(row, 2)->text().toInt(&okCol);
    if(!okLine || line <= 0) return;

    QTextBlock block = ed->document()->findBlockByLineNumber(line-1);
    if(!block.isValid()) return;

    QTextCursor cur(block);
    if(okCol && c > 0) cur.movePosition(QTextCursor::Right, QTextCursor::MoveAnchor, c-1);
    ed->setTextCursor(cur);
    ed->setFocus();
}
