#pragma once

#include <QMainWindow>
#include <QProcess>
#include <QModelIndex>

class QAction;
class QDockWidget;
class QFileSystemModel;
class QLabel;
class QPlainTextEdit;
class QTableWidget;
class QTabWidget;
class QTreeView;

class CodeEditor;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow();

private slots:
    void onNewFile();
    void onOpenFile();
    void onOpenFolder();
    void onSaveFile();
    void onSaveFileAs();

    void onRunVM();
    void onRunInterp();
    void onRunBoth();
    void onStopRun();

    void onProcReadyRead();
    void onProcFinished(int exitCode, QProcess::ExitStatus status);
    void onProcError(QProcess::ProcessError err);

    void onFileActivated(const QModelIndex& idx);
    void onProblemActivated(int row, int col);
    void onTabCloseRequested(int index);

private:
    enum class RunMode { VM, Interpreter, Both };

    void setupUi();
    void applyWindowTitle();

    // Editors
    CodeEditor* currentEditor() const;
    QString currentFilePath() const;
    void setCurrentFilePath(const QString& path);
    bool loadFileIntoNewTab(const QString& path, QString* err);
    bool saveEditorToPath(CodeEditor* ed, const QString& path, QString* err);

    // Running
    void startRun(RunMode mode);
    QString findDilExecutable() const;
    QString ensureTempSourceFile();
    QString projectRootGuess() const;

    void clearPanelsForRun();
    void parseAndPopulatePanels(const QString& mergedText);
    void clearProblems();
    void addProblem(const QString& kind, int line, int col, const QString& msg);

private:
    // Main UI
    QTabWidget* editors = nullptr;

    // Left dock: file explorer
    QDockWidget* filesDock = nullptr;
    QFileSystemModel* fsModel = nullptr;
    QTreeView* fileTree = nullptr;

    // Bottom dock: output panels
    QDockWidget* panelDock = nullptr;
    QTabWidget* panelTabs = nullptr;
    QPlainTextEdit* outView = nullptr;
    QPlainTextEdit* bytecodeView = nullptr;
    QPlainTextEdit* traceView = nullptr;
    QTableWidget* problems = nullptr;
    QLabel* statusLabel = nullptr;

    // Actions
    QAction* actDisasm = nullptr;
    QAction* actTrace = nullptr;
    QAction* actStop  = nullptr;

    // Process
    QProcess proc;
    QString merged;
    RunMode currentRunMode = RunMode::VM;
};
