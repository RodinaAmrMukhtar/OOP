#include "interpreter.h"
#include "stdlib_registry.h"
#include <cmath>
#include <algorithm>
#include <cctype>
#include <iostream>
#include <fstream>
#include <random>
#include <sstream>
#include <stdexcept>


void Interpreter::runtimeError(const std::string& msg){
    hadError=true;
    std::cerr<<"Runtime error: "<<msg<<"\n";
}

void Interpreter::beginScope(){ scopes.push_back({}); }
void Interpreter::endScope(){ if(!scopes.empty()) scopes.pop_back(); }

Value* Interpreter::findVar(const std::string& name){
    for(int i=(int)scopes.size()-1;i>=0;--i){
        auto& m=scopes[(size_t)i];
        auto it=m.find(name);
        if(it!=m.end()) return &it->second;
    }
    return nullptr;
}

bool Interpreter::isTruthy(const Value& v) const{
    switch(v.type){
        case Value::Type::Bool:   return v.boolean;
        case Value::Type::Null:   return false;
        case Value::Type::Number: return v.number!=0.0;
        case Value::Type::String: return !v.str.empty();
        case Value::Type::Function: return true;
        case Value::Type::Array:  return v.arr && !v.arr->empty();
        case Value::Type::Object: return (bool)v.obj;
    }
    return false;
}

// ---------- UTF-8 helpers (codepoint-based) ----------
static bool utf8_next(const std::string& s, size_t& pos, size_t& len){
    if(pos >= s.size()) return false;
    unsigned char c = (unsigned char)s[pos];
    if((c & 0x80) == 0x00) len = 1;
    else if((c & 0xE0) == 0xC0) len = 2;
    else if((c & 0xF0) == 0xE0) len = 3;
    else if((c & 0xF8) == 0xF0) len = 4;
    else return false;
    if(pos + len > s.size()) return false;
    return true;
}

static int utf8_codepoint_count(const std::string& s){
    size_t pos=0, len=0;
    int count=0;
    while(pos < s.size()){
        if(!utf8_next(s,pos,len)) return -1;
        pos += len;
        count++;
    }
    return count;
}

static bool utf8_nth_codepoint(const std::string& s, int index, std::string& out){
    int n = utf8_codepoint_count(s);
    if(n < 0) return false;
    if(index < 0) index = n + index; // allow negative indexing
    if(index < 0 || index >= n) return false;

    size_t pos=0, len=0;
    int cur=0;
    while(pos < s.size()){
        if(!utf8_next(s,pos,len)) return false;
        if(cur == index){
            out = s.substr(pos, len);
            return true;
        }
        pos += len;
        cur++;
    }
    return false;
}

static bool utf8_substr(const std::string& s, int start, int count, std::string& out){
    int n = utf8_codepoint_count(s);
    if(n < 0) return false;

    if(start < 0) start = n + start;
    if(start < 0) start = 0;
    if(start > n) start = n;

    if(count < 0) count = 0;
    int end = start + count;
    if(end > n) end = n;

    // get byte pos for start/end
    size_t pos=0, len=0;
    int cur=0;
    size_t byteStart=0, byteEnd=0;
    bool gotStart=false, gotEnd=false;

    while(pos < s.size()){
        if(!utf8_next(s,pos,len)) return false;

        if(cur == start && !gotStart){ byteStart = pos; gotStart=true; }
        if(cur == end && !gotEnd){ byteEnd = pos; gotEnd=true; break; }

        pos += len;
        cur++;
    }

    if(!gotStart) byteStart = s.size();
    if(!gotEnd) byteEnd = s.size();

    if(byteEnd < byteStart) byteEnd = byteStart;
    out = s.substr(byteStart, byteEnd - byteStart);
    return true;
}

// ---------- equality ----------
bool Interpreter::valueEquals(const Value& a, const Value& b) const{
    if(a.type != b.type) return false;
    switch(a.type){
        case Value::Type::Null: return true;
        case Value::Type::Number: return a.number == b.number;
        case Value::Type::String: return a.str == b.str;
        case Value::Type::Bool: return a.boolean == b.boolean;
        case Value::Type::Function: return a.func == b.func;
        case Value::Type::Array: return a.arr == b.arr;
        case Value::Type::Object: return a.obj == b.obj;
    }
    return false;
}

// ---------- function calls ----------
Value Interpreter::callFunction(Function* fn, const std::vector<Value>& args){
    if(!fn || !fn->body){
        runtimeError("Invalid function");
        return Value::makeNull();
    }

    beginScope();
    for(size_t i=0;i<fn->params.size();++i){
        Value val = (i<args.size()) ? args[i] : Value::makeNull();
        scopes.back()[fn->params[i]] = val;
    }
    Flow f = execStmt(fn->body);
    endScope();
    if(f.kind==FlowKind::Return) return f.returnValue;
    return Value::makeNull();
}

// ---------- builtins ----------
bool Interpreter::isBuiltin(const std::string& name) const{
    static const auto names = allBuiltinNames();
    return std::find(names.begin(), names.end(), name) != names.end();
}

Value Interpreter::callBuiltin(const std::string& name, const std::vector<Value>& args){
    // internal: enable libraries
    if(name=="__kullaniliyor"){
        if(args.size()!=1 || args[0].type!=Value::Type::String){
            runtimeError("__kullaniliyor(lib) expects 1 string");
            return Value::makeNull();
        }
        enabledLibs.insert(canonicalLibName(args[0].str));
        return Value::makeNull();
    }


    // len/uzunluk: now UTF-8 codepoint length for strings
    if(name=="len" || name=="uzunluk"){
        if(args.size()!=1){ runtimeError("uzunluk(x) expects 1 arg"); return Value::makeNull(); }
        const Value& x=args[0];
        if(x.type==Value::Type::String){
            int n = utf8_codepoint_count(x.str);
            if(n < 0){ runtimeError("uzunluk: invalid utf-8"); return Value::makeNull(); }
            return Value::makeNumber((double)n);
        }
        if(x.type==Value::Type::Array)  return Value::makeNumber(x.arr ? (double)x.arr->size() : 0.0);
        if(x.type==Value::Type::Object) return Value::makeNumber(x.obj ? (double)x.obj->fields.size() : 0.0);
        runtimeError("uzunluk: unsupported type");
        return Value::makeNull();
    }

    if(name=="tip"){
        if(args.size()!=1){ runtimeError("tip(x) expects 1 arg"); return Value::makeNull(); }
        return Value::makeString(args[0].typeName());
    }

    // sizeof/boyut: "rough size" (bytes-ish for primitives; count for collections)
    if(name=="sizeof" || name=="boyut"){
        if(args.size()!=1){ runtimeError("boyut(x) expects 1 arg"); return Value::makeNull(); }
        const Value& x=args[0];
        switch(x.type){
            case Value::Type::Null: return Value::makeNumber(0);
            case Value::Type::Bool: return Value::makeNumber(1);
            case Value::Type::Number: return Value::makeNumber(8);
            case Value::Type::String: return Value::makeNumber((double)x.str.size()); // bytes
            case Value::Type::Function: return Value::makeNumber(8);
            case Value::Type::Array: return Value::makeNumber(x.arr ? (double)x.arr->size() : 0.0);
            case Value::Type::Object: return Value::makeNumber(x.obj ? (double)x.obj->fields.size() : 0.0);
        }
    }

    // range/aralik -> returns array [a..b-1]
    if(name=="aralik" || name=="aralık" || name=="range"){
        if(args.size()!=2){ runtimeError("aralik(a,b) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Number || args[1].type!=Value::Type::Number){
            runtimeError("aralik: args must be numbers");
            return Value::makeNull();
        }
        int a=(int)args[0].number;
        int b=(int)args[1].number;
        auto vec = std::make_shared<std::vector<Value>>();
        for(int i=a;i<b;i++) vec->push_back(Value::makeNumber(i));
        return Value::makeArray(vec);
    }

    // yaz(x): print without newline (or you can change to newline if you want)
    if(name=="yaz"){
        if(args.size()!=1){ runtimeError("yaz(x) expects 1 arg"); return Value::makeNull(); }
        std::cout << args[0].toString();
        return Value::makeNull();
    }

    // oku/girdi([prompt]): read a line from stdin (optional prompt)
    if(name=="oku" || name=="girdi"){
        if(args.size()>1){ runtimeError("oku([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(args.size()==1) std::cout << args[0].toString();
        std::string line;
        std::getline(std::cin, line);
        return Value::makeString(line);
    }

    // oku_sayi/girdi_sayi([prompt]): read a number
    if(name=="oku_sayi" || name=="oku_sayı" || name=="girdi_sayi" || name=="girdi_sayı"){
        if(args.size()>1){ runtimeError("oku_sayi([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(args.size()==1) std::cout << args[0].toString();
        std::string line;
        std::getline(std::cin, line);
        try{
            double v = std::stod(line);
            return Value::makeNumber(v);
        } catch(...){
            runtimeError("oku_sayi: not a number");
            return Value::makeNull();
        }
    }

    // oku_tamsayi/girdi_tamsayi([prompt]): read an integer
    if(name=="oku_tamsayi" || name=="oku_tamsayı" || name=="girdi_tamsayi" || name=="girdi_tamsayı"){
        if(args.size()>1){ runtimeError("oku_tamsayi([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(args.size()==1) std::cout << args[0].toString();
        std::string line;
        std::getline(std::cin, line);
        try{
            long long v = std::stoll(line);
            return Value::makeNumber((double)v);
        } catch(...){
            runtimeError("oku_tamsayi: not an integer");
            return Value::makeNull();
        }
    }

    // conversions
    if(name=="metne"){
        if(args.size()!=1){ runtimeError("metne(x) expects 1 arg"); return Value::makeNull(); }
        return Value::makeString(args[0].toString());
    }
    if(name=="sayiya" || name=="sayıya"){
        if(args.size()!=1){ runtimeError("sayiya(x) expects 1 arg"); return Value::makeNull(); }
        const Value& x=args[0];
        if(x.type==Value::Type::Number) return x;
        if(x.type==Value::Type::Bool) return Value::makeNumber(x.boolean?1.0:0.0);
        if(x.type==Value::Type::String){
            try{ return Value::makeNumber(std::stod(x.str)); }
            catch(...){ runtimeError("sayiya: string is not a number"); return Value::makeNull(); }
        }
        if(x.type==Value::Type::Null) return Value::makeNumber(0.0);
        runtimeError("sayiya: unsupported type");
        return Value::makeNull();
    }
    if(name=="mantiksala" || name=="mantıksala"){
        if(args.size()!=1){ runtimeError("mantiksala(x) expects 1 arg"); return Value::makeNull(); }
        return Value::makeBool(isTruthy(args[0]));
    }

    // push/ekle(arr, v)
    if(name=="push" || name=="ekle"){
        if(args.size()!=2){ runtimeError("ekle(dizi, v) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){
            runtimeError("ekle: first arg must be array");
            return Value::makeNull();
        }
        args[0].arr->push_back(args[1]);
        return Value::makeNull();
    }

    // pop(arr) -> value
    if(name=="pop" || name=="cikar" || name=="çıkar"){
        if(args.size()!=1){ runtimeError("pop(dizi) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){
            runtimeError("pop: arg must be array");
            return Value::makeNull();
        }
        if(args[0].arr->empty()){
            runtimeError("pop: empty array");
            return Value::makeNull();
        }
        Value v = args[0].arr->back();
        args[0].arr->pop_back();
        return v;
    }

    // sil(arr, i) -> removes at index
    if(name=="sil"){
        if(args.size()!=2){ runtimeError("sil(dizi, i) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){
            runtimeError("sil: first arg must be array");
            return Value::makeNull();
        }
        if(args[1].type!=Value::Type::Number){
            runtimeError("sil: index must be number");
            return Value::makeNull();
        }
        int i=(int)args[1].number;
        int n=(int)args[0].arr->size();
        if(i<0) i=n+i;
        if(i<0 || i>=n){ runtimeError("sil: index out of range"); return Value::makeNull(); }
        args[0].arr->erase(args[0].arr->begin()+i);
        return Value::makeNull();
    }

    // temizle(arr)
    if(name=="temizle"){
        if(args.size()!=1){ runtimeError("temizle(dizi) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){
            runtimeError("temizle: arg must be array");
            return Value::makeNull();
        }
        args[0].arr->clear();
        return Value::makeNull();
    }

    // birlestir(arr, ayirici) -> join
    if(name=="birlestir" || name=="birleştir"){
        if(args.size()!=2){ runtimeError("birlestir(dizi, ayirici) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Array || !args[0].arr){
            runtimeError("birlestir: first arg must be array");
            return Value::makeNull();
        }
        if(args[1].type!=Value::Type::String){
            runtimeError("birlestir: separator must be string");
            return Value::makeNull();
        }
        const std::string& sep=args[1].str;
        std::string out;
        for(size_t i=0;i<args[0].arr->size();++i){
            if(i) out += sep;
            out += (*args[0].arr)[i].toString();
        }
        return Value::makeString(out);
    }

    // bol(text, ayirici) -> split
    if(name=="bol"){
        if(args.size()!=2){ runtimeError("bol(metin, ayirici) expects 2 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::String || args[1].type!=Value::Type::String){
            runtimeError("bol: both args must be strings");
            return Value::makeNull();
        }

        auto vec = std::make_shared<std::vector<Value>>();
        const std::string& text=args[0].str;
        const std::string& sep=args[1].str;

        if(sep.empty()){
            // split into UTF-8 codepoints
            size_t pos=0, len=0;
            while(pos < text.size()){
                if(!utf8_next(text,pos,len)){ runtimeError("bol: invalid utf-8"); return Value::makeNull(); }
                vec->push_back(Value::makeString(text.substr(pos, len)));
                pos += len;
            }
            return Value::makeArray(vec);
        }

        size_t start=0;
        while(true){
            size_t p = text.find(sep, start);
            if(p==std::string::npos){
                vec->push_back(Value::makeString(text.substr(start)));
                break;
            }
            vec->push_back(Value::makeString(text.substr(start, p-start)));
            start = p + sep.size();
        }
        return Value::makeArray(vec);
    }

    // alt(text, bas, uzunluk) -> UTF-8 safe substring by codepoints
    if(name=="alt"){
        if(args.size()!=3){ runtimeError("alt(metin, bas, uzunluk) expects 3 args"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::String || args[1].type!=Value::Type::Number || args[2].type!=Value::Type::Number){
            runtimeError("alt: types must be (string, number, number)");
            return Value::makeNull();
        }
        int start=(int)args[1].number;
        int count=(int)args[2].number;
        std::string out;
        if(!utf8_substr(args[0].str, start, count, out)){
            runtimeError("alt: invalid utf-8");
            return Value::makeNull();
        }
        return Value::makeString(out);
    }

    // object helpers
    if(name=="anahtarlar"){
        if(args.size()!=1){ runtimeError("anahtarlar(obj) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Object || !args[0].obj){
            runtimeError("anahtarlar: arg must be object");
            return Value::makeNull();
        }
        auto vec = std::make_shared<std::vector<Value>>();
        for(auto& kv: args[0].obj->fields) vec->push_back(Value::makeString(kv.first));
        return Value::makeArray(vec);
    }

    if(name=="degerler" || name=="değerler"){
        if(args.size()!=1){ runtimeError("degerler(obj) expects 1 arg"); return Value::makeNull(); }
        if(args[0].type!=Value::Type::Object || !args[0].obj){
            runtimeError("degerler: arg must be object");
            return Value::makeNull();
        }
        auto vec = std::make_shared<std::vector<Value>>();
        for(auto& kv: args[0].obj->fields) vec->push_back(kv.second);
        return Value::makeArray(vec);
    }

    if(name=="varmi" || name=="varmı"){
        if(args.size()!=2){ runtimeError("varmi(x, y) expects 2 args"); return Value::makeNull(); }

        // array contains
        if(args[0].type==Value::Type::Array && args[0].arr){
            for(auto& v: *args[0].arr){
                if(valueEquals(v, args[1])) return Value::makeBool(true);
            }
            return Value::makeBool(false);
        }

        // object contains key
        if(args[0].type==Value::Type::Object && args[0].obj){
            if(args[1].type!=Value::Type::String){
                runtimeError("varmi(obj, anahtar) requires string key");
                return Value::makeNull();
            }
            return Value::makeBool(args[0].obj->fields.find(args[1].str)!=args[0].obj->fields.end());
        }

        // string contains substring
        if(args[0].type==Value::Type::String && args[1].type==Value::Type::String){
            return Value::makeBool(args[0].str.find(args[1].str) != std::string::npos);
        }

        runtimeError("varmi: unsupported types");
        return Value::makeNull();
    }

    // math helpers
    if(name=="mutlak"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("mutlak(x) expects 1 number"); return Value::makeNull(); }
        return Value::makeNumber(std::fabs(args[0].number));
    }
    if(name=="taban"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("taban(x) expects 1 number"); return Value::makeNull(); }
        return Value::makeNumber(std::floor(args[0].number));
    }
    if(name=="tavan"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("tavan(x) expects 1 number"); return Value::makeNull(); }
        return Value::makeNumber(std::ceil(args[0].number));
    }
    if(name=="yuvarla"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){ runtimeError("yuvarla(x) expects 1 number"); return Value::makeNull(); }
        return Value::makeNumber(std::round(args[0].number));
    }
    if(name=="min" || name=="max"){
        if(args.empty()){ runtimeError(std::string(name)+" requires at least 1 arg"); return Value::makeNull(); }
        for(auto& v: args) if(v.type!=Value::Type::Number){ runtimeError(std::string(name)+" expects numbers"); return Value::makeNull(); }
        double best = args[0].number;
        for(size_t i=1;i<args.size();++i){
            if(name=="min") best = std::min(best, args[i].number);
            else best = std::max(best, args[i].number);
        }
        return Value::makeNumber(best);
    }
    if(name=="rastgele"){
        if(args.size()!=2 || args[0].type!=Value::Type::Number || args[1].type!=Value::Type::Number){
            runtimeError("rastgele(a,b) expects 2 numbers");
            return Value::makeNull();
        }
        int a=(int)args[0].number;
        int b=(int)args[1].number;
        if(a>b) std::swap(a,b);
        static std::random_device rd;
        static std::mt19937 gen(rd());
        std::uniform_int_distribution<int> dist(a,b);
        return Value::makeNumber((double)dist(gen));
    }


    // --- math library builtins (require: mat_kütüphanesi kullanılıyor;) ---
    auto requireMath=[&]()->bool{
        if(!libEnabled(enabledLibs, "math")){
            runtimeError("Bu fonksiyon için önce 'mat_kütüphanesi kullanılıyor;' yazmalısın");
            return false;
        }
        return true;
    };

    if(name=="pi"){
        if(!args.empty()){ runtimeError("pi() expects 0 args"); return Value::makeNull(); }
        if(!requireMath()) return Value::makeNull();
        return Value::makeNumber(3.14159265358979323846);
    }
    if(name=="sin" || name=="cos" || name=="tan"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){
            runtimeError(std::string(name)+"(x) expects 1 number");
            return Value::makeNull();
        }
        if(!requireMath()) return Value::makeNull();
        double x=args[0].number;
        if(name=="sin") return Value::makeNumber(std::sin(x));
        if(name=="cos") return Value::makeNumber(std::cos(x));
        return Value::makeNumber(std::tan(x));
    }
    if(name=="sqrt" || name=="karekok" || name=="karekök"){
        if(args.size()!=1 || args[0].type!=Value::Type::Number){
            runtimeError("karekok(x) expects 1 number");
            return Value::makeNull();
        }
        if(!requireMath()) return Value::makeNull();
        if(args[0].number < 0){ runtimeError("karekok: x must be >= 0"); return Value::makeNull(); }
        return Value::makeNumber(std::sqrt(args[0].number));
    }
    if(name=="pow" || name=="us" || name=="üs"){
        if(args.size()!=2 || args[0].type!=Value::Type::Number || args[1].type!=Value::Type::Number){
            runtimeError("us(x,y) expects 2 numbers");
            return Value::makeNull();
        }
        if(!requireMath()) return Value::makeNull();
        return Value::makeNumber(std::pow(args[0].number, args[1].number));
    }


    if(name=="buyuk" || name=="büyük"){
        if(args.size()!=1){ runtimeError("buyuk(x) expects 1 arg"); return Value::makeNull(); }
        std::string out = args[0].toString();
        for(char& c : out) c = (char)std::toupper((unsigned char)c);
        if(!libEnabled(enabledLibs, "text")){ runtimeError("Bu fonksiyon için önce 'metin_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        return Value::makeString(out);
    }
    if(name=="kucuk" || name=="küçük"){
        if(args.size()!=1){ runtimeError("kucuk(x) expects 1 arg"); return Value::makeNull(); }
        std::string out = args[0].toString();
        for(char& c : out) c = (char)std::tolower((unsigned char)c);
        if(!libEnabled(enabledLibs, "text")){ runtimeError("Bu fonksiyon için önce 'metin_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        return Value::makeString(out);
    }
    if(name=="kirp"){
        if(args.size()!=1){ runtimeError("kirp(x) expects 1 arg"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "text")){ runtimeError("Bu fonksiyon için önce 'metin_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        std::string out = args[0].toString();
        auto ws=[](unsigned char ch){ return std::isspace(ch); };
        while(!out.empty() && ws((unsigned char)out.front())) out.erase(out.begin());
        while(!out.empty() && ws((unsigned char)out.back())) out.pop_back();
        return Value::makeString(out);
    }
    if(name=="degistir" || name=="değiştir"){
        if(args.size()!=3){ runtimeError("degistir(metin, eski, yeni) expects 3 args"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "text")){ runtimeError("Bu fonksiyon için önce 'metin_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        std::string s=args[0].toString(), old=args[1].toString(), neu=args[2].toString();
        if(old.empty()) return Value::makeString(s);
        size_t pos=0; while((pos=s.find(old,pos))!=std::string::npos){ s.replace(pos, old.size(), neu); pos += neu.size(); }
        return Value::makeString(s);
    }
    if(name=="icerir" || name=="içerir"){
        if(args.size()!=2){ runtimeError("icerir(metin, parca) expects 2 args"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "text")){ runtimeError("Bu fonksiyon için önce 'metin_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        return Value::makeBool(args[0].toString().find(args[1].toString()) != std::string::npos);
    }
    if(name=="dosya_oku"){
        if(args.size()!=1){ runtimeError("dosya_oku(yol) expects 1 arg"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "file")){ runtimeError("Bu fonksiyon için önce 'dosya_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        std::ifstream in(args[0].toString(), std::ios::binary);
        if(!in){ runtimeError("dosya_oku: file not found"); return Value::makeNull(); }
        std::ostringstream ss; ss << in.rdbuf();
        return Value::makeString(ss.str());
    }
    if(name=="dosya_yaz" || name=="dosya_ekle"){
        if(args.size()!=2){ runtimeError("dosya_yaz(yol, metin) expects 2 args"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "file")){ runtimeError("Bu fonksiyon için önce 'dosya_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        std::ofstream out(args[0].toString(), name=="dosya_ekle" ? (std::ios::binary|std::ios::app) : std::ios::binary);
        if(!out){ runtimeError("dosya_yaz: cannot open file"); return Value::makeNull(); }
        out << args[1].toString();
        return Value::makeNull();
    }
    if(name=="guvenli_sayi_girdi" || name=="güvenli_sayı_girdi"){
        if(args.size()>1){ runtimeError("guvenli_sayi_girdi([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "input")){ runtimeError("Bu fonksiyon için önce 'girdi_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        while(true){ if(args.size()==1) std::cout << args[0].toString(); std::string line; if(!std::getline(std::cin, line)) return Value::makeNull(); try{ return Value::makeNumber(std::stod(line)); } catch(...){ std::cout << "Geçerli bir sayı gir.\n"; } }
    }
    if(name=="guvenli_tamsayi_girdi" || name=="güvenli_tamsayı_girdi"){
        if(args.size()>1){ runtimeError("guvenli_tamsayi_girdi([prompt]) expects 0 or 1 arg"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "input")){ runtimeError("Bu fonksiyon için önce 'girdi_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        while(true){ if(args.size()==1) std::cout << args[0].toString(); std::string line; if(!std::getline(std::cin, line)) return Value::makeNull(); try{ return Value::makeNumber((double)std::stoll(line)); } catch(...){ std::cout << "Geçerli bir tamsayı gir.\n"; } }
    }
    if(name=="rastgele_sec" || name=="rastgele_seç"){
        if(args.size()!=1 || args[0].type!=Value::Type::Array || !args[0].arr){ runtimeError("rastgele_sec(dizi) expects 1 array"); return Value::makeNull(); }
        if(!libEnabled(enabledLibs, "random")){ runtimeError("Bu fonksiyon için önce 'rastgele_kütüphanesi kullanılıyor;' yazmalısın"); return Value::makeNull(); }
        if(args[0].arr->empty()) return Value::makeNull();
        static std::random_device rd; static std::mt19937 gen(rd());
        std::uniform_int_distribution<int> dist(0, (int)args[0].arr->size()-1);
        return (*args[0].arr)[(size_t)dist(gen)];
    }

    runtimeError("Unknown builtin: "+name);
    return Value::makeNull();
}

// ---------- eval expr ----------
Value Interpreter::evalExpr(const Expr* e){
    if(!e) return Value::makeNull();

    if(auto n=dynamic_cast<const ExprNumber*>(e)) return Value::makeNumber(n->value);
    if(auto s=dynamic_cast<const ExprString*>(e)) return Value::makeString(s->value);
    if(auto b=dynamic_cast<const ExprBool*>(e)) return Value::makeBool(b->value);
    if(dynamic_cast<const ExprNull*>(e)) return Value::makeNull();

    if(auto a=dynamic_cast<const ExprArray*>(e)){
        auto vec = std::make_shared<std::vector<Value>>();
        vec->reserve(a->elems.size());
        for(auto& el : a->elems) vec->push_back(evalExpr(el.get()));
        return Value::makeArray(vec);
    }

    if(auto st=dynamic_cast<const ExprStruct*>(e)){
        auto it = structDefs.find(st->typeName);
        if(it==structDefs.end()){
            runtimeError("Unknown struct type: "+st->typeName);
            return Value::makeNull();
        }

        auto obj = std::make_shared<Object>();
        obj->typeName = st->typeName;

        // default fields -> bos
        for(auto& kv : it->second.fieldTypes){
            obj->fields[kv.first] = Value::makeNull();
        }

        // apply initializers
        for(auto& f : st->fields){
            auto ft = it->second.fieldTypes.find(f.name);
            if(ft==it->second.fieldTypes.end()){
                runtimeError("Unknown field '"+f.name+"' for struct "+st->typeName);
                return Value::makeNull();
            }
            Value val = evalExpr(f.value.get());

            // optional runtime type enforcement for primitive fields
            const std::string& tname = ft->second;
            bool ok=true;
            if(tname=="tamsayi" || tname=="tamsayı") ok = (val.type==Value::Type::Number || val.type==Value::Type::Null);
            else if(tname=="metin") ok = (val.type==Value::Type::String || val.type==Value::Type::Null);
            else if(tname=="mantiksal" || tname=="mantıksal") ok = (val.type==Value::Type::Bool || val.type==Value::Type::Null);
            // other types -> allow any

            if(!ok){
                runtimeError("Field '"+f.name+"' type mismatch in "+st->typeName);
                return Value::makeNull();
            }

            obj->fields[f.name] = val;
        }

        return Value::makeObject(obj);
    }

    if(auto d=dynamic_cast<const ExprDict*>(e)){
        auto obj = std::make_shared<Object>();
        obj->typeName = "sozluk";
        for(const auto& ent : d->entries) obj->fields[ent.key] = evalExpr(ent.value.get());
        return Value::makeObject(obj);
    }

    if(auto v=dynamic_cast<const ExprVar*>(e)){
        auto fit=functions.find(v->name);
        if(fit!=functions.end()) return Value::makeFunction(fit->second.get());

        Value* slot=findVar(v->name);
        if(!slot){ runtimeError("Undefined variable: "+v->name); return Value::makeNull(); }
        return *slot;
    }

    if(auto u=dynamic_cast<const ExprUnary*>(e)){
        Value r=evalExpr(u->right.get());
        if(u->op=="-"){
            if(r.type!=Value::Type::Number){ runtimeError("Unary '-' requires number"); return Value::makeNull(); }
            return Value::makeNumber(-r.number);
        }
        if(u->op=="degil" || u->op=="değil"){
            return Value::makeBool(!isTruthy(r));
        }
        runtimeError("Unknown unary op: "+u->op);
        return Value::makeNull();
    }

    if(auto bin=dynamic_cast<const ExprBinary*>(e)){
        const std::string& op=bin->op;

        // short-circuit logical
        if(op=="ve"){
            Value L=evalExpr(bin->left.get());
            if(!isTruthy(L)) return Value::makeBool(false);
            Value R=evalExpr(bin->right.get());
            return Value::makeBool(isTruthy(R));
        }
        if(op=="veya"){
            Value L=evalExpr(bin->left.get());
            if(isTruthy(L)) return Value::makeBool(true);
            Value R=evalExpr(bin->right.get());
            return Value::makeBool(isTruthy(R));
        }

        Value L=evalExpr(bin->left.get());
        Value R=evalExpr(bin->right.get());

        if(op=="+"){
            if(L.type==Value::Type::String || R.type==Value::Type::String)
                return Value::makeString(L.toString()+R.toString());

            if(L.type==Value::Type::Array && R.type==Value::Type::Array && L.arr && R.arr){
                auto out = std::make_shared<std::vector<Value>>(*L.arr);
                out->insert(out->end(), R.arr->begin(), R.arr->end());
                return Value::makeArray(out);
            }

            if(L.type==Value::Type::Number && R.type==Value::Type::Number)
                return Value::makeNumber(L.number+R.number);

            runtimeError("'+': needs numbers, strings, or arrays");
            return Value::makeNull();
        }

        if(op=="-"||op=="*"||op=="/"||op=="%"){
            if(L.type!=Value::Type::Number||R.type!=Value::Type::Number){
                runtimeError("Operator '"+op+"' needs numbers");
                return Value::makeNull();
            }
            if(op=="-") return Value::makeNumber(L.number-R.number);
            if(op=="*") return Value::makeNumber(L.number*R.number);
            if(op=="/"){
                if(R.number==0.0){ runtimeError("Division by zero"); return Value::makeNull(); }
                return Value::makeNumber(L.number/R.number);
            }
            if(op=="%"){
                long long a=(long long)L.number, b=(long long)R.number;
                if(b==0){ runtimeError("Modulo by zero"); return Value::makeNull(); }
                return Value::makeNumber((double)(a % b));
            }
        }

        if(op=="<"||op=="<="||op==">"||op==">="){
            if(L.type!=Value::Type::Number||R.type!=Value::Type::Number){
                runtimeError("Comparison '"+op+"' needs numbers");
                return Value::makeNull();
            }
            if(op=="<") return Value::makeBool(L.number<R.number);
            if(op=="<=") return Value::makeBool(L.number<=R.number);
            if(op==">") return Value::makeBool(L.number>R.number);
            if(op==">=") return Value::makeBool(L.number>=R.number);
        }

        if(op=="=="||op=="!="){
            bool eq = valueEquals(L,R);
            return Value::makeBool(op=="=="?eq:!eq);
        }

        runtimeError("Unknown operator: "+op);
        return Value::makeNull();
    }

    if(auto get=dynamic_cast<const ExprGet*>(e)){
        Value base=evalExpr(get->obj.get());
        if(base.type!=Value::Type::Object || !base.obj){
            runtimeError("'.' needs object");
            return Value::makeNull();
        }
        auto it = base.obj->fields.find(get->field);
        if(it==base.obj->fields.end()){
            runtimeError("Unknown field: "+get->field);
            return Value::makeNull();
        }
        return it->second;
    }

    if(auto ix=dynamic_cast<const ExprIndex*>(e)){
        Value base=evalExpr(ix->base.get());
        Value idx=evalExpr(ix->index.get());

        if(base.type==Value::Type::Object && base.obj){
            if(idx.type!=Value::Type::String){
                runtimeError("Object index must be string");
                return Value::makeNull();
            }
            auto it = base.obj->fields.find(idx.str);
            if(it==base.obj->fields.end()) return Value::makeNull();
            return it->second;
        }

        if(idx.type!=Value::Type::Number){
            runtimeError("Index must be number");
            return Value::makeNull();
        }
        int i=(int)idx.number;

        if(base.type==Value::Type::Array && base.arr){
            int n=(int)base.arr->size();
            if(i<0) i=n+i;
            if(i<0 || i>=n){ runtimeError("Array index out of range"); return Value::makeNull(); }
            return (*base.arr)[(size_t)i];
        }

        if(base.type==Value::Type::String){
            std::string ch;
            if(!utf8_nth_codepoint(base.str, i, ch)){ runtimeError("String index out of range"); return Value::makeNull(); }
            return Value::makeString(ch);
        }

        runtimeError("Indexing supported only on array/string/object");
        return Value::makeNull();
    }

    if(auto call=dynamic_cast<const ExprCall*>(e)){
        if(auto cv=dynamic_cast<const ExprVar*>(call->callee.get())){
            std::vector<Value> args;
            args.reserve(call->args.size());
            for(auto& a: call->args) args.push_back(evalExpr(a.get()));

            if(isBuiltin(cv->name)){
                return callBuiltin(cv->name, args);
            }

            auto fit=functions.find(cv->name);
            if(fit!=functions.end()){
                return callFunction(fit->second.get(), args);
            }
        }

        Value callee=evalExpr(call->callee.get());
        if(callee.type!=Value::Type::Function || !callee.func){
            runtimeError("Called value is not a function");
            return Value::makeNull();
        }
        std::vector<Value> args;
        args.reserve(call->args.size());
        for(auto& a: call->args) args.push_back(evalExpr(a.get()));
        return callFunction(callee.func,args);
    }

    runtimeError("Unknown expression type");
    return Value::makeNull();
}

// ---------- exec stmt ----------
Interpreter::Flow Interpreter::execStmt(const Stmt* s){
    if(!s) return Flow::none();

    if(auto sd=dynamic_cast<const StmtStructDecl*>(s)){
        StructDef def;
        for(auto& f : sd->fields){
            def.fieldTypes[f.name] = f.typeName;
        }
        structDefs[sd->name] = std::move(def);
        return Flow::none();
    }

    if(auto fn=dynamic_cast<const StmtFunction*>(s)){
        auto f=std::make_unique<Function>();
        f->name   = fn->name;
        for(const auto& p : fn->params){ f->params.push_back(p.name); f->paramTypes.push_back(p.typeName); }
        f->returnType = fn->returnType;
        f->body   = fn->body.get();
        functions[fn->name] = std::move(f);
        return Flow::none();
    }

    if(auto ul=dynamic_cast<const StmtUseLib*>(s)){
        enabledLibs.insert(canonicalLibName(ul->libName));
        return Flow::none();
    }


    if(auto vd=dynamic_cast<const StmtVarDecl*>(s)){
        Value v=evalExpr(vd->init.get());
        scopes.back()[vd->name]=v;
        return Flow::none();
    }

    if(auto as=dynamic_cast<const StmtAssign*>(s)){
        Value v=evalExpr(as->value.get());
        Value* slot=findVar(as->name);
        if(!slot){ runtimeError("Assign to undefined: "+as->name); return Flow::none(); }
        *slot=v;
        return Flow::none();
    }

    if(auto aa=dynamic_cast<const StmtAugAssign*>(s)){
        Value* slot=findVar(aa->name);
        if(!slot){ runtimeError("AugAssign to undefined: "+aa->name); return Flow::none(); }

        Value rhs=evalExpr(aa->value.get());
        const std::string& op=aa->op;

        if(op=="+="){
            if(slot->type==Value::Type::String || rhs.type==Value::Type::String){
                *slot = Value::makeString(slot->toString() + rhs.toString());
                return Flow::none();
            }
            if(slot->type==Value::Type::Array && rhs.type==Value::Type::Array && slot->arr && rhs.arr){
                slot->arr->insert(slot->arr->end(), rhs.arr->begin(), rhs.arr->end());
                return Flow::none();
            }
            if(slot->type==Value::Type::Number && rhs.type==Value::Type::Number){
                slot->number += rhs.number;
                return Flow::none();
            }
            runtimeError("'+=' supports numbers/strings/arrays");
            return Flow::none();
        }

        if(op=="-="||op=="*="||op=="/="){
            if(slot->type!=Value::Type::Number || rhs.type!=Value::Type::Number){
                runtimeError("AugAssign '"+op+"' needs numbers");
                return Flow::none();
            }
            if(op=="-=") slot->number -= rhs.number;
            else if(op=="*=") slot->number *= rhs.number;
            else if(op=="/="){
                if(rhs.number==0.0){ runtimeError("Division by zero"); return Flow::none(); }
                slot->number /= rhs.number;
            }
            return Flow::none();
        }

        runtimeError("Unknown augmented op: "+op);
        return Flow::none();
    }

    if(auto si=dynamic_cast<const StmtSetIndex*>(s)){
        Value* slot=findVar(si->arrName);
        if(!slot){ runtimeError("SetIndex on undefined: "+si->arrName); return Flow::none(); }
        Value idx=evalExpr(si->index.get());
        Value val=evalExpr(si->value.get());

        if(slot->type==Value::Type::Object && slot->obj){
            if(idx.type!=Value::Type::String){ runtimeError("SetIndex object key must be string"); return Flow::none(); }
            slot->obj->fields[idx.str] = val;
            return Flow::none();
        }

        if(slot->type!=Value::Type::Array || !slot->arr){
            runtimeError("SetIndex requires array/object variable");
            return Flow::none();
        }
        if(idx.type!=Value::Type::Number){ runtimeError("SetIndex index must be number"); return Flow::none(); }
        int i=(int)idx.number;
        int n=(int)slot->arr->size();
        if(i<0) i=n+i;
        if(i<0){ runtimeError("SetIndex out of range"); return Flow::none(); }
        if(i >= 0 && i < (int)slot->arr->size()){
            (*slot->arr)[(size_t)i] = val;
            return Flow::none();
        }
        if(i == (int)slot->arr->size()){
            slot->arr->push_back(val);
            return Flow::none();
        }
        runtimeError("SetIndex out of range (only existing index or append at size)");
        return Flow::none();
    }

    if(auto sf=dynamic_cast<const StmtSetField*>(s)){
        Value* slot=findVar(sf->objName);
        if(!slot){ runtimeError("SetField on undefined: "+sf->objName); return Flow::none(); }
        if(slot->type!=Value::Type::Object || !slot->obj){
            runtimeError("SetField requires object");
            return Flow::none();
        }

        auto defIt = structDefs.find(slot->obj->typeName);
        if(defIt != structDefs.end()){
            auto ft = defIt->second.fieldTypes.find(sf->field);
            if(ft==defIt->second.fieldTypes.end()){
                runtimeError("Unknown field '"+sf->field+"' for struct "+slot->obj->typeName);
                return Flow::none();
            }
            Value val=evalExpr(sf->value.get());
            const std::string& tname=ft->second;
            bool ok=true;
            if(tname=="tamsayi" || tname=="tamsayı") ok = (val.type==Value::Type::Number || val.type==Value::Type::Null);
            else if(tname=="metin") ok = (val.type==Value::Type::String || val.type==Value::Type::Null);
            else if(tname=="mantiksal" || tname=="mantıksal") ok = (val.type==Value::Type::Bool || val.type==Value::Type::Null);
            if(!ok){
                runtimeError("Field '"+sf->field+"' type mismatch in "+slot->obj->typeName);
                return Flow::none();
            }
            slot->obj->fields[sf->field] = val;
            return Flow::none();
        }

        slot->obj->fields[sf->field] = evalExpr(sf->value.get());
        return Flow::none();
    }


    if(auto fe=dynamic_cast<const StmtForeach*>(s)){
        Value it = evalExpr(fe->iterable.get());

        auto runBody = [&](const Value& first, const Value& second)->Flow{
            beginScope();
            if(fe->isPair){
                scopes.back()[fe->firstName]  = first;
                scopes.back()[fe->secondName] = second;
            } else {
                scopes.back()[fe->secondName] = second;
            }

            Flow f = execStmt(fe->body.get());
            endScope();
            return f;
        };

        // foreach over array
        if(it.type==Value::Type::Array && it.arr){
            for(int idx=0; idx<(int)it.arr->size(); ++idx){
                Value first = Value::makeNumber((double)idx);
                Value second = (*it.arr)[(size_t)idx];

                Flow f = runBody(first, second);
                if(f.kind==FlowKind::Return) return f;
                if(f.kind==FlowKind::BreakLoop) break;
                if(f.kind==FlowKind::ContinueLoop) continue;
            }
            return Flow::none();
        }

        // foreach over string (UTF-8 codepoints)
        if(it.type==Value::Type::String){
            int n = utf8_codepoint_count(it.str);
            if(n < 0){ runtimeError("foreach: invalid utf-8 string"); return Flow::none(); }
            for(int idx=0; idx<n; ++idx){
                std::string ch;
                if(!utf8_nth_codepoint(it.str, idx, ch)){
                    runtimeError("foreach: utf-8 index fail");
                    return Flow::none();
                }

                Value first = Value::makeNumber((double)idx);
                Value second = Value::makeString(ch);

                Flow f = runBody(first, second);
                if(f.kind==FlowKind::Return) return f;
                if(f.kind==FlowKind::BreakLoop) break;
                if(f.kind==FlowKind::ContinueLoop) continue;
            }
            return Flow::none();
        }

        // foreach over object:
        //   - single-var: gives key
        //   - pair-var: first=key, second=value
        if(it.type==Value::Type::Object && it.obj){
            for(auto& kv : it.obj->fields){
                Value key = Value::makeString(kv.first);
                Value val = kv.second;

                if(fe->isPair){
                    Flow f = runBody(key, val);
                    if(f.kind==FlowKind::Return) return f;
                    if(f.kind==FlowKind::BreakLoop) break;
                    if(f.kind==FlowKind::ContinueLoop) continue;
                } else {
                    Flow f = runBody(key, key);
                    if(f.kind==FlowKind::Return) return f;
                    if(f.kind==FlowKind::BreakLoop) break;
                    if(f.kind==FlowKind::ContinueLoop) continue;
                }
            }
            return Flow::none();
        }

        runtimeError("her ... içinde: iterable must be dizi/metin/yapi");
        return Flow::none();
    }

    if(auto pr=dynamic_cast<const StmtPrint*>(s)){
        std::cout<<evalExpr(pr->expr.get()).toString()<<"\n";
        return Flow::none();
    }

    if(auto es=dynamic_cast<const StmtExpr*>(s)){
        (void)evalExpr(es->expr.get());
        return Flow::none();
    }

    if(dynamic_cast<const StmtBreak*>(s)) return Flow::brLoop();
    if(dynamic_cast<const StmtContinue*>(s)) return Flow::contLoop();
    if(auto rt=dynamic_cast<const StmtReturn*>(s)) return Flow::makeReturn(evalExpr(rt->value.get()));

    if(auto bl=dynamic_cast<const StmtBlock*>(s)){
        beginScope();
        for(auto& st: bl->stmts){
            Flow f=execStmt(st.get());
            if(f.kind!=FlowKind::None){
                endScope();
                return f;
            }
        }
        endScope();
        return Flow::none();
    }

    if(auto iff=dynamic_cast<const StmtIf*>(s)){
        if(isTruthy(evalExpr(iff->cond.get()))){
            return execStmt(iff->thenBranch.get());
        } else if(iff->elseBranch){
            return execStmt(iff->elseBranch.get());
        }
        return Flow::none();
    }

    if(auto wh=dynamic_cast<const StmtWhile*>(s)){
        while(isTruthy(evalExpr(wh->cond.get()))){
            Flow f=execStmt(wh->body.get());
            if(f.kind==FlowKind::BreakLoop) break;
            if(f.kind==FlowKind::ContinueLoop) continue;
            if(f.kind==FlowKind::Return) return f;
        }
        return Flow::none();
    }

    if(auto dw=dynamic_cast<const StmtDoWhile*>(s)){
        do{
            Flow f=execStmt(dw->body.get());
            if(f.kind==FlowKind::BreakLoop) break;
            if(f.kind==FlowKind::Return) return f;
        }while(isTruthy(evalExpr(dw->cond.get())));
        return Flow::none();
    }

    if(auto fr=dynamic_cast<const StmtFor*>(s)){
        beginScope();
        if(fr->init) execStmt(fr->init.get());
        while(true){
            if(fr->cond){
                if(!isTruthy(evalExpr(fr->cond.get()))) break;
            }
            Flow f=execStmt(fr->body.get());
            if(f.kind==FlowKind::Return){ endScope(); return f; }
            if(f.kind==FlowKind::BreakLoop) break;
            if(fr->step) execStmt(fr->step.get());
            if(f.kind==FlowKind::ContinueLoop) continue;
        }
        endScope();
        return Flow::none();
    }

    if(auto sw=dynamic_cast<const StmtSwitch*>(s)){
        Value key=evalExpr(sw->expr.get());
        bool matched=false;

        auto execList=[&](const std::vector<std::unique_ptr<Stmt>>& list)->Flow{
            for(auto& st:list){
                Flow f=execStmt(st.get());
                if(f.kind==FlowKind::BreakLoop) return Flow::brSwitch();
                if(f.kind==FlowKind::Return) return f;
            }
            return Flow::none();
        };

        for(auto& c: sw->cases){
            Value cv=evalExpr(c.value.get());
            bool eq=valueEquals(key, cv);
            if(eq){
                matched=true;
                Flow f=execList(c.stmts);
                if(f.kind==FlowKind::BreakSwitch) return Flow::none();
                if(f.kind!=FlowKind::None) return f;
                break;
            }
        }
        if(!matched && !sw->defaultStmts.empty()){
            Flow f=execList(sw->defaultStmts);
            if(f.kind==FlowKind::BreakSwitch) return Flow::none();
            if(f.kind!=FlowKind::None) return f;
        }
        return Flow::none();
    }

    runtimeError("Unknown statement type");
    return Flow::none();
}

bool Interpreter::run(const Program& program){
    hadError=false;
    scopes.clear();
    functions.clear();
    structDefs.clear();
    enabledLibs.clear();

    beginScope(); // global scope

    // Hoist structs + functions so usage-before-decl works.
    for(auto& st: program.stmts){
        if(auto sd=dynamic_cast<const StmtStructDecl*>(st.get())){
            StructDef def;
            for(auto& f : sd->fields) def.fieldTypes[f.name] = f.typeName;
            structDefs[sd->name] = std::move(def);
        }
        if(auto fn=dynamic_cast<const StmtFunction*>(st.get())){
            auto f=std::make_unique<Function>();
            f->name   = fn->name;
            for(const auto& p : fn->params){ f->params.push_back(p.name); f->paramTypes.push_back(p.typeName); }
            f->returnType = fn->returnType;
            f->body   = fn->body.get();
            functions[fn->name] = std::move(f);
        }
    }

    for(auto& st: program.stmts){
        // skip decls (already hoisted)
        if(dynamic_cast<const StmtFunction*>(st.get())) continue;
        if(dynamic_cast<const StmtStructDecl*>(st.get())) continue;

        Flow f=execStmt(st.get());
        if(f.kind==FlowKind::Return) runtimeError("dondur used outside function");
        if(f.kind==FlowKind::BreakLoop || f.kind==FlowKind::ContinueLoop)
            runtimeError("kir/devam used outside loop");
    }

    endScope();
    return !hadError;
}