#pragma once
#include <string>
#include <unordered_set>
#include <vector>

inline std::string turkceToLowerAscii(std::string s){
    for(char& c : s){
        if(c>='A' && c<='Z') c = (char)(c - 'A' + 'a');
    }
    return s;
}

inline std::string canonicalLibName(const std::string& s){
    std::string t = turkceToLowerAscii(s);

    if(t=="mat_kutphanesi" || t=="mat_kütüphanesi" || t=="mat" || t=="math" ||
       t=="matematik_kutphanesi" || t=="matematik_kütüphanesi")
        return "math";

    if(t=="metin_kutphanesi" || t=="metin_kütüphanesi" || t=="metin" || t=="text" ||
       t=="string_kutphanesi" || t=="string_kütüphanesi")
        return "text";

    if(t=="dosya_kutphanesi" || t=="dosya_kütüphanesi" || t=="dosya" || t=="file" ||
       t=="file_kutphanesi" || t=="file_kütüphanesi")
        return "file";

    if(t=="rastgele_kutphanesi" || t=="rastgele_kütüphanesi" || t=="rastgele" || t=="random" ||
       t=="random_kutphanesi" || t=="random_kütüphanesi")
        return "random";

    if(t=="girdi_kutphanesi" || t=="girdi_kütüphanesi" || t=="girdi" || t=="io" ||
       t=="io_kutphanesi" || t=="io_kütüphanesi")
        return "input";

    return t;
}

inline bool isKnownLibraryName(const std::string& s){
    static const std::unordered_set<std::string> known = {"math","text","file","random","input"};
    return known.find(canonicalLibName(s)) != known.end();
}

inline bool libEnabled(const std::unordered_set<std::string>& libs, const std::string& name){
    return libs.find(canonicalLibName(name)) != libs.end();
}

inline const char* preferredLibraryDisplayName(const std::string& canonical){
    if(canonical=="math") return "mat_kütüphanesi";
    if(canonical=="text") return "metin_kütüphanesi";
    if(canonical=="file") return "dosya_kütüphanesi";
    if(canonical=="random") return "rastgele_kütüphanesi";
    if(canonical=="input") return "girdi_kütüphanesi";
    return nullptr;
}

inline std::string builtinRequiredLibrary(const std::string& name){
    if(name=="pi" || name=="sin" || name=="cos" || name=="tan" ||
       name=="sqrt" || name=="karekok" || name=="karekök" ||
       name=="pow" || name=="us" || name=="üs")
        return "math";

    if(name=="buyuk" || name=="büyük" || name=="kucuk" || name=="küçük" ||
       name=="kirp" || name=="degistir" || name=="değiştir" ||
       name=="icerir" || name=="içerir")
        return "text";

    if(name=="dosya_oku" || name=="dosya_yaz" || name=="dosya_ekle")
        return "file";

    if(name=="rastgele" || name=="rastgele_sec" || name=="rastgele_seç")
        return "random";

    if(name=="guvenli_sayi_girdi" || name=="güvenli_sayı_girdi" ||
       name=="guvenli_tamsayi_girdi" || name=="güvenli_tamsayı_girdi")
        return "input";

    return "";
}

inline std::vector<std::string> allBuiltinNames(){
    return {
        "len","uzunluk","tip","sizeof","boyut",
        "push","ekle","pop","cikar","çıkar","sil","temizle",
        "anahtarlar","degerler","değerler","varmi","varmı",
        "bol","birlestir","birleştir","alt",
        "mutlak","taban","tavan","yuvarla","min","max","rastgele",
        "pi","sin","cos","tan","sqrt","karekok","karekök","pow","us","üs",
        "oku","girdi","oku_sayi","oku_sayı","girdi_sayi","girdi_sayı",
        "oku_tamsayi","oku_tamsayı","girdi_tamsayi","girdi_tamsayı",
        "guvenli_sayi_girdi","güvenli_sayı_girdi","guvenli_tamsayi_girdi","güvenli_tamsayı_girdi",
        "yaz","__kullaniliyor",
        "metne","sayiya","sayıya","mantiksala","mantıksala",
        "aralik","aralık","range",
        "buyuk","büyük","kucuk","küçük","kirp","degistir","değiştir","icerir","içerir",
        "dosya_oku","dosya_yaz","dosya_ekle",
        "rastgele_sec","rastgele_seç"
    };
}
