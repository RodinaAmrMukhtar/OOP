#pragma once
#include <memory>
#include <string>
#include <utility>
#include <vector>

struct Expr { virtual ~Expr() = default; };

struct ExprNumber : Expr { double value; explicit ExprNumber(double v):value(v){} };
struct ExprString : Expr { std::string value; explicit ExprString(std::string v):value(std::move(v)){} };
struct ExprBool   : Expr { bool value; explicit ExprBool(bool v):value(v){} };
struct ExprNull   : Expr { };

struct ExprVar : Expr { std::string name; explicit ExprVar(std::string n):name(std::move(n)){} };

struct ExprUnary : Expr {
    std::string op;
    std::unique_ptr<Expr> right;
    ExprUnary(std::string o, std::unique_ptr<Expr> r):op(std::move(o)),right(std::move(r)){}
};

struct ExprBinary : Expr {
    std::string op;
    std::unique_ptr<Expr> left, right;
    ExprBinary(std::string o, std::unique_ptr<Expr> l, std::unique_ptr<Expr> r)
        : op(std::move(o)), left(std::move(l)), right(std::move(r)) {}
};

struct ExprCall : Expr {
    std::unique_ptr<Expr> callee;
    std::vector<std::unique_ptr<Expr>> args;
    ExprCall(std::unique_ptr<Expr> c, std::vector<std::unique_ptr<Expr>> a)
        : callee(std::move(c)), args(std::move(a)) {}
};

struct ExprArray : Expr {
    std::vector<std::unique_ptr<Expr>> elems;
    ExprArray() = default;
    explicit ExprArray(std::vector<std::unique_ptr<Expr>> e): elems(std::move(e)) {}
};

struct StructFieldInit { std::string name; std::unique_ptr<Expr> value; };
struct DictEntry { std::string key; std::unique_ptr<Expr> value; };

struct ExprStruct : Expr {
    std::string typeName;
    std::vector<StructFieldInit> fields;
};

struct ExprDict : Expr {
    std::vector<DictEntry> entries;
};

struct ExprGet : Expr {
    std::unique_ptr<Expr> obj;
    std::string field;
    ExprGet(std::unique_ptr<Expr> o, std::string f) : obj(std::move(o)), field(std::move(f)) {}
};

struct ExprIndex : Expr {
    std::unique_ptr<Expr> base;
    std::unique_ptr<Expr> index;
    ExprIndex(std::unique_ptr<Expr> b, std::unique_ptr<Expr> i)
        : base(std::move(b)), index(std::move(i)) {}
};

struct Stmt { virtual ~Stmt() = default; };

struct StmtVarDecl : Stmt {
    std::string name;
    std::unique_ptr<Expr> init;
    std::string declaredType;
    bool isConst = false;
    StmtVarDecl(std::string n, std::unique_ptr<Expr> e, std::string t = "", bool c = false)
        : name(std::move(n)), init(std::move(e)), declaredType(std::move(t)), isConst(c) {}
};

struct StmtAssign : Stmt {
    std::string name;
    std::unique_ptr<Expr> value;
    StmtAssign(std::string n, std::unique_ptr<Expr> v):name(std::move(n)),value(std::move(v)){}
};

struct StmtAugAssign : Stmt {
    std::string name;
    std::string op;
    std::unique_ptr<Expr> value;
    StmtAugAssign(std::string n, std::string o, std::unique_ptr<Expr> v)
        : name(std::move(n)), op(std::move(o)), value(std::move(v)) {}
};

struct StmtSetIndex : Stmt {
    std::string arrName;
    std::unique_ptr<Expr> index;
    std::unique_ptr<Expr> value;
    StmtSetIndex(std::string a, std::unique_ptr<Expr> i, std::unique_ptr<Expr> v)
        : arrName(std::move(a)), index(std::move(i)), value(std::move(v)) {}
};

struct StmtSetField : Stmt {
    std::string objName;
    std::string field;
    std::unique_ptr<Expr> value;
    StmtSetField(std::string o, std::string f, std::unique_ptr<Expr> v)
        : objName(std::move(o)), field(std::move(f)), value(std::move(v)) {}
};

struct StmtPrint : Stmt { std::unique_ptr<Expr> expr; explicit StmtPrint(std::unique_ptr<Expr> e):expr(std::move(e)){} };
struct StmtUseLib : Stmt { std::string libName; explicit StmtUseLib(std::string n): libName(std::move(n)) {} };
struct StmtExpr : Stmt { std::unique_ptr<Expr> expr; explicit StmtExpr(std::unique_ptr<Expr> e):expr(std::move(e)){} };
struct StmtBlock : Stmt { std::vector<std::unique_ptr<Stmt>> stmts; };

struct StmtIf : Stmt {
    std::unique_ptr<Expr> cond;
    std::unique_ptr<Stmt> thenBranch;
    std::unique_ptr<Stmt> elseBranch;
    StmtIf(std::unique_ptr<Expr> c, std::unique_ptr<Stmt> t, std::unique_ptr<Stmt> e)
        : cond(std::move(c)), thenBranch(std::move(t)), elseBranch(std::move(e)) {}
};

struct StmtWhile : Stmt {
    std::unique_ptr<Expr> cond;
    std::unique_ptr<Stmt> body;
    StmtWhile(std::unique_ptr<Expr> c, std::unique_ptr<Stmt> b):cond(std::move(c)),body(std::move(b)){}
};

struct StmtDoWhile : Stmt {
    std::unique_ptr<Stmt> body;
    std::unique_ptr<Expr> cond;
    StmtDoWhile(std::unique_ptr<Stmt> b, std::unique_ptr<Expr> c):body(std::move(b)),cond(std::move(c)){}
};

struct StmtFor : Stmt {
    std::unique_ptr<Stmt> init;
    std::unique_ptr<Expr> cond;
    std::unique_ptr<Stmt> step;
    std::unique_ptr<Stmt> body;
    StmtFor(std::unique_ptr<Stmt> i, std::unique_ptr<Expr> c, std::unique_ptr<Stmt> s, std::unique_ptr<Stmt> b)
        : init(std::move(i)), cond(std::move(c)), step(std::move(s)), body(std::move(b)) {}
};

struct StmtForeach : Stmt {
    std::string firstName;
    std::string secondName;
    bool isPair = false;
    std::unique_ptr<Expr> iterable;
    std::unique_ptr<Stmt> body;

    StmtForeach(std::string one, std::unique_ptr<Expr> it, std::unique_ptr<Stmt> bod)
        : secondName(std::move(one)), iterable(std::move(it)), body(std::move(bod)) {}

    StmtForeach(std::string a, std::string b, std::unique_ptr<Expr> it, std::unique_ptr<Stmt> bod)
        : firstName(std::move(a)), secondName(std::move(b)), isPair(true),
          iterable(std::move(it)), body(std::move(bod)) {}
};

struct StmtBreak : Stmt {};
struct StmtContinue : Stmt {};
struct StmtReturn : Stmt { std::unique_ptr<Expr> value; explicit StmtReturn(std::unique_ptr<Expr> v):value(std::move(v)){} };

struct SwitchCase { std::unique_ptr<Expr> value; std::vector<std::unique_ptr<Stmt>> stmts; };

struct StmtSwitch : Stmt {
    std::unique_ptr<Expr> expr;
    std::vector<SwitchCase> cases;
    std::vector<std::unique_ptr<Stmt>> defaultStmts;
};

struct FunctionParam {
    std::string name;
    std::string typeName;
};

struct StmtFunction : Stmt {
    std::string name;
    std::vector<FunctionParam> params;
    std::string returnType;
    std::unique_ptr<StmtBlock> body;
    StmtFunction(std::string n, std::vector<FunctionParam> p, std::string rt, std::unique_ptr<StmtBlock> b)
        : name(std::move(n)), params(std::move(p)), returnType(std::move(rt)), body(std::move(b)) {}
};

struct StructFieldDef { std::string typeName; std::string name; };

struct StmtStructDecl : Stmt {
    std::string name;
    std::vector<StructFieldDef> fields;
    StmtStructDecl(std::string n, std::vector<StructFieldDef> f)
        : name(std::move(n)), fields(std::move(f)) {}
};

struct Program { std::vector<std::unique_ptr<Stmt>> stmts; };
